<?php
/**
 * Test POR Creation with Fixed Action Handling
 * Simulate frontend AJAX call with action in JSON body
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simulate POST request
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SESSION['user'] = [
    'id' => 'admin',
    'name' => 'System Admin',
    'email' => 'admin@example.com',
    'role' => 'admin'
];

// Find a receiving without POR
require_once 'config/database.php';
$db = getDB();

$stmt = $db->query("
    SELECT r.id
    FROM receivings r
    LEFT JOIN proof_of_receiving por ON r.id = por.receiving_id
    WHERE por.id IS NULL
    LIMIT 1
");
$receiving = $stmt->fetch();

if (!$receiving) {
    die("No receivings available without POR\n");
}

echo "TEST: POR Creation with Action in JSON Body\n";
echo str_repeat("=", 80) . "\n";
echo "Receiving ID: {$receiving['id']}\n";
echo str_repeat("=", 80) . "\n\n";

// Simulate JSON body input (like frontend sends)
$jsonBody = json_encode([
    'action' => 'create-from-receiving',
    'receiving_id' => $receiving['id']
]);

// Override php://input
stream_wrapper_unregister('php');
stream_wrapper_register('php', MockPhpInput::class);
MockPhpInput::$data = $jsonBody;

// Capture API output
ob_start();
try {
    include 'api/por.php';
} catch (Exception $e) {
    echo "EXCEPTION: " . $e->getMessage() . "\n";
}
$output = ob_get_clean();

echo "API RESPONSE:\n";
echo str_repeat("-", 80) . "\n";
echo $output . "\n";
echo str_repeat("-", 80) . "\n\n";

// Parse response
$response = json_decode($output, true);
if ($response) {
    if ($response['success']) {
        echo "✓ SUCCESS!\n";
        echo "POR ID: " . ($response['data']['por_id'] ?? 'N/A') . "\n";
        echo "POR Number: " . ($response['data']['por_number'] ?? 'N/A') . "\n";
    } else {
        echo "✗ FAILED\n";
        echo "Error: " . ($response['error'] ?? $response['message'] ?? 'Unknown error') . "\n";
    }
} else {
    echo "⚠ Could not parse JSON response\n";
}

/**
 * Mock php://input stream
 */
class MockPhpInput {
    public static $data = '';
    private $position = 0;
    
    public function stream_open($path, $mode, $options, &$opened_path) {
        $this->position = 0;
        return true;
    }
    
    public function stream_read($count) {
        $ret = substr(self::$data, $this->position, $count);
        $this->position += strlen($ret);
        return $ret;
    }
    
    public function stream_eof() {
        return $this->position >= strlen(self::$data);
    }
    
    public function stream_stat() {
        return [];
    }
}
