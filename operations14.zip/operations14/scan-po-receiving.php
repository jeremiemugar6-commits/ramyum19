<?php
/**
 * PO Receiving QR Scanner
 * Mobile-optimized interface for scanning and confirming PO deliveries
 */

require_once __DIR__ . '/includes/auth.php';
require_login();
$currentUser = $_SESSION['user'];

$token = $_GET['token'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan PO Delivery - RAM-YUM</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    <style>
        body {
            background: #f9fafb;
            padding: 0;
            margin: 0;
        }
        .scanner-container {
            max-width: 600px;
            margin: 0 auto;
            min-height: 100vh;
            background: white;
        }
        .header {
            background: var(--primary-red);
            color: white;
            padding: 20px;
            text-align: center;
        }
        .scanner-area {
            padding: 20px;
        }
        #reader {
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            overflow: hidden;
        }
        .manual-entry {
            margin-top: 20px;
            padding: 16px;
            background: #f9fafb;
            border-radius: 8px;
        }
        .form-group {
            margin-bottom: 16px;
        }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #374151;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-family: inherit;
        }
        .item-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 12px;
        }
        .item-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
        }
        .item-name {
            font-weight: 600;
            color: #111827;
        }
        .item-sku {
            color: #6b7280;
            font-size: 14px;
        }
        .quantity-inputs {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-top: 12px;
        }
        .btn {
            width: 100%;
            padding: 14px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: all 0.2s;
            font-size: 16px;
        }
        .btn-primary {
            background: var(--primary-red);
            color: white;
        }
        .btn-primary:hover {
            background: #b91c1c;
        }
        .btn-primary:disabled {
            background: #9ca3af;
            cursor: not-allowed;
        }
        .btn-secondary {
            background: #f3f4f6;
            color: #374151;
        }
        .alert {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .alert-info {
            background: #dbeafe;
            color: #1e40af;
            border-left: 4px solid #3b82f6;
        }
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }
        .alert-error {
            background: #fee2e2;
            color: #991b1b;
            border-left: 4px solid #ef4444;
        }
        .summary-section {
            background: #f9fafb;
            padding: 16px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e5e7eb;
        }
        .summary-row:last-child {
            border-bottom: none;
            font-weight: 600;
            font-size: 18px;
            padding-top: 12px;
        }
        .photo-upload {
            margin-top: 20px;
            padding: 16px;
            background: #fef3c7;
            border-radius: 8px;
            border-left: 4px solid #f59e0b;
        }
        .photo-preview {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
            gap: 12px;
            margin-top: 12px;
        }
        .photo-preview img {
            width: 100%;
            height: 100px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #e5e7eb;
        }
        #loadingOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.7);
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 9999;
        }
        .loading-content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
        }
        .spinner {
            border: 4px solid #f3f4f6;
            border-top: 4px solid var(--primary-red);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="scanner-container">
        <div class="header">
            <h1 style="margin: 0; font-size: 24px;">📦 Receive PO Delivery</h1>
            <p style="margin: 8px 0 0 0; opacity: 0.9;">Scan QR or enter token manually</p>
        </div>

        <div class="scanner-area">
            <!-- Step 1: Scan QR Code -->
            <div id="step1" style="display: <?php echo empty($token) ? 'block' : 'none'; ?>;">
                <div class="alert alert-info">
                    <strong>Step 1:</strong> Scan the QR code from the purchase order or enter the token manually below.
                </div>

                <div id="reader" style="margin-bottom: 20px;"></div>

                <div class="manual-entry">
                    <div class="form-group">
                        <label>Or Enter Token Manually:</label>
                        <input type="text" id="manualToken" placeholder="POR-XXXXXXXXXXXX" style="font-family: monospace;">
                    </div>
                    <button onclick="verifyManualToken()" class="btn btn-primary">Verify Token</button>
                </div>
            </div>

            <!-- Step 2: Verify Items -->
            <div id="step2" style="display: <?php echo !empty($token) ? 'block' : 'none'; ?>;">
                <div id="poInfo" style="margin-bottom: 20px;"></div>

                <h3 style="margin: 20px 0 16px 0; color: #111827;">Verify Delivered Items</h3>
                <div id="itemsList"></div>

                <div class="photo-upload">
                    <label style="display: block; font-weight: 600; margin-bottom: 8px; color: #92400e;">
                        📸 Damage Evidence (Optional)
                    </label>
                    <p style="margin: 0 0 12px 0; font-size: 14px; color: #92400e;">
                        Take photos of any damaged or incorrect items
                    </p>
                    <input type="file" id="photoInput" accept="image/*" capture="environment" multiple style="display: block; margin-bottom: 12px;">
                    <div id="photoPreview" class="photo-preview"></div>
                </div>

                <div class="form-group">
                    <label>Remarks (Optional):</label>
                    <textarea id="remarks" rows="3" placeholder="Any notes about this delivery..."></textarea>
                </div>

                <div class="summary-section" id="receivingSummary"></div>

                <button onclick="confirmReceiving()" id="confirmBtn" class="btn btn-primary" style="margin-top: 20px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                        <path d="M22 4L12 14.01l-3-3"/>
                    </svg>
                    Confirm Receipt & Update Inventory
                </button>
            </div>

            <!-- Step 3: Success -->
            <div id="step3" style="display: none;">
                <div class="alert alert-success">
                    <div style="text-align: center; padding: 20px 0;">
                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" style="margin: 0 auto 20px;">
                            <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                            <path d="M22 4L12 14.01l-3-3"/>
                        </svg>
                        <h2 style="margin: 0 0 12px 0; color: #065f46;">Receipt Confirmed!</h2>
                        <p style="margin: 0; color: #065f46;" id="successMessage"></p>
                    </div>
                </div>

                <div id="receiptSummary" style="background: white; border: 1px solid #e5e7eb; border-radius: 8px; padding: 20px; margin-top: 20px;"></div>

                <button onclick="window.location.href='dashboard.php'" class="btn btn-primary" style="margin-top: 20px;">
                    Return to Dashboard
                </button>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay">
        <div class="loading-content">
            <div class="spinner"></div>
            <p style="margin: 0; color: #111827; font-weight: 600;">Processing...</p>
        </div>
    </div>

    <script>
        let currentPO = null;
        let currentToken = '<?php echo htmlspecialchars($token); ?>';
        let html5QrcodeScanner = null;
        let uploadedPhotos = [];

        // Initialize scanner if no token provided
        <?php if (empty($token)): ?>
        function initScanner() {
            html5QrcodeScanner = new Html5QrcodeScanner(
                "reader",
                { fps: 10, qrbox: { width: 250, height: 250 } },
                false
            );
            
            html5QrcodeScanner.render(onScanSuccess, onScanFailure);
        }

        function onScanSuccess(decodedText, decodedResult) {
            // Extract token from URL if scanned
            let token = decodedText;
            const match = decodedText.match(/token=([A-Z0-9\-]+)/);
            if (match) {
                token = match[1];
            }
            
            html5QrcodeScanner.clear();
            verifyToken(token);
        }

        function onScanFailure(error) {
            // Ignore scan failures (expected when no QR code in view)
        }

        initScanner();
        <?php else: ?>
        // Token provided in URL, verify it
        verifyToken(currentToken);
        <?php endif; ?>

        async function verifyManualToken() {
            const token = document.getElementById('manualToken').value.trim();
            if (!token) {
                alert('Please enter a token');
                return;
            }
            verifyToken(token);
        }

        async function verifyToken(token) {
            showLoading();
            
            try {
                const response = await fetch(`api/po-receiving.php?action=scan&token=${encodeURIComponent(token)}`);
                const result = await response.json();

                hideLoading();

                if (result.success) {
                    currentPO = result.data.po;
                    currentToken = token;
                    displayPOForReceiving(result.data);
                    document.getElementById('step1').style.display = 'none';
                    document.getElementById('step2').style.display = 'block';
                } else {
                    alert(result.error || 'Invalid QR code or PO not found');
                    if (html5QrcodeScanner) {
                        initScanner();
                    }
                }
            } catch (error) {
                hideLoading();
                console.error('Error verifying token:', error);
                alert('Failed to verify QR code. Please try again.');
            }
        }

        function displayPOForReceiving(data) {
            const po = data.po;
            const supplier = data.supplier;

            // PO Info
            document.getElementById('poInfo').innerHTML = `
                <div class="alert alert-info">
                    <strong>PO #${escapeHtml(po.poNumber)}</strong><br>
                    Supplier: ${escapeHtml(po.supplierName)}<br>
                    Order Date: ${formatDate(po.orderDate)}<br>
                    Total: ${formatCurrency(po.total)}
                </div>
            `;

            // Items List
            const itemsHtml = po.items.map((item, index) => `
                <div class="item-card" data-index="${index}">
                    <div class="item-header">
                        <div>
                            <div class="item-name">${escapeHtml(item.productName)}</div>
                            <div class="item-sku">SKU: ${escapeHtml(item.sku || 'N/A')}</div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-weight: 600;">Ordered: ${item.quantity} ${item.unit || 'pcs'}</div>
                            <div style="font-size: 14px; color: #6b7280;">${formatCurrency(item.unitCost)} each</div>
                        </div>
                    </div>
                    <div class="quantity-inputs">
                        <div class="form-group" style="margin: 0;">
                            <label style="font-size: 14px;">Delivered:</label>
                            <input type="number" 
                                   id="delivered_${index}" 
                                   class="delivered-input"
                                   value="${item.quantity}" 
                                   min="0" 
                                   max="${item.quantity * 1.1}"
                                   onchange="updateAccepted(${index})"
                                   style="padding: 8px;">
                        </div>
                        <div class="form-group" style="margin: 0;">
                            <label style="font-size: 14px;">Accepted:</label>
                            <input type="number" 
                                   id="accepted_${index}" 
                                   class="accepted-input"
                                   value="${item.quantity}" 
                                   min="0"
                                   onchange="updateSummary()"
                                   style="padding: 8px;">
                        </div>
                    </div>
                </div>
            `).join('');

            document.getElementById('itemsList').innerHTML = itemsHtml;
            updateSummary();
        }

        function updateAccepted(index) {
            const delivered = parseFloat(document.getElementById(`delivered_${index}`).value) || 0;
            document.getElementById(`accepted_${index}`).value = delivered;
            updateSummary();
        }

        function updateSummary() {
            let totalDelivered = 0;
            let totalAccepted = 0;
            let totalRejected = 0;

            currentPO.items.forEach((item, index) => {
                const delivered = parseFloat(document.getElementById(`delivered_${index}`).value) || 0;
                const accepted = parseFloat(document.getElementById(`accepted_${index}`).value) || 0;
                totalDelivered += delivered;
                totalAccepted += accepted;
                totalRejected += (delivered - accepted);
            });

            document.getElementById('receivingSummary').innerHTML = `
                <div class="summary-row">
                    <span>Total Items Delivered:</span>
                    <span>${totalDelivered}</span>
                </div>
                <div class="summary-row">
                    <span>Total Items Accepted:</span>
                    <span>${totalAccepted}</span>
                </div>
                <div class="summary-row">
                    <span>Total Items Rejected:</span>
                    <span style="color: ${totalRejected > 0 ? '#dc2626' : '#6b7280'}">${totalRejected}</span>
                </div>
            `;
        }

        // Photo handling
        document.getElementById('photoInput').addEventListener('change', function(e) {
            const files = Array.from(e.target.files);
            files.forEach(file => {
                const reader = new FileReader();
                reader.onload = (e) => {
                    uploadedPhotos.push({
                        data: e.target.result,
                        name: file.name,
                        timestamp: new Date().toISOString()
                    });
                    displayPhotoPreview();
                };
                reader.readAsDataURL(file);
            });
        });

        function displayPhotoPreview() {
            const preview = document.getElementById('photoPreview');
            preview.innerHTML = uploadedPhotos.map((photo, index) => `
                <div style="position: relative;">
                    <img src="${photo.data}" alt="Damage evidence ${index + 1}">
                    <button onclick="removePhoto(${index})" 
                            style="position: absolute; top: 4px; right: 4px; background: #ef4444; color: white; border: none; border-radius: 50%; width: 24px; height: 24px; cursor: pointer; font-size: 12px; display: flex; align-items: center; justify-content: center;">
                        ×
                    </button>
                </div>
            `).join('');
        }

        function removePhoto(index) {
            uploadedPhotos.splice(index, 1);
            displayPhotoPreview();
        }

        async function confirmReceiving() {
            if (!confirm('Confirm receiving these items? Inventory will be updated immediately.')) {
                return;
            }

            const items = currentPO.items.map((item, index) => ({
                productId: item.productId,
                productName: item.productName,
                sku: item.sku,
                unit: item.unit,
                unitCost: item.unitCost,
                quantityOrdered: item.quantity,
                quantityDelivered: parseFloat(document.getElementById(`delivered_${index}`).value) || 0,
                quantityAccepted: parseFloat(document.getElementById(`accepted_${index}`).value) || 0
            }));

            const data = {
                poId: currentPO.id,
                qrToken: currentToken,
                items: items,
                remarks: document.getElementById('remarks').value,
                damagePhotos: uploadedPhotos
            };

            showLoading();

            try {
                const response = await fetch('api/po-receiving.php?action=confirm-receiving', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });

                const result = await response.json();
                hideLoading();

                if (result.success) {
                    displaySuccess(result.data.por);
                } else {
                    alert(result.error || 'Failed to confirm receiving');
                }
            } catch (error) {
                hideLoading();
                console.error('Error confirming receiving:', error);
                alert('Failed to confirm receiving. Please try again.');
            }
        }

        function displaySuccess(por) {
            document.getElementById('successMessage').textContent = 
                `Receiving ${por.receivingNumber} completed successfully! Inventory has been updated.`;

            document.getElementById('receiptSummary').innerHTML = `
                <h3 style="margin: 0 0 16px 0;">Receipt Summary</h3>
                <div style="margin-bottom: 12px;"><strong>Receipt #:</strong> ${por.receivingNumber}</div>
                <div style="margin-bottom: 12px;"><strong>PO #:</strong> ${por.poNumber}</div>
                <div style="margin-bottom: 12px;"><strong>Supplier:</strong> ${por.supplierName}</div>
                <div style="margin-bottom: 12px;"><strong>Items Received:</strong> ${por.totalAccepted}</div>
                <div style="margin-bottom: 12px;"><strong>Items Rejected:</strong> ${por.totalRejected || 0}</div>
                <div style="margin-bottom: 12px;"><strong>Total Value:</strong> ${formatCurrency(por.totalValue)}</div>
                <div style="margin-bottom: 12px;"><strong>Received By:</strong> ${por.receivedByName}</div>
                <div style="margin-bottom: 12px;"><strong>Date:</strong> ${formatDate(por.receivedDate)}</div>
            `;

            document.getElementById('step2').style.display = 'none';
            document.getElementById('step3').style.display = 'block';
        }

        function showLoading() {
            document.getElementById('loadingOverlay').style.display = 'flex';
            document.getElementById('confirmBtn').disabled = true;
        }

        function hideLoading() {
            document.getElementById('loadingOverlay').style.display = 'none';
            document.getElementById('confirmBtn').disabled = false;
        }

        function formatDate(isoDate) {
            if (!isoDate) return 'N/A';
            const date = new Date(isoDate);
            return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
        }

        function formatCurrency(amount) {
            return '₱' + parseFloat(amount || 0).toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
    </script>
</body>
</html>
