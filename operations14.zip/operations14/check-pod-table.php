<?php
require_once 'config/database.php';

try {
    $db = getDB();
    
    // Check if proof_of_delivery table exists
    $stmt = $db->query("SHOW TABLES LIKE 'proof_of_delivery'");
    $exists = $stmt->fetch();
    
    if ($exists) {
        echo "✓ proof_of_delivery table EXISTS\n\n";
        
        // Show table structure
        $stmt = $db->query("DESCRIBE proof_of_delivery");
        $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo "Table structure:\n";
        foreach ($columns as $col) {
            echo "  - {$col['Field']} ({$col['Type']})\n";
        }
        
        // Count records
        $stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_delivery");
        $count = $stmt->fetch();
        echo "\nRecords: {$count['count']}\n";
        
    } else {
        echo "✗ proof_of_delivery table DOES NOT EXIST\n";
        echo "Run panel-revisions-migration.sql to create it.\n";
    }
    
    // Check stock_transfers table
    echo "\n--- Stock Transfers ---\n";
    $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfers");
    $count = $stmt->fetch();
    echo "Stock transfers in database: {$count['count']}\n";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
