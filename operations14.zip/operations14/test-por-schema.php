<?php
require_once 'config/database.php';

$db = getDB();

echo "Checking proof_of_receiving table...\n\n";

// Check if table exists
$stmt = $db->query("SHOW TABLES LIKE 'proof_of_receiving'");
$tableExists = $stmt->fetch();

if ($tableExists) {
    echo "✓ Table 'proof_of_receiving' EXISTS\n\n";
    
    // Show table structure
    echo "Table Structure:\n";
    echo "================\n";
    $columns = $db->query("DESCRIBE proof_of_receiving")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo "{$col['Field']} - {$col['Type']} - {$col['Null']} - {$col['Key']}\n";
    }
} else {
    echo "✗ Table 'proof_of_receiving' DOES NOT EXIST\n";
    echo "Need to create table!\n";
}

echo "\n\nChecking proof_of_receiving_items table...\n\n";

$stmt = $db->query("SHOW TABLES LIKE 'proof_of_receiving_items'");
$itemsTableExists = $stmt->fetch();

if ($itemsTableExists) {
    echo "✓ Table 'proof_of_receiving_items' EXISTS\n";
} else {
    echo "✗ Table 'proof_of_receiving_items' DOES NOT EXIST\n";
}
?>
