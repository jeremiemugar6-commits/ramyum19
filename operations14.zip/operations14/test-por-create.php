<?php
require_once 'config/database.php';
require_once 'includes/auth.php';

$db = getDB();

echo "Testing POR Creation...\n\n";

// Simulate creating a POR
try {
    $porNumber = "POR-2026-TEST";
    $porId = generate_id('por');
    
    echo "Generated POR ID: $porId\n";
    echo "POR Number: $porNumber\n\n";
    
    $stmt = $db->prepare("
        INSERT INTO proof_of_receiving (
            id, por_number, purchase_order_id, po_number,
            supplier_id, supplier_name, receiving_date, receiving_time,
            status, received_by, received_by_name,
            remarks, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), 'Draft', ?, ?, ?, NOW(), NOW())
    ");
    
    $result = $stmt->execute([
        $porId,
        $porNumber,
        'demo_po_001',
        'PO-2026-0001',
        's1',
        'Seoul Food Distribution',
        'u1',
        'Test User',
        'Test creation'
    ]);
    
    if ($result) {
        echo "✓ POR Created Successfully!\n\n";
        
        // Fetch it back
        $fetchStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $fetchStmt->execute([$porId]);
        $por = $fetchStmt->fetch(PDO::FETCH_ASSOC);
        
        echo "Created POR Details:\n";
        print_r($por);
        
        // Clean up test record
        $db->prepare("DELETE FROM proof_of_receiving WHERE id = ?")->execute([$porId]);
        echo "\n✓ Test record cleaned up\n";
    } else {
        echo "✗ Failed to create POR\n";
    }
    
} catch (Exception $e) {
    echo "✗ Error: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
?>
