<?php
/**
 * Check ALL Pending POR Records
 */

require_once __DIR__ . '/config/database.php';

$db = getDB();

// Get ALL Pending records
$stmt = $db->query("
    SELECT 
        por_number,
        inspection_status,
        status,
        received_by_name,
        total_accepted,
        total_rejected,
        total_received,
        inventory_updated
    FROM proof_of_receiving 
    WHERE inspection_status IN ('Pending', 'Pending Inspection')
    ORDER BY created_at DESC
");

$pendingRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "<h2>ALL Pending POR Records</h2>";
echo "<p>Found <strong>" . count($pendingRecords) . "</strong> Pending records</p>";

if (count($pendingRecords) > 0) {
    echo "<table border='1' cellpadding='10' style='border-collapse:collapse; width:100%;'>";
    echo "<tr style='background:#f0f0f0;'>
            <th>POR #</th>
            <th>Inspection Status</th>
            <th>Record Status</th>
            <th>Received By</th>
            <th>Accepted</th>
            <th>Rejected</th>
            <th>Received</th>
            <th>Inventory Updated</th>
          </tr>";
    
    foreach ($pendingRecords as $rec) {
        echo "<tr>";
        echo "<td>{$rec['por_number']}</td>";
        echo "<td style='color:#F59E0B; font-weight:bold;'>{$rec['inspection_status']}</td>";
        echo "<td>{$rec['status']}</td>";
        echo "<td><strong>{$rec['received_by_name']}</strong></td>";
        echo "<td style='color:#10B981;'>{$rec['total_accepted']}</td>";
        echo "<td style='color:#EF4444;'>{$rec['total_rejected']}</td>";
        echo "<td>{$rec['total_received']}</td>";
        echo "<td>" . ($rec['inventory_updated'] ? '✓ Yes' : '✗ No') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Show fix button
    echo "<div style='margin:30px 0;'>";
    echo "<form method='POST' action='fix-all-pending.php'>";
    echo "<button type='submit' style='padding:12px 24px; background:#10B981; color:white; border:none; border-radius:8px; font-size:1.1rem; font-weight:600; cursor:pointer;'>";
    echo "Update ALL These Pending Records to Passed";
    echo "</button>";
    echo "</form>";
    echo "</div>";
    
} else {
    echo "<p style='color:green;'>✓ No Pending records found!</p>";
}

// Show status summary
echo "<h3>Complete Status Summary:</h3>";
$stmt = $db->query("
    SELECT 
        inspection_status,
        COUNT(*) as count,
        SUM(total_accepted) as total_accepted,
        SUM(total_rejected) as total_rejected
    FROM proof_of_receiving 
    GROUP BY inspection_status
    ORDER BY count DESC
");

echo "<table border='1' cellpadding='10' style='border-collapse:collapse;'>";
echo "<tr style='background:#f0f0f0;'>
        <th>Status</th>
        <th>Count</th>
        <th>Total Accepted</th>
        <th>Total Rejected</th>
      </tr>";

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td><strong>{$row['inspection_status']}</strong></td>";
    echo "<td>{$row['count']}</td>";
    echo "<td style='color:#10B981;'>{$row['total_accepted']}</td>";
    echo "<td style='color:#EF4444;'>{$row['total_rejected']}</td>";
    echo "</tr>";
}

echo "</table>";
?>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 1200px;
        margin: 50px auto;
        padding: 20px;
        background: #f5f5f5;
    }
    h2 {
        color: #333;
        border-bottom: 3px solid #FF7A00;
        padding-bottom: 10px;
    }
</style>
