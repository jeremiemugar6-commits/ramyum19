<?php
/**
 * Test POR Creation with Cached Input Fix
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "TEST: POR Creation with Cached Input\n";
echo str_repeat("=", 80) . "\n\n";

// Find a receiving without POR
$stmt = $db->query("
    SELECT r.id
    FROM receivings r
    LEFT JOIN proof_of_receiving por ON r.id = por.receiving_id
    WHERE por.id IS NULL
    LIMIT 1
");
$receiving = $stmt->fetch();

if (!$receiving) {
    echo "All receivings have PORs. Test with duplicate prevention.\n";
    $stmt = $db->query("SELECT id FROM receivings LIMIT 1");
    $receiving = $stmt->fetch();
    echo "Receiving ID: {$receiving['id']} (will show 'already exists' error)\n";
} else {
    echo "Found receiving without POR: {$receiving['id']}\n";
}

echo "\nSimulating API request flow:\n";
echo str_repeat("-", 80) . "\n";

// Simulate the fix: read JSON input once and cache it
$jsonInput = [
    'action' => 'create-from-receiving',
    'receiving_id' => $receiving['id']
];

echo "1. First call to get_json_input() to extract action\n";
$cachedInput = $jsonInput;
$action = $cachedInput['action'] ?? '';
echo "   Action extracted: '$action'\n\n";

echo "2. Second call to get_json_input() inside createPORFromReceiving()\n";
// Simulate what happens in the function
$input2 = $cachedInput;  // This should return cached input, not empty
echo "   Input received: " . json_encode($input2) . "\n";
echo "   Receiving ID: " . ($input2['receiving_id'] ?? 'MISSING') . "\n\n";

if (isset($input2['receiving_id']) && !empty($input2['receiving_id'])) {
    echo "✓ SUCCESS! Cached input is accessible\n";
    echo "✓ The fix prevents php://input being read twice\n";
    echo "✓ POR creation should now work\n";
} else {
    echo "✗ FAILED! Input is empty\n";
    echo "✗ php://input was already consumed\n";
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "CONCLUSION:\n";
echo "The fix caches the JSON input in \$cachedInput global variable,\n";
echo "allowing get_json_input() to return the same data on subsequent calls.\n";
echo "\nThis solves the 'Unexpected token <' error caused by empty response.\n";
