<?php
/**
 * Test POR API endpoint directly
 * Simulates API call without HTTP
 */

// Simulate API environment
$_SERVER['REQUEST_METHOD'] = 'POST';
$_GET['action'] = 'create';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';

// Simulate logged-in user
$_SESSION['user_id'] = 'u1';
$_SESSION['user'] = [
    'id' => 'u1',
    'email' => 'admin@ramyum.com',
    'name' => 'Admin User',
    'role' => 'admin'
];

// Simulate JSON input
$testInput = [
    'purchaseOrderId' => 'demo_po_001',
    'poNumber' => 'PO-2026-0001',
    'supplierId' => 's1',
    'supplierName' => 'Seoul Food Distribution',
    'notes' => 'API Test'
];

file_put_contents('php://input', json_encode($testInput));

// Capture output
ob_start();

try {
    // Include the API file
    include 'api/proof-of-receiving.php';
    
    $output = ob_get_clean();
    
    echo "API Response:\n";
    echo "=============\n";
    echo $output . "\n\n";
    
    // Parse response
    $response = json_decode($output, true);
    
    if ($response && $response['success']) {
        echo "✓ API Call Successful!\n";
        echo "POR ID: " . $response['data']['id'] . "\n";
        echo "POR Number: " . $response['data']['por_number'] . "\n";
        
        // Clean up
        require_once 'config/database.php';
        $db = getDB();
        $db->prepare("DELETE FROM proof_of_receiving WHERE id = ?")->execute([$response['data']['id']]);
        echo "\n✓ Test record cleaned up\n";
    } else {
        echo "✗ API Call Failed\n";
        if ($response) {
            echo "Error: " . ($response['error'] ?? 'Unknown error') . "\n";
        }
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo "✗ Exception: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
}
?>
