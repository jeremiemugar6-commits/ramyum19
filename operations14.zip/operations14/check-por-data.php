<?php
require_once 'config/database.php';

$db = getDB();

echo "=== POR Database Check ===\n\n";

// Check if table exists
try {
    $stmt = $db->query('SHOW TABLES LIKE "proof_of_receiving"');
    $tableExists = $stmt->fetch();
    
    if ($tableExists) {
        echo "✓ Table 'proof_of_receiving' exists\n\n";
        
        // Count records
        $stmt = $db->query('SELECT COUNT(*) as count FROM proof_of_receiving');
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        echo "Total POR Records: " . $result['count'] . "\n\n";
        
        if ($result['count'] > 0) {
            // Show sample records
            echo "Sample POR Records:\n";
            echo str_repeat("-", 80) . "\n";
            $stmt = $db->query('SELECT por_number, status, inspection_status, total_received, total_accepted, total_rejected FROM proof_of_receiving LIMIT 5');
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo json_encode($row, JSON_PRETTY_PRINT) . "\n";
            }
        } else {
            echo "⚠ No POR records found in database\n";
            echo "The table exists but has no data.\n";
        }
    } else {
        echo "✗ Table 'proof_of_receiving' DOES NOT exist\n";
        echo "The POR module requires the table to be created.\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}

echo "\n=== End Check ===\n";
