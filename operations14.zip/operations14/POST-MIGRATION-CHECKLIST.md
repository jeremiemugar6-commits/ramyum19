# Post-Migration Testing Checklist

## Overview
This checklist ensures all functionality works correctly after consolidating to the `ram_yum_inventory` centralized database.

## 🔍 Pre-Testing Validation

### ✅ Database Configuration Check
- [ ] Run `/verify-database-config.php` - all checks should pass
- [ ] Database name is `ram_yum_inventory` (not `ramyum_db`)
- [ ] `get_database_connection()` function works (backward compatibility)
- [ ] All required tables exist (14 tables total)
- [ ] `stock_transfer_audit` table has correct structure (action_type, user_id, user_name, details JSON)

### ✅ Database Integration Test  
- [ ] Run `/test-database-integration.php` - all 8 tests should pass
- [ ] Connection test successful
- [ ] JSON document storage working
- [ ] Security logging function operational
- [ ] Data integrity checks passed

### ✅ System Functionality Test
- [ ] Run `/test-system-functionality.php` - all module tests should pass
- [ ] Authentication module: 3/3 tests pass
- [ ] Inventory module: 3/3 tests pass
- [ ] Stock Transfer module: 2/2 tests pass
- [ ] API module: 2/2 tests pass
- [ ] Security module: 2/2 tests pass

## 🧪 Manual Functionality Testing

### 1. Authentication & User Management
- [ ] **Login Test**: Access `/index.php`
  - [ ] Login with `admin` / `Admin@123` works
  - [ ] Login with `staff` / `Staff@123` works
  - [ ] Login with `manager` / `Manager@123` works (if exists)
  - [ ] Failed login attempts are tracked
  - [ ] Redirects to dashboard after successful login

- [ ] **User Session**: Access `/dashboard.php`
  - [ ] Dashboard loads without errors
  - [ ] User profile displays correctly
  - [ ] Role-based navigation visible
  - [ ] Logout functionality works

- [ ] **Password Management**: Test change password
  - [ ] Current password validation works
  - [ ] New password is hashed and stored
  - [ ] Can login with new password

### 2. Product & Inventory Management
- [ ] **Product Catalog**: Access Products section
  - [ ] Products list displays correctly
  - [ ] JSON data renders properly (name, price, category)
  - [ ] Search functionality works
  - [ ] Product details view functional
  - [ ] Add new product works (if permissions allow)
  - [ ] Edit existing product works

- [ ] **Categories & Suppliers**: Test master data
  - [ ] Categories list displays
  - [ ] Suppliers list displays
  - [ ] JSON data extraction working
  - [ ] Add/Edit functionality works

- [ ] **Inventory by Location**:
  - [ ] Inventory locations display
  - [ ] Stock levels show correctly
  - [ ] Available vs Reserved quantities accurate
  - [ ] Location-based filtering works

### 3. Stock Transfer Operations
- [ ] **Create Stock Transfer**:
  - [ ] Location dropdowns populate (minimum 4 locations)
  - [ ] Source inventory displays correctly
  - [ ] Item selection works
  - [ ] Quantity validation prevents overselling
  - [ ] Transfer number generates automatically
  - [ ] Submit for approval works

- [ ] **Approval Workflow**:
  - [ ] Manager/Admin can see pending approvals
  - [ ] Approve transfer functionality works
  - [ ] Reject transfer with reason works
  - [ ] Email notifications sent (if configured)

- [ ] **Transfer Execution**:
  - [ ] Approved transfers can be executed
  - [ ] Source inventory decreases correctly
  - [ ] Destination inventory increases correctly
  - [ ] Inventory movements logged properly

- [ ] **Audit Trail**:
  - [ ] Stock transfer audit records created
  - [ ] Action types correct (TRANSFER_CREATED, TRANSFER_APPROVED, etc.)
  - [ ] User information captured (user_id, user_name)
  - [ ] JSON details field populated
  - [ ] IP addresses logged
  - [ ] Timestamps accurate

### 4. Purchase Orders & Receiving
- [ ] **Purchase Orders**:
  - [ ] Create new PO works
  - [ ] Supplier selection functional
  - [ ] Product selection from catalog
  - [ ] PO approval workflow
  - [ ] PO status tracking

- [ ] **Receiving Process**:
  - [ ] Receive against PO works
  - [ ] Quantity validation
  - [ ] Inventory updates after receiving
  - [ ] Movement records created
  - [ ] PO status updated

### 5. Reporting & Analytics
- [ ] **Inventory Reports**:
  - [ ] Current stock levels report
  - [ ] Low stock alerts
  - [ ] Movement history report
  - [ ] JSON queries perform adequately

- [ ] **Stock Transfer Reports**:
  - [ ] Transfer history displays
  - [ ] Status filtering works
  - [ ] Date range filtering
  - [ ] Export functionality (if available)

- [ ] **AI Analytics** (if configured):
  - [ ] Inventory predictions table accessible
  - [ ] Prediction data displays
  - [ ] Historical vs predicted quantities

### 6. API Endpoints Testing
- [ ] **Data API**: Test `/api/data.php`
  - [ ] GET requests for all collections work
  - [ ] Products: `/api/data.php?collection=products`
  - [ ] Suppliers: `/api/data.php?collection=suppliers`
  - [ ] Categories: `/api/data.php?collection=categories`
  - [ ] POST requests create records
  - [ ] PUT requests update records
  - [ ] DELETE requests remove records

- [ ] **Stock Transfer API**: Test `/api/stock-transfers.php`
  - [ ] GET locations: `/api/stock-transfers.php?action=locations`
  - [ ] GET transfers: `/api/stock-transfers.php?action=transfers`
  - [ ] GET inventory: `/api/stock-transfers.php?action=inventory&locationId=loc1`
  - [ ] POST create transfer works
  - [ ] POST approve/reject works
  - [ ] Audit logging via API functions

- [ ] **Authentication API**:
  - [ ] Login API functional
  - [ ] OTP generation/verification (if enabled)
  - [ ] Session management
  - [ ] Password change API

### 7. Security & Error Handling
- [ ] **Security Logging**:
  - [ ] Security events logged to database
  - [ ] Login attempts tracked
  - [ ] Failed login lockout works
  - [ ] Admin can view security logs

- [ ] **Error Handling**:
  - [ ] Database connection errors handled gracefully
  - [ ] JSON parsing errors don't crash system
  - [ ] Invalid data input validation works
  - [ ] SQL injection protection active

- [ ] **Performance**:
  - [ ] Page load times acceptable
  - [ ] JSON queries perform well
  - [ ] Large dataset handling
  - [ ] Memory usage reasonable

## 🚨 Issues & Troubleshooting

### Common Issues After Migration

1. **Database Connection Errors**
   - Check `config/database.php` has correct database name
   - Ensure MySQL server is running
   - Verify database exists and has correct permissions

2. **Stock Transfer Audit Errors**
   - Run `/migrate-to-centralized-db.php` to fix table structure
   - Check for old column names (action, performed_by) vs new (action_type, user_id)

3. **Missing Data**
   - Migration may not have completed
   - Check original database still exists for re-migration
   - Verify foreign key relationships intact

4. **JSON Data Issues**
   - Check for invalid JSON in data columns
   - Verify JSON_EXTRACT queries working
   - Ensure character encoding is UTF-8

5. **Authentication Problems**
   - Verify user table structure
   - Check password hashes are preserved
   - Ensure session handling works

### Performance Issues

1. **Slow JSON Queries**
   - Add indexes on frequently queried JSON fields
   - Consider extracting frequently used JSON fields to regular columns
   - Use MySQL 8.0+ JSON functions for better performance

2. **Large Dataset Problems**
   - Implement pagination for large tables
   - Archive old transaction data
   - Consider table partitioning

## ✅ Sign-off Checklist

Before marking the migration complete, ensure:

- [ ] All manual tests completed successfully
- [ ] No critical errors in any module
- [ ] Performance is acceptable
- [ ] All user roles can access their required functions
- [ ] Data integrity verified (compare record counts pre/post migration)
- [ ] Backup strategy implemented for new database
- [ ] Team trained on any changes
- [ ] Documentation updated

## 📊 Migration Success Criteria

### Required (Must Pass)
- ✅ Database connection works
- ✅ User authentication functional
- ✅ Stock transfer workflow complete
- ✅ No data loss from original system
- ✅ All API endpoints respond correctly

### Optional (Should Pass)
- ✅ Performance equivalent to original system
- ✅ All reporting functions work
- ✅ Email notifications functional (if configured)
- ✅ Legacy SQL files archived
- ✅ Team comfortable with changes

## 📝 Testing Notes

**Date**: _______________  
**Tester**: _______________  
**Environment**: _______________  

**Overall Result**: ⚠️ PENDING / ✅ PASSED / ❌ FAILED

**Critical Issues Found**:
- 
- 
- 

**Minor Issues Found**:
- 
- 
- 

**Performance Notes**:
- 
- 

**Recommendations**:
- 
- 
- 

**Sign-off**: _______________  **Date**: _______________