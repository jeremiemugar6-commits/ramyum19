<?php
/**
 * Setup Demo Data for Panel Revisions
 * Creates sample stock transfers with units, POD records, and demonstration data
 */

require_once __DIR__ . '/config/database.php';

echo "=============================================================\n";
echo "RAM-YUM PANEL REVISIONS - DEMO DATA SETUP\n";
echo "=============================================================\n\n";

try {
    $pdo = getDBConnection();
    echo "✓ Database connection established\n\n";

    // Sample Stock Transfers with Units
    echo "Step 1: Creating sample stock transfers with units...\n";
    
    $sampleTransfers = [
        [
            'id' => 'st_demo_rev_001',
            'transferNumber' => 'ST-2026-0010',
            'sourceLocationId' => 'loc1',
            'sourceName' => 'Main Warehouse',
            'destinationLocationId' => 'loc2',
            'destinationName' => 'Branch 1 - Makati',
            'status' => 'Approved',
            'items' => [
                [
                    'productId' => 'p1',
                    'productName' => 'Samyang Buldak Original',
                    'sku' => 'SB-001',
                    'quantity' => 25,
                    'unit' => 'Pack'
                ],
                [
                    'productId' => 'p2',
                    'productName' => 'Shin Ramyun',
                    'sku' => 'SR-002',
                    'quantity' => 30,
                    'unit' => 'Pack'
                ]
            ],
            'transferDate' => date('Y-m-d\TH:i:s.000\Z', strtotime('-2 days')),
            'requestedBy' => 'Admin User',
            'approvedBy' => 'Admin User',
            'approvedAt' => date('Y-m-d\TH:i:s.000\Z', strtotime('-2 days')),
            'totalItems' => 55,
            'notes' => 'Regular restocking for Makati branch'
        ],
        [
            'id' => 'st_demo_rev_002',
            'transferNumber' => 'ST-2026-0011',
            'sourceLocationId' => 'loc1',
            'sourceName' => 'Main Warehouse',
            'destinationLocationId' => 'loc3',
            'destinationName' => 'Branch 2 - Quezon City',
            'status' => 'Approved',
            'items' => [
                [
                    'productId' => 'DRK001',
                    'productName' => "Welch's Grape",
                    'sku' => 'DRK001',
                    'quantity' => 20,
                    'unit' => 'Bottle'
                ],
                [
                    'productId' => 'p10',
                    'productName' => 'Korean Seaweed Snack',
                    'sku' => 'KS-010',
                    'quantity' => 15,
                    'unit' => 'Box'
                ]
            ],
            'transferDate' => date('Y-m-d\TH:i:s.000\Z', strtotime('-1 day')),
            'requestedBy' => 'Staff User',
            'approvedBy' => 'Admin User',
            'approvedAt' => date('Y-m-d\TH:i:s.000\Z', strtotime('-1 day')),
            'totalItems' => 35,
            'notes' => 'QC branch monthly delivery'
        ],
        [
            'id' => 'st_demo_rev_003',
            'transferNumber' => 'ST-2026-0012',
            'sourceLocationId' => 'loc1',
            'sourceName' => 'Main Warehouse',
            'destinationLocationId' => 'loc4',
            'destinationName' => 'Storage Area - BGC',
            'status' => 'Pending Approval',
            'items' => [
                [
                    'productId' => 'p3',
                    'productName' => 'Ottogi Jin Ramen',
                    'sku' => 'OJ-003',
                    'quantity' => 40,
                    'unit' => 'Pack'
                ]
            ],
            'transferDate' => date('Y-m-d\TH:i:s.000\Z'),
            'requestedBy' => 'Staff User',
            'totalItems' => 40,
            'notes' => 'Overflow storage transfer'
        ]
    ];

    foreach ($sampleTransfers as $transfer) {
        $data = json_encode($transfer, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        
        // Check if exists
        $stmt = $pdo->prepare("SELECT id FROM stock_transfers WHERE id = ?");
        $stmt->execute([$transfer['id']]);
        
        if (!$stmt->fetch()) {
            $stmt = $pdo->prepare("INSERT INTO stock_transfers (id, data, created_at) VALUES (?, ?, NOW())");
            $stmt->execute([$transfer['id'], $data]);
            echo "  ✓ Created transfer: {$transfer['transferNumber']}\n";
        } else {
            echo "  ⚠ Transfer {$transfer['transferNumber']} already exists\n";
        }
    }

    // Create POD records for approved transfers
    echo "\nStep 2: Creating Proof of Delivery records...\n";
    
    $podRecords = [
        [
            'id' => 'pod_demo_001',
            'transfer_id' => 'st_demo_rev_001',
            'transfer_number' => 'ST-2026-0010',
            'qr_token' => 'POD-' . strtoupper(bin2hex(random_bytes(16))),
            'status' => 'Pending'
        ],
        [
            'id' => 'pod_demo_002',
            'transfer_id' => 'st_demo_rev_002',
            'transfer_number' => 'ST-2026-0011',
            'qr_token' => 'POD-' . strtoupper(bin2hex(random_bytes(16))),
            'status' => 'Pending'
        ]
    ];

    foreach ($podRecords as $pod) {
        $stmt = $pdo->prepare("SELECT id FROM proof_of_delivery WHERE id = ?");
        $stmt->execute([$pod['id']]);
        
        if (!$stmt->fetch()) {
            $stmt = $pdo->prepare("
                INSERT INTO proof_of_delivery (id, transfer_id, transfer_number, qr_token, status, created_at)
                VALUES (?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $pod['id'],
                $pod['transfer_id'],
                $pod['transfer_number'],
                $pod['qr_token'],
                $pod['status']
            ]);
            echo "  ✓ Created POD for {$pod['transfer_number']}\n";
            echo "    QR Token: {$pod['qr_token']}\n";
            echo "    Scan URL: " . "http://localhost/scan-pod.php?token={$pod['qr_token']}\n";
        } else {
            echo "  ⚠ POD for {$pod['transfer_number']} already exists\n";
        }
    }

    echo "\n";
    echo "=============================================================\n";
    echo "✓ DEMO DATA SETUP COMPLETED\n";
    echo "=============================================================\n";
    echo "\n";
    echo "Sample Data Created:\n";
    echo "- 3 Stock Transfers with units (Pack, Bottle, Box)\n";
    echo "- 2 POD records with QR tokens\n";
    echo "\n";
    echo "Next Steps:\n";
    echo "1. Test stock transfer workflow\n";
    echo "2. Generate QR codes for approved transfers\n";
    echo "3. Test POD scanning with QR tokens\n";
    echo "4. Verify units display in PO/Receiving/Stock Transfer\n";
    echo "\n";

} catch (Exception $e) {
    echo "\n";
    echo "=============================================================\n";
    echo "✗ SETUP FAILED\n";
    echo "=============================================================\n";
    echo "Error: " . $e->getMessage() . "\n";
    echo "\n";
    exit(1);
}
