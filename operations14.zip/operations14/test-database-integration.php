<?php
/**
 * Database Integration Test Script
 * Tests all major database operations with the centralized database
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);
set_time_limit(120);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Integration Test - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 4px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 4px; }
        .test-pass { border-left: 4px solid #28a745; }
        .test-fail { border-left: 4px solid #dc3545; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; }
        h1 { color: #FF7A00; }
    </style>
</head>
<body>
    <h1>🧪 Database Integration Tests</h1>
    <p>Testing all major database operations with the centralized <strong>ram_yum_inventory</strong> database.</p>

    <?php
    $testResults = [];
    $totalTests = 0;
    $passedTests = 0;

    function runTest($testName, $testFunction) {
        global $testResults, $totalTests, $passedTests;
        $totalTests++;
        
        try {
            $result = $testFunction();
            $passed = $result['success'] ?? false;
            $message = $result['message'] ?? 'Test completed';
            
            if ($passed) {
                $passedTests++;
                echo "<div class='test-section test-pass'>";
                echo "<h3>✅ $testName</h3>";
                echo "<div class='success'>$message</div>";
            } else {
                echo "<div class='test-section test-fail'>";
                echo "<h3>❌ $testName</h3>";
                echo "<div class='error'>$message</div>";
            }
            
            if (isset($result['details'])) {
                echo "<pre>" . htmlspecialchars($result['details']) . "</pre>";
            }
            
            echo "</div>";
            
            $testResults[] = ['name' => $testName, 'passed' => $passed, 'message' => $message];
            
        } catch (Exception $e) {
            echo "<div class='test-section test-fail'>";
            echo "<h3>❌ $testName</h3>";
            echo "<div class='error'>Exception: " . htmlspecialchars($e->getMessage()) . "</div>";
            echo "</div>";
            
            $testResults[] = ['name' => $testName, 'passed' => false, 'message' => $e->getMessage()];
        }
    }

    // Test 1: Basic Database Connection
    runTest('Database Connection', function() {
        $db = getDB();
        $result = $db->query("SELECT DATABASE() as db_name, VERSION() as version")->fetch();
        
        if ($result['db_name'] !== 'ram_yum_inventory') {
            return ['success' => false, 'message' => "Connected to wrong database: {$result['db_name']}"];
        }
        
        return [
            'success' => true, 
            'message' => "Successfully connected to ram_yum_inventory",
            'details' => "Database: {$result['db_name']}\nMySQL Version: {$result['version']}"
        ];
    });

    // Test 2: Backward Compatibility Function
    runTest('Backward Compatibility Function', function() {
        if (!function_exists('get_database_connection')) {
            return ['success' => false, 'message' => 'get_database_connection() function not found'];
        }
        
        $db1 = getDB();
        $db2 = get_database_connection();
        
        // Both should connect to the same database
        $name1 = $db1->query("SELECT DATABASE()")->fetchColumn();
        $name2 = $db2->query("SELECT DATABASE()")->fetchColumn();
        
        if ($name1 !== $name2) {
            return ['success' => false, 'message' => 'Functions connect to different databases'];
        }
        
        return [
            'success' => true,
            'message' => 'Backward compatibility function works correctly',
            'details' => "Both functions connect to: $name1"
        ];
    });

    // Test 3: Table Structure Validation
    runTest('Table Structure Validation', function() {
        $db = getDB();
        
        $requiredTables = [
            'users', 'login_attempts', 'otp_codes', 'security_logs',
            'categories', 'suppliers', 'products', 'locations', 
            'inventory_locations', 'inventory_movements',
            'purchase_orders', 'receivings', 'stock_transfers', 
            'stock_transfer_audit', 'stock_adjustments', 'inventory_predictions'
        ];
        
        $existingTables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        $missingTables = array_diff($requiredTables, $existingTables);
        
        if (!empty($missingTables)) {
            return [
                'success' => false, 
                'message' => 'Missing required tables',
                'details' => 'Missing: ' . implode(', ', $missingTables)
            ];
        }
        
        return [
            'success' => true,
            'message' => 'All required tables exist',
            'details' => 'Found ' . count($existingTables) . ' tables: ' . implode(', ', $existingTables)
        ];
    });

    // Test 4: Stock Transfer Audit Table Structure
    runTest('Stock Transfer Audit Table Structure', function() {
        $db = getDB();
        
        $columns = $db->query("SHOW COLUMNS FROM stock_transfer_audit")->fetchAll();
        $columnNames = array_column($columns, 'Field');
        
        $requiredColumns = ['id', 'transfer_id', 'action_type', 'user_id', 'user_name', 'details', 'ip_address', 'created_at'];
        $missingColumns = array_diff($requiredColumns, $columnNames);
        
        $oldColumns = array_intersect(['action', 'performed_by', 'performed_by_name'], $columnNames);
        
        if (!empty($missingColumns)) {
            return [
                'success' => false,
                'message' => 'Missing required columns in stock_transfer_audit',
                'details' => 'Missing: ' . implode(', ', $missingColumns)
            ];
        }
        
        if (!empty($oldColumns)) {
            return [
                'success' => false,
                'message' => 'Old problematic columns still exist',
                'details' => 'Old columns: ' . implode(', ', $oldColumns)
            ];
        }
        
        return [
            'success' => true,
            'message' => 'Stock transfer audit table has correct structure',
            'details' => 'Columns: ' . implode(', ', $columnNames)
        ];
    });

    // Test 5: User Authentication Data
    runTest('User Authentication Data', function() {
        $db = getDB();
        
        $userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
        if ($userCount == 0) {
            return ['success' => false, 'message' => 'No users found in database'];
        }
        
        $users = $db->query("SELECT id, name, email, role FROM users")->fetchAll();
        $roles = array_unique(array_column($users, 'role'));
        
        $requiredRoles = ['admin', 'manager', 'staff'];
        $missingRoles = array_diff($requiredRoles, $roles);
        
        if (!empty($missingRoles)) {
            return [
                'success' => false,
                'message' => 'Missing required user roles',
                'details' => 'Missing roles: ' . implode(', ', $missingRoles)
            ];
        }
        
        return [
            'success' => true,
            'message' => "Found $userCount users with all required roles",
            'details' => 'Users: ' . implode(', ', array_column($users, 'name')) . "\nRoles: " . implode(', ', $roles)
        ];
    });

    // Test 6: JSON Document Storage
    runTest('JSON Document Storage', function() {
        $db = getDB();
        
        // Test reading JSON data from products table
        $productCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
        if ($productCount == 0) {
            return ['success' => false, 'message' => 'No products found to test JSON storage'];
        }
        
        $product = $db->query("SELECT id, data FROM products LIMIT 1")->fetch();
        $productData = json_decode($product['data'], true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['success' => false, 'message' => 'Invalid JSON in products table'];
        }
        
        if (!isset($productData['id']) || !isset($productData['name'])) {
            return ['success' => false, 'message' => 'Product JSON missing required fields'];
        }
        
        return [
            'success' => true,
            'message' => 'JSON document storage working correctly',
            'details' => "Sample product: {$productData['name']} (ID: {$productData['id']})"
        ];
    });

    // Test 7: Security Logging Function
    runTest('Security Logging Function', function() {
        $db = getDB();
        
        $initialCount = $db->query("SELECT COUNT(*) FROM security_logs")->fetchColumn();
        
        // Test the log_security_event function
        log_security_event('TEST_EVENT', 'test_user', 'Test User', ['test' => 'data']);
        
        $newCount = $db->query("SELECT COUNT(*) FROM security_logs")->fetchColumn();
        
        if ($newCount <= $initialCount) {
            return ['success' => false, 'message' => 'Security logging function not working'];
        }
        
        $lastLog = $db->query("SELECT event_type, user_id, username FROM security_logs ORDER BY created_at DESC LIMIT 1")->fetch();
        
        if ($lastLog['event_type'] !== 'TEST_EVENT' || $lastLog['user_id'] !== 'test_user') {
            return ['success' => false, 'message' => 'Security log data incorrect'];
        }
        
        return [
            'success' => true,
            'message' => 'Security logging function working correctly',
            'details' => "Logged event: {$lastLog['event_type']} by {$lastLog['username']}"
        ];
    });

    // Test 8: Data Integrity Checks
    runTest('Data Integrity Checks', function() {
        $db = getDB();
        
        $checks = [];
        
        // Check foreign key relationships
        $otpCount = $db->query("SELECT COUNT(*) FROM otp_codes")->fetchColumn();
        if ($otpCount > 0) {
            $orphanedOtps = $db->query("
                SELECT COUNT(*) FROM otp_codes o 
                LEFT JOIN users u ON o.user_id = u.id 
                WHERE u.id IS NULL
            ")->fetchColumn();
            
            if ($orphanedOtps > 0) {
                return ['success' => false, 'message' => "Found $orphanedOtps orphaned OTP records"];
            }
            $checks[] = "OTP foreign keys: OK";
        }
        
        // Check JSON data integrity
        $invalidJson = $db->query("
            SELECT COUNT(*) FROM products 
            WHERE data IS NULL OR NOT JSON_VALID(data)
        ")->fetchColumn();
        
        if ($invalidJson > 0) {
            return ['success' => false, 'message' => "Found $invalidJson products with invalid JSON"];
        }
        $checks[] = "Product JSON data: OK";
        
        return [
            'success' => true,
            'message' => 'All data integrity checks passed',
            'details' => implode("\n", $checks)
        ];
    });

    // Display Summary
    echo "<div class='test-section'>";
    echo "<h2>📊 Test Summary</h2>";
    
    $successRate = round(($passedTests / $totalTests) * 100, 1);
    
    if ($passedTests == $totalTests) {
        echo "<div class='success'>";
        echo "<strong>🎉 All Tests Passed!</strong><br>";
        echo "Passed: $passedTests/$totalTests ($successRate%)";
        echo "</div>";
        
        echo "<div class='info'>";
        echo "<strong>✅ Database Consolidation Complete</strong><br>";
        echo "• Centralized database: ram_yum_inventory<br>";
        echo "• All table structures correct<br>";
        echo "• Backward compatibility maintained<br>";
        echo "• Data integrity verified<br>";
        echo "• Application ready for use";
        echo "</div>";
        
    } else {
        $failedTests = $totalTests - $passedTests;
        echo "<div class='error'>";
        echo "<strong>⚠️ Some Tests Failed</strong><br>";
        echo "Passed: $passedTests/$totalTests ($successRate%)<br>";
        echo "Failed: $failedTests tests need attention";
        echo "</div>";
        
        echo "<div class='warning'>";
        echo "<strong>Action Required:</strong><br>";
        echo "1. Run the migration script: <code>/migrate-to-centralized-db.php</code><br>";
        echo "2. Check database configuration<br>";
        echo "3. Verify all required tables exist<br>";
        echo "4. Re-run this test";
        echo "</div>";
    }
    
    echo "</div>";

    // Detailed Results Table
    echo "<div class='test-section'>";
    echo "<h3>📋 Detailed Results</h3>";
    echo "<table>";
    echo "<tr><th>Test Name</th><th>Status</th><th>Message</th></tr>";
    
    foreach ($testResults as $result) {
        $status = $result['passed'] ? '✅ PASS' : '❌ FAIL';
        $statusClass = $result['passed'] ? 'success' : 'error';
        echo "<tr>";
        echo "<td>{$result['name']}</td>";
        echo "<td><span style='color:" . ($result['passed'] ? '#155724' : '#721c24') . ";'>$status</span></td>";
        echo "<td>{$result['message']}</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    echo "</div>";
    ?>

</body>
</html>