<?php
/**
 * Direct test of POR create functionality
 */

session_start();

// Set up test session
$_SESSION['user_id'] = 'u1';
$_SESSION['user'] = [
    'id' => 'u1',
    'email' => 'admin@ramyum.com',
    'name' => 'Admin User',
    'role' => 'admin'
];

require_once 'config/database.php';
require_once 'includes/auth.php';

$db = getDB();
$currentUser = [
    'id' => 'u1',
    'email' => 'admin@ramyum.com',
    'name' => 'Admin User',
    'role' => 'admin'
];

echo "Testing POR Create Function...\n\n";

function generatePORNumber($db) {
    $currentYear = date('Y');
    $stmt = $db->prepare("SELECT por_number FROM proof_of_receiving WHERE por_number LIKE ?");
    $stmt->execute(["POR-$currentYear-%"]);
    $results = $stmt->fetchAll();
    
    $maxNumber = 0;
    foreach ($results as $row) {
        if (preg_match("/POR-$currentYear-(\d{4})/", $row['por_number'], $matches)) {
            $maxNumber = max($maxNumber, intval($matches[1]));
        }
    }
    
    $nextNumber = str_pad($maxNumber + 1, 4, '0', STR_PAD_LEFT);
    return "POR-$currentYear-$nextNumber";
}

function logReceivingActivity($db, $porId, $actionType, $currentUser, $details) {
    try {
        $stmt = $db->prepare("
            INSERT INTO security_logs (event_type, user_id, username, details, ip_address, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $actionType,
            $currentUser['id'],
            $currentUser['name'],
            json_encode(array_merge($details, ['porId' => $porId])),
            '127.0.0.1'
        ]);
        echo "✓ Activity logged\n";
    } catch (Exception $e) {
        echo "⚠ Logging failed: " . $e->getMessage() . "\n";
    }
}

// Test input
$input = [
    'purchaseOrderId' => 'demo_po_001',
    'poNumber' => 'PO-2026-0001',
    'supplierId' => 's1',
    'supplierName' => 'Seoul Food Distribution',
    'notes' => 'Direct test'
];

echo "Input Data:\n";
print_r($input);
echo "\n";

try {
    $db->beginTransaction();
    
    // Generate POR number
    $porNumber = generatePORNumber($db);
    echo "Generated POR Number: $porNumber\n";
    
    // Verify PO exists
    $poStmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
    $poStmt->execute([$input['purchaseOrderId']]);
    $poResult = $poStmt->fetch();
    
    if (!$poResult) {
        throw new Exception('Purchase order not found');
    }
    echo "✓ Purchase Order found\n";

    $po = json_decode($poResult['data'], true);
    
    if ($po['status'] !== 'Approved') {
        throw new Exception('Purchase order must be approved before receiving');
    }
    echo "✓ Purchase Order is approved\n";

    // Create POR record
    $porId = generate_id('por');
    echo "Generated POR ID: $porId\n";
    
    $insertStmt = $db->prepare("
        INSERT INTO proof_of_receiving (
            id, por_number, purchase_order_id, po_number,
            supplier_id, supplier_name, receiving_date, receiving_time,
            status, received_by, received_by_name,
            remarks, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), 'Draft', ?, ?, ?, NOW(), NOW())
    ");
    
    $insertStmt->execute([
        $porId,
        $porNumber,
        $input['purchaseOrderId'],
        $input['poNumber'],
        $input['supplierId'],
        $input['supplierName'],
        $currentUser['id'],
        $currentUser['name'],
        $input['notes'] ?? null
    ]);
    
    echo "✓ POR record inserted\n";

    // Log activity
    logReceivingActivity($db, $porId, 'POR_CREATED', $currentUser, [
        'porNumber' => $porNumber,
        'poNumber' => $input['poNumber'],
        'supplier' => $input['supplierName']
    ]);

    $db->commit();
    echo "✓ Transaction committed\n\n";

    // Fetch created POR
    $newPORStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
    $newPORStmt->execute([$porId]);
    $newPOR = $newPORStmt->fetch(PDO::FETCH_ASSOC);

    echo "SUCCESS! POR Created:\n";
    echo "=====================\n";
    echo "ID: {$newPOR['id']}\n";
    echo "POR Number: {$newPOR['por_number']}\n";
    echo "PO Number: {$newPOR['po_number']}\n";
    echo "Supplier: {$newPOR['supplier_name']}\n";
    echo "Status: {$newPOR['status']}\n";
    echo "Created At: {$newPOR['created_at']}\n\n";
    
    // Clean up
    $db->prepare("DELETE FROM proof_of_receiving WHERE id = ?")->execute([$porId]);
    $db->prepare("DELETE FROM security_logs WHERE event_type = 'POR_CREATED' AND details LIKE ?")->execute(["%$porId%"]);
    echo "✓ Test record cleaned up\n";

} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
?>
