<?php
/**
 * Load Audit Trail Data for Stock Transfer Demo
 * Adds comprehensive audit trail entries for all demo scenarios
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

$currentUser = require_login_page();
if ($currentUser['role'] !== 'admin') {
    http_response_code(403);
    die('Access denied. Admin role required.');
}

echo "<!DOCTYPE html><html><head><title>Load Audit Trail Data</title>";
echo "<link rel='stylesheet' href='assets/css/main.css'>";
echo "<style>
    body { font-family: system-ui; margin: 40px; }
    .success { color: green; }
    .warning { color: orange; }
    .error { color: red; }
    .info { color: blue; }
    .container { max-width: 900px; margin: 0 auto; }
</style></head><body><div class='container'>";

echo "<h1>📊 Loading Audit Trail Data</h1>";
echo "<p>Adding comprehensive audit trail entries for all stock transfer demo scenarios...</p>";

try {
    $db = getDB();
    $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
    
    // First, let's ensure we have the comprehensive demo data
    echo "<h2>Step 1: Loading Comprehensive Demo Data</h2>";
    
    $comprehensiveFile = __DIR__ . '/database/stock-transfer-comprehensive-demo.sql';
    if (file_exists($comprehensiveFile)) {
        $sql = file_get_contents($comprehensiveFile);
        
        // Remove USE statements and split by semicolon
        $sql = preg_replace('/^USE\s+\w+\s*;/m', '', $sql);
        $statements = preg_split('/;\s*(?=(?:[^\'"]|\'[^\']*\'|"[^"]*")*$)/', $sql);
        $statements = array_filter(array_map('trim', $statements), function($stmt) {
            return !empty($stmt) && !preg_match('/^\s*--/', $stmt) && !preg_match('/^\s*\/\*/', $stmt);
        });
        
        $successCount = 0;
        $skipCount = 0;
        
        foreach ($statements as $statement) {
            if (trim($statement)) {
                try {
                    $db->exec($statement);
                    $successCount++;
                    
                    // Show meaningful progress for key operations
                    if (stripos($statement, 'INSERT INTO stock_transfers') !== false) {
                        preg_match("/'(ST-\d{4}-\d{4})'/", $statement, $matches);
                        $transferId = $matches[1] ?? 'Unknown';
                        echo "<p class='success'>✅ Added demo transfer: $transferId</p>";
                    } elseif (stripos($statement, 'INSERT INTO stock_transfer_audit') !== false) {
                        preg_match("/'(audit_\d{3})'/", $statement, $matches);
                        $auditId = $matches[1] ?? 'Unknown';
                        echo "<p class='success'>✅ Added audit entry: $auditId</p>";
                    } elseif (stripos($statement, 'INSERT INTO inventory_movements') !== false) {
                        echo "<p class='success'>✅ Added inventory movement record</p>";
                    }
                    
                } catch (PDOException $e) {
                    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                        $skipCount++;
                    } else {
                        echo "<p class='warning'>⚠ Warning: " . substr($statement, 0, 50) . "... - " . htmlspecialchars($e->getMessage()) . "</p>";
                    }
                }
            }
        }
        
        echo "<p class='info'>📈 Processed $successCount statements successfully, skipped $skipCount duplicates</p>";
        
    } else {
        echo "<p class='error'>❌ Comprehensive demo file not found. Creating audit trail manually...</p>";
        
        // Manual audit trail creation
        echo "<h2>Step 2: Creating Audit Trail Manually</h2>";
        
        $auditEntries = [
            // Urgent restock audit
            ['audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', 'DATE_SUB(NOW(), INTERVAL 2 HOUR)'],
            ['audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', 'DATE_SUB(NOW(), INTERVAL 2 HOUR)'],
            
            // New product launch audit
            ['audit_003', 'ST-2026-0102', 'CREATED', 'u3', 'Manager User', 'Transfer created for new product distribution', 'DATE_SUB(NOW(), INTERVAL 4 HOUR)'],
            ['audit_004', 'ST-2026-0102', 'SUBMITTED', 'u3', 'Manager User', 'Transfer submitted for admin approval', 'DATE_SUB(NOW(), INTERVAL 4 HOUR)'],
            
            // Completed transfer audit
            ['audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', 'DATE_SUB(NOW(), INTERVAL 1 DAY)'],
            ['audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', 'DATE_SUB(NOW(), INTERVAL 22 HOUR)'],
            ['audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', 'DATE_SUB(NOW(), INTERVAL 6 HOUR)'],
            ['audit_008', 'ST-2026-0103', 'COMPLETED', 'u2', 'Staff User', 'Inventory transfer completed successfully', 'DATE_SUB(NOW(), INTERVAL 4 HOUR)'],
            
            // Rejected transfer audit
            ['audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', 'DATE_SUB(NOW(), INTERVAL 2 DAY)'],
            ['audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', 'DATE_SUB(NOW(), INTERVAL 46 HOUR)'],
            ['audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', 'DATE_SUB(NOW(), INTERVAL 1 DAY)'],
            
            // Emergency transfer audit
            ['audit_012', 'ST-2026-0105', 'CREATED', 'u3', 'Manager User', 'Emergency transfer created for stockout situation', 'DATE_SUB(NOW(), INTERVAL 3 HOUR)'],
            ['audit_013', 'ST-2026-0105', 'SUBMITTED', 'u3', 'Manager User', 'Emergency transfer submitted for immediate approval', 'DATE_SUB(NOW(), INTERVAL 3 HOUR)'],
            ['audit_014', 'ST-2026-0105', 'APPROVED', 'u1', 'Admin User', 'Emergency transfer approved with fast-track priority', 'DATE_SUB(NOW(), INTERVAL 2 HOUR)']
        ];
        
        $insertSQL = "INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) VALUES (?, ?, ?, ?, ?, ?, DATE_FORMAT($6, '%Y-%m-%dT%H:%i:%s.000Z')) ON DUPLICATE KEY UPDATE id = id";
        $stmt = $db->prepare($insertSQL);
        
        foreach ($auditEntries as $entry) {
            try {
                $stmt->execute($entry);
                echo "<p class='success'>✅ Added audit: {$entry[0]} - {$entry[2]} action for {$entry[1]}</p>";
            } catch (PDOException $e) {
                echo "<p class='warning'>⚠ Audit {$entry[0]} already exists</p>";
            }
        }
    }
    
    // Step 3: Verification
    echo "<h2>Step 3: Verification</h2>";
    
    // Count audit entries
    $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfer_audit");
    $auditCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    echo "<p class='success'>✅ Total audit trail entries: $auditCount</p>";
    
    // Show audit trail summary by action
    $stmt = $db->query("
        SELECT action, COUNT(*) as count 
        FROM stock_transfer_audit 
        GROUP BY action 
        ORDER BY action
    ");
    $actionCounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<div style='background: #f9fafb; padding: 16px; border-radius: 8px; margin: 16px 0;'>";
    echo "<h3>📊 Audit Trail Summary</h3>";
    foreach ($actionCounts as $action) {
        echo "<p>• {$action['action']}: {$action['count']} entries</p>";
    }
    echo "</div>";
    
    // Show recent audit entries
    $stmt = $db->query("
        SELECT transfer_id, action, performed_by_name, details, created_at 
        FROM stock_transfer_audit 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $recentAudits = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($recentAudits) > 0) {
        echo "<div style='background: #f0f9ff; padding: 16px; border-radius: 8px; margin: 16px 0;'>";
        echo "<h3>📝 Recent Audit Entries</h3>";
        echo "<table style='width: 100%; border-collapse: collapse;'>";
        echo "<tr style='background: #e5e7eb;'><th style='padding: 8px; text-align: left;'>Transfer</th><th style='padding: 8px; text-align: left;'>Action</th><th style='padding: 8px; text-align: left;'>User</th><th style='padding: 8px; text-align: left;'>Details</th></tr>";
        
        foreach ($recentAudits as $audit) {
            echo "<tr>";
            echo "<td style='padding: 8px; border-bottom: 1px solid #e5e7eb;'>" . htmlspecialchars($audit['transfer_id']) . "</td>";
            echo "<td style='padding: 8px; border-bottom: 1px solid #e5e7eb;'>" . htmlspecialchars($audit['action']) . "</td>";
            echo "<td style='padding: 8px; border-bottom: 1px solid #e5e7eb;'>" . htmlspecialchars($audit['performed_by_name']) . "</td>";
            echo "<td style='padding: 8px; border-bottom: 1px solid #e5e7eb;'>" . htmlspecialchars(substr($audit['details'], 0, 50)) . "...</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    }
    
    // Check stock transfers
    $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfers WHERE id LIKE 'st_comp_%'");
    $transferCount = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
    echo "<p class='success'>✅ Comprehensive demo transfers: $transferCount</p>";
    
    echo "<h2>🎉 Audit Trail Data Loaded Successfully!</h2>";
    echo "<p>Your Stock Transfer module now has comprehensive audit trail data for all demo scenarios.</p>";
    
    echo "<div style='text-align: center; margin: 30px 0;'>";
    echo "<a href='dashboard.php' style='background: #10b981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-right: 10px;'>📊 View in Dashboard</a>";
    echo "<a href='test-stock-transfer-scenarios.php' style='background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;'>🎭 Demo Scenarios</a>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<h3 class='error'>❌ Failed to Load Audit Trail</h3>";
    echo "<p class='error'>Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}

echo "</div></body></html>";
?>