<?php
/**
 * Test POR Item Transfer from Receiving
 * Verifies that ALL items from receiving transfer completely to POR
 */

require_once 'config/database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Test POR Item Transfer</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #1e1e1e; color: #d4d4d4; }
        .success { color: #4ec9b0; }
        .error { color: #f48771; }
        .info { color: #569cd6; }
        .warning { color: #dcdcaa; }
        table { border-collapse: collapse; margin: 20px 0; width: 100%; }
        th, td { border: 1px solid #404040; padding: 8px 12px; text-align: left; }
        th { background: #2d2d2d; }
        tr:nth-child(even) { background: #252526; }
        h2 { color: #4ec9b0; border-bottom: 2px solid #4ec9b0; padding-bottom: 10px; }
        .section { margin: 30px 0; padding: 20px; background: #252526; border-radius: 8px; }
    </style>
</head>
<body>";

echo "<h1>🔬 Test POR Item Transfer from Receiving</h1>\n";
echo "<p class='info'>Verifying that complete items from receiving transfer to POR...</p>\n";

try {
    $db = getDB();
    
    // ============================================
    // STEP 1: Get a recent receiving record
    // ============================================
    echo "<div class='section'>";
    echo "<h2>📦 STEP 1: Fetch Recent Receiving Record</h2>\n";
    
    $stmt = $db->query("
        SELECT * FROM receivings 
        WHERE status = 'Approved' 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $receiving = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$receiving) {
        echo "<p class='warning'>⚠️ No approved receiving records found. Please create one first.</p>\n";
        echo "</div></body></html>";
        exit;
    }
    
    $receivingData = json_decode($receiving['data'], true);
    
    echo "<p class='success'>✓ Found receiving: <strong>{$receivingData['receivingNumber']}</strong></p>\n";
    echo "<p>PO Number: <strong>{$receivingData['poNumber']}</strong></p>\n";
    echo "<p>Supplier: <strong>{$receivingData['supplier']}</strong></p>\n";
    echo "<p>Received Date: <strong>{$receiving['received_date']}</strong></p>\n";
    echo "<p>Total Items: <strong>" . count($receivingData['items']) . "</strong></p>\n";
    
    echo "<h3>Receiving Items:</h3>\n";
    echo "<table>
        <tr>
            <th>Product</th>
            <th>Ordered Qty</th>
            <th>Received Qty</th>
            <th>Unit Cost</th>
            <th>Total</th>
        </tr>";
    
    $receivingTotalValue = 0;
    foreach ($receivingData['items'] as $item) {
        $orderedQty = floatval($item['quantityOrdered'] ?? 0);
        $receivedQty = floatval($item['quantityDelivered'] ?? 0);
        $unitCost = floatval($item['unitCost'] ?? 0);
        $totalCost = $receivedQty * $unitCost;
        $receivingTotalValue += $totalCost;
        
        echo "<tr>
            <td>{$item['productName']}</td>
            <td>{$orderedQty}</td>
            <td class='success'>{$receivedQty}</td>
            <td>₱" . number_format($unitCost, 2) . "</td>
            <td>₱" . number_format($totalCost, 2) . "</td>
        </tr>";
    }
    echo "<tr style='font-weight:bold; background:#2d2d2d;'>
        <td colspan='4'>Total Value</td>
        <td>₱" . number_format($receivingTotalValue, 2) . "</td>
    </tr>";
    echo "</table>\n";
    echo "</div>";
    
    // ============================================
    // STEP 2: Check if POR already exists
    // ============================================
    echo "<div class='section'>";
    echo "<h2>🔍 STEP 2: Check Existing POR</h2>\n";
    
    $checkStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE receiving_id = ?");
    $checkStmt->execute([$receiving['id']]);
    $existingPOR = $checkStmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingPOR) {
        echo "<p class='warning'>⚠️ POR already exists: <strong>{$existingPOR['por_number']}</strong></p>\n";
        echo "<p>Using existing POR for verification...</p>\n";
        $porId = $existingPOR['id'];
    } else {
        echo "<p class='success'>✓ No existing POR found. Ready to create new one.</p>\n";
        $porId = null;
    }
    echo "</div>";
    
    // ============================================
    // STEP 3: Create POR if not exists
    // ============================================
    if (!$porId) {
        echo "<div class='section'>";
        echo "<h2>➕ STEP 3: Create POR from Receiving</h2>\n";
        
        // Simulate the API call
        $url = "http://localhost/operations2/api/por.php";
        $data = [
            'action' => 'create_from_receiving',
            'receiving_id' => $receiving['id'],
            'remarks' => 'Test POR creation - verifying complete item transfer'
        ];
        
        $options = [
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/json\r\n",
                'content' => json_encode($data)
            ]
        ];
        
        echo "<p>Creating POR via API...</p>\n";
        echo "<pre class='info'>POST {$url}\n" . json_encode($data, JSON_PRETTY_PRINT) . "</pre>\n";
        
        // Note: This would need session auth in real scenario
        echo "<p class='warning'>⚠️ API call requires authentication. Creating POR directly in database for testing...</p>\n";
        
        // Direct database creation for testing
        $db->beginTransaction();
        
        // Generate POR number
        $year = date('Y');
        $lastPOR = $db->query("SELECT por_number FROM proof_of_receiving WHERE por_number LIKE 'POR-$year-%' ORDER BY created_at DESC LIMIT 1")->fetch();
        if ($lastPOR && preg_match('/POR-\d{4}-(\d{4})/', $lastPOR['por_number'], $matches)) {
            $nextNum = intval($matches[1]) + 1;
        } else {
            $nextNum = 1;
        }
        $porNumber = sprintf('POR-%d-%04d', $year, $nextNum);
        $porId = 'por_' . uniqid();
        
        // Calculate totals
        $totalOrdered = 0;
        $totalReceived = 0;
        foreach ($receivingData['items'] as $item) {
            $totalOrdered += floatval($item['quantityOrdered'] ?? 0);
            $totalReceived += floatval($item['quantityDelivered'] ?? 0);
        }
        
        // Insert POR
        $insertPOR = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number, receiving_id,
                supplier_id, supplier_name, received_by, received_by_name,
                receiving_date, inspection_status, status,
                total_items, total_ordered, total_received, total_accepted, total_rejected,
                total_value, remarks, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $insertPOR->execute([
            $porId,
            $porNumber,
            $receivingData['poId'] ?? null,
            $receivingData['poNumber'],
            $receiving['id'],
            $receivingData['supplierId'] ?? null,
            $receivingData['supplier'],
            'u1', // Test user
            'Test User',
            $receiving['received_date'],
            'Pending Inspection',
            'Draft',
            count($receivingData['items']),
            $totalOrdered,
            $totalReceived,
            $totalReceived, // Initially all received items are accepted
            0,
            $receivingTotalValue,
            'Test POR - complete item transfer'
        ]);
        
        // Insert POR items with COMPLETE quantities from receiving
        $insertItem = $db->prepare("
            INSERT INTO proof_of_receiving_items (
                id, por_id, product_id, product_name, sku, unit,
                ordered_quantity, received_quantity, accepted_quantity, rejected_quantity,
                unit_cost, total_cost, inspection_result, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        foreach ($receivingData['items'] as $item) {
            $receivedQty = floatval($item['quantityDelivered'] ?? 0);
            $unitCost = floatval($item['unitCost'] ?? 0);
            
            $insertItem->execute([
                'por_item_' . uniqid(),
                $porId,
                $item['productId'],
                $item['productName'],
                $item['sku'] ?? null,
                $item['unit'] ?? 'pcs',
                floatval($item['quantityOrdered'] ?? 0),
                $receivedQty,
                $receivedQty, // ALL received quantity is initially accepted
                0, // No rejections initially
                $unitCost,
                $receivedQty * $unitCost,
                'Pending'
            ]);
        }
        
        $db->commit();
        
        echo "<p class='success'>✓ POR created: <strong>{$porNumber}</strong></p>\n";
        echo "</div>";
    }
    
    // ============================================
    // STEP 4: Verify POR Items
    // ============================================
    echo "<div class='section'>";
    echo "<h2>✅ STEP 4: Verify POR Items</h2>\n";
    
    $porStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
    $porStmt->execute([$porId]);
    $por = $porStmt->fetch(PDO::FETCH_ASSOC);
    
    echo "<p class='success'>POR Number: <strong>{$por['por_number']}</strong></p>\n";
    echo "<p>Status: <strong>{$por['inspection_status']}</strong></p>\n";
    
    $itemsStmt = $db->prepare("SELECT * FROM proof_of_receiving_items WHERE por_id = ? ORDER BY created_at");
    $itemsStmt->execute([$porId]);
    $porItems = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h3>POR Items (Should match receiving items exactly):</h3>\n";
    echo "<table>
        <tr>
            <th>Product</th>
            <th>Ordered</th>
            <th>Received</th>
            <th>Accepted</th>
            <th>Rejected</th>
            <th>Unit Cost</th>
            <th>Total Cost</th>
            <th>Status</th>
        </tr>";
    
    $porTotalValue = 0;
    foreach ($porItems as $item) {
        $porTotalValue += floatval($item['total_cost']);
        
        echo "<tr>
            <td>{$item['product_name']}</td>
            <td>{$item['ordered_quantity']}</td>
            <td>{$item['received_quantity']}</td>
            <td class='success'><strong>{$item['accepted_quantity']}</strong></td>
            <td>{$item['rejected_quantity']}</td>
            <td>₱" . number_format($item['unit_cost'], 2) . "</td>
            <td>₱" . number_format($item['total_cost'], 2) . "</td>
            <td>{$item['inspection_result']}</td>
        </tr>";
    }
    echo "<tr style='font-weight:bold; background:#2d2d2d;'>
        <td colspan='6'>Total Value</td>
        <td>₱" . number_format($porTotalValue, 2) . "</td>
        <td></td>
    </tr>";
    echo "</table>\n";
    echo "</div>";
    
    // ============================================
    // STEP 5: Comparison & Verification
    // ============================================
    echo "<div class='section'>";
    echo "<h2>🔬 STEP 5: Verification Results</h2>\n";
    
    $receivingItemCount = count($receivingData['items']);
    $porItemCount = count($porItems);
    
    echo "<table>
        <tr>
            <th>Metric</th>
            <th>Receiving</th>
            <th>POR</th>
            <th>Status</th>
        </tr>
        <tr>
            <td>Total Items</td>
            <td>{$receivingItemCount}</td>
            <td>{$porItemCount}</td>
            <td>" . ($receivingItemCount === $porItemCount ? "<span class='success'>✓ Match</span>" : "<span class='error'>✗ Mismatch</span>") . "</td>
        </tr>
        <tr>
            <td>Total Value</td>
            <td>₱" . number_format($receivingTotalValue, 2) . "</td>
            <td>₱" . number_format($porTotalValue, 2) . "</td>
            <td>" . (abs($receivingTotalValue - $porTotalValue) < 0.01 ? "<span class='success'>✓ Match</span>" : "<span class='error'>✗ Mismatch</span>") . "</td>
        </tr>";
    
    // Check each item
    $allMatch = true;
    foreach ($receivingData['items'] as $index => $recItem) {
        $porItem = $porItems[$index] ?? null;
        if ($porItem) {
            $recQty = floatval($recItem['quantityDelivered'] ?? 0);
            $porAccepted = floatval($porItem['accepted_quantity']);
            
            if (abs($recQty - $porAccepted) > 0.001) {
                $allMatch = false;
                echo "<tr>
                    <td>{$recItem['productName']}</td>
                    <td>{$recQty} received</td>
                    <td>{$porAccepted} accepted</td>
                    <td><span class='error'>✗ Mismatch</span></td>
                </tr>";
            }
        }
    }
    
    echo "</table>\n";
    
    if ($allMatch && $receivingItemCount === $porItemCount && abs($receivingTotalValue - $porTotalValue) < 0.01) {
        echo "<h3 class='success'>🎉 ✓ ALL VERIFICATION PASSED!</h3>\n";
        echo "<p class='success'>All items from receiving have been completely transferred to POR with:</p>\n";
        echo "<ul class='success'>
            <li>✓ Same item count</li>
            <li>✓ All received quantities set as accepted quantities</li>
            <li>✓ Matching total values</li>
            <li>✓ Zero rejections initially</li>
            <li>✓ Pending inspection status</li>
        </ul>\n";
    } else {
        echo "<h3 class='error'>❌ VERIFICATION FAILED</h3>\n";
        echo "<p class='error'>Some items did not transfer correctly. Check the details above.</p>\n";
    }
    
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='section'>";
    echo "<p class='error'>❌ ERROR: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "<pre class='error'>" . htmlspecialchars($e->getTraceAsString()) . "</pre>\n";
    echo "</div>";
}

echo "</body></html>";
?>
