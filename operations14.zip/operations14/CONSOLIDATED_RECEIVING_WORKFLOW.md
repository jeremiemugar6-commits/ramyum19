# 📦 Consolidated Receiving & Inspection Workflow

## Overview
The Receiving and Proof of Receiving (POR) operations have been consolidated into a **single atomic transaction**. This means you inspect items BEFORE they are added to inventory, not after.

---

## Why This Change?

### Old Workflow (Sequential - REMOVED)
```
1. Receive items → Add ALL to inventory
2. Create separate POR → Inspect items
3. Manually adjust inventory for rejected items
```

**Problems:**
- ❌ Poor quality items entered inventory first
- ❌ Required manual inventory adjustments
- ❌ Two separate steps prone to errors
- ❌ Inventory temporarily incorrect between steps

### New Workflow (Consolidated - CURRENT)
```
1. Receive & Inspect items → Record accepted/rejected/damaged
2. Add ONLY accepted items to inventory
3. Both Receiving + POR records created automatically
```

**Benefits:**
- ✅ Inspect BEFORE items enter inventory
- ✅ Only accepted items increase stock
- ✅ Single atomic SQL transaction (all-or-nothing)
- ✅ Automatic POR creation with inspection results
- ✅ Inventory always accurate

---

## How It Works

### Step 1: Navigate to Receiving Module
- Go to **Receiving & Inspection (Consolidated)** module
- Click **"Receive & Inspect Delivery"** button

### Step 2: Select Purchase Order
- Choose an approved PO from the list
- System shows all items awaiting delivery

### Step 3: Record Quantities (Single Form)
For each item, you enter:

| Field | Description | Required |
|-------|-------------|----------|
| **Received Qty** | Total physically delivered | Yes |
| **Accepted Qty** | Items in good condition | Yes |
| **Rejected Qty** | Poor quality items | Optional |
| **Damaged Qty** | Broken/damaged items | Optional |

**Validation Rule:**
```
Accepted + Rejected + Damaged = Received
```

### Step 4: Add Inspection Notes
- Record observations about quality
- Note any discrepancies
- Document special handling

### Step 5: Submit (One Click)
System performs **all actions in one transaction**:

1. ✅ Validates quantities match
2. ✅ Generates Receiving Number (GR-YYYY-NNNN)
3. ✅ Generates POR Number (POR-YYYY-NNNN)
4. ✅ Creates Receiving record (historical)
5. ✅ Creates POR record (inspection results)
6. ✅ **Updates inventory** (ONLY accepted items)
7. ✅ Recalculates stock status badges
8. ✅ Creates inventory movement logs
9. ✅ Updates PO status (Partially/Fully Received)
10. ✅ Logs comprehensive audit trail

**If ANY step fails → Entire transaction rolls back (nothing changes)**

---

## Frontend Changes

### Receiving Module (`modules/receiving/receiving.js`)

#### Updated Functions:
- `renderReceivingForm()` - Now includes inspection fields
- `processConsolidatedReceiving()` - Calls new workflow API
- `showReceivingResults()` - Displays detailed inspection results

#### New UI Elements:
```javascript
// Each item now has 4 quantity inputs
<input class="receive-qty" />   // Total delivered
<input class="accepted-qty" />   // Good quality
<input class="rejected-qty" />   // Poor quality  
<input class="damaged-qty" />    // Broken/damaged
```

#### Real-time Validation:
- Visual feedback when quantities don't match
- Auto-adjustment of accepted quantity
- Border color changes (green=valid, red=invalid, yellow=incomplete)

### POR Module (`modules/por/index.js`)

#### Updated Behavior:
- **Removed "Create POR" button** (now auto-created)
- Added info banner: "POR records are now created automatically during Receiving & Inspection"
- Module is now **view-only** for inspection results

---

## Backend Changes

### New API Endpoint
**File:** `api/workflow-processor.php`

**Action:** `receive_and_inspect_items`

**Request:**
```json
POST /api/workflow-processor.php
{
  "action": "receive_and_inspect_items",
  "purchase_order_id": "po_xxxxx",
  "items": [
    {
      "product_id": "p_xxxxx",
      "sku": "RAM-001",
      "product_name": "Shin Ramyun",
      "ordered_quantity": 100,
      "received_quantity": 100,
      "accepted_quantity": 95,
      "rejected_quantity": 3,
      "damaged_quantity": 2,
      "unit_cost": 45.00,
      "inspection_result": "Conditional"
    }
  ],
  "inspection_notes": "3 packs slightly damaged, 2 expired",
  "received_by": "John Doe"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Receiving and inspection completed successfully",
  "data": {
    "receiving_number": "GR-2026-0001",
    "por_number": "POR-2026-0001",
    "po_number": "PO-2026-0005",
    "po_status": "Partially Received",
    "total_received": 100,
    "total_accepted": 95,
    "total_rejected": 3,
    "total_damaged": 2,
    "inventory_updated": true,
    "inspection_results": [...]
  }
}
```

### Core Function: `receiveAndInspectItems()`

**Transaction Flow:**
```php
try {
    $db->beginTransaction();
    
    // 1. Validate PO exists and is Approved
    // 2. Validate inspection quantities
    // 3. Generate receiving number
    // 4. Generate POR number
    // 5. Create Receiving record
    // 6. Create POR header record
    // 7. Create POR items (inspection details)
    // 8. Update product stock (accepted only)
    // 9. Recalculate stock status badges
    // 10. Create inventory movements
    // 11. Update PO status
    // 12. Log audit trail
    
    $db->commit();
    return success;
    
} catch (Exception $e) {
    $db->rollBack();
    return error;
}
```

---

## Database Records Created

### 1. Receiving Record (Historical)
```sql
INSERT INTO receivings (data) VALUES ('{
  "receivingNumber": "GR-2026-0001",
  "poNumber": "PO-2026-0005",
  "supplier": "Seoul Food Distribution",
  "totalReceived": 100,
  "receivedBy": "John Doe",
  "receivedDate": "2026-10-03T10:30:00Z"
}');
```

### 2. POR Header (Inspection Summary)
```sql
INSERT INTO proof_of_receiving (
  por_number,
  purchase_order_id,
  receiving_id,
  supplier_id,
  supplier_name,
  inspection_status,
  total_accepted,
  total_rejected,
  total_damaged,
  inventory_updated
) VALUES (
  'POR-2026-0001',
  'po_xxxxx',
  'rec_xxxxx',
  's1',
  'Seoul Food Distribution',
  'Conditional',
  95,
  3,
  2,
  1
);
```

### 3. POR Items (Per-Product Details)
```sql
INSERT INTO proof_of_receiving_items (
  por_id,
  product_id,
  ordered_quantity,
  received_quantity,
  accepted_quantity,
  rejected_quantity,
  damaged_quantity,
  inspection_result
) VALUES (
  'por_xxxxx',
  'p_xxxxx',
  100,
  100,
  95,
  3,
  2,
  'Conditional'
);
```

### 4. Inventory Update (Accepted Items Only)
```sql
UPDATE products 
SET data = JSON_SET(
  data,
  '$.stock', stock + 95,  -- Only accepted quantity
  '$.status', 'In Stock'
)
WHERE id = 'p_xxxxx';
```

### 5. Inventory Movement Log
```sql
INSERT INTO inventory_movements (data) VALUES ('{
  "type": "Stock In",
  "referenceType": "RECEIVING",
  "referenceId": "GR-2026-0001",
  "quantity": 95,
  "reason": "Purchase Order Receiving (Accepted Items Only)"
}');
```

---

## Stock Status Calculation

After accepting items, stock badges are recalculated:

```php
function calculateStockStatus($currentStock) {
    if ($currentStock === 0) return 'Out of Stock';
    if ($currentStock <= 20) return 'Low Stock';
    if ($currentStock <= 100) return 'In Stock';
    return 'Overstock';
}
```

---

## Error Handling

### Validation Errors
- ❌ Quantities don't match: `Accepted + Rejected + Damaged ≠ Received`
- ❌ Negative quantities
- ❌ PO not found or not Approved
- ❌ Product not found in catalog

### Transaction Rollback
If **any error occurs**, the entire transaction is rolled back:
- No receiving record created
- No POR record created
- No inventory changes
- No audit logs
- System returns to previous state

---

## Migration from Old System

### Legacy Receiving Records
Old receiving records (without POR) are still viewable:
- Display "No POR (Legacy)" in history
- Action button shows "Old workflow" instead of "Create POR"

### What to Do with Legacy Data
**Option 1:** Leave as-is (historical reference)
**Option 2:** Create POR manually for important records
**Option 3:** Archive old records (not recommended)

---

## Testing Checklist

- [ ] Create PO with multiple items
- [ ] Approve PO (status → Approved)
- [ ] Navigate to Receiving module
- [ ] Click "Receive & Inspect Delivery"
- [ ] Select approved PO
- [ ] Enter received quantities
- [ ] Enter accepted/rejected/damaged (ensure they sum correctly)
- [ ] Add inspection notes
- [ ] Submit form
- [ ] Verify success message shows both GR and POR numbers
- [ ] Check results modal displays correctly
- [ ] Verify inventory updated (only accepted qty added)
- [ ] Check POR module shows new record
- [ ] Verify PO status updated (Partially/Fully Received)
- [ ] Test transaction rollback (e.g., invalid quantities)

---

## Common Issues & Solutions

### Issue: "Quantities don't match"
**Cause:** Accepted + Rejected + Damaged ≠ Received
**Solution:** Adjust quantities so they equal received total

### Issue: "PO not found or not Approved"
**Cause:** Selected PO has wrong status
**Solution:** Approve the PO first in Purchase Orders module

### Issue: "Product not found in catalog"
**Cause:** Product was deleted after PO creation
**Solution:** Restore product or remove from PO items

### Issue: Transaction timeout
**Cause:** Too many items or slow database
**Solution:** Increase PHP max_execution_time or split into smaller deliveries

---

## Benefits Summary

| Aspect | Old Workflow | New Workflow |
|--------|-------------|--------------|
| **Steps** | 2 separate operations | 1 consolidated operation |
| **Inventory Accuracy** | Temporarily incorrect | Always accurate |
| **Transaction Safety** | Partial updates possible | All-or-nothing atomicity |
| **User Experience** | Complex, error-prone | Simple, guided |
| **Data Consistency** | Manual adjustments needed | Automatic and consistent |
| **Audit Trail** | Scattered across operations | Single comprehensive log |
| **Performance** | Multiple database calls | Single optimized transaction |

---

## Developer Notes

### Frontend Architecture
```
Receiving Module
├── renderReceivingForm() - Display inspection form
├── processConsolidatedReceiving() - Collect & validate data
└── showReceivingResults() - Display success details

POR Module (View Only)
└── renderPOR() - Display inspection results
```

### Backend Architecture
```
workflow-processor.php
└── receiveAndInspectItems()
    ├── validatePurchaseOrder()
    ├── validateInspectionQuantities()
    ├── generateReceivingNumber()
    ├── generatePORNumber()
    ├── createReceivingRecord()
    ├── createPORRecord()
    ├── updateProductStock() (accepted only)
    ├── calculateStockStatus()
    ├── createInventoryMovements()
    ├── updatePurchaseOrderStatus()
    └── logAuditTrail()
```

### Transaction Pattern
```php
// ALWAYS use this pattern for data consistency
try {
    $db->beginTransaction();
    // ... all operations ...
    $db->commit();
} catch (Exception $e) {
    $db->rollBack();
    throw $e;
}
```

---

## Future Enhancements

Potential improvements for future versions:

1. **Photo Upload per Item**
   - Attach photos of damaged items
   - Visual evidence in POR record

2. **Batch/Lot Tracking**
   - Record batch numbers during inspection
   - Track expiration dates

3. **Quality Score Calculation**
   - Automatic supplier rating based on acceptance rate
   - Trend analysis over time

4. **Barcode Scanning**
   - Scan items during receiving
   - Auto-populate quantities

5. **Email Notifications**
   - Notify managers when items rejected
   - Alert suppliers of quality issues

6. **Mobile App Integration**
   - Receive items using mobile device
   - Offline support for warehouse

---

## Support & Questions

For issues or questions about the consolidated workflow:
1. Review this document
2. Check BACKEND_IMPLEMENTATION_GUIDE.md
3. Test in demo environment first
4. Check browser console for errors
5. Review PHP error logs

**Last Updated:** October 3, 2026
**Version:** 2.0 (Consolidated Workflow)
**Status:** ✅ Production Ready
