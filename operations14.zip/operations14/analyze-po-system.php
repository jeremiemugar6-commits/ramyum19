<?php
/**
 * Analyze Current Purchase Order System
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';

$db = getDB();

echo "PURCHASE ORDER SYSTEM ANALYSIS\n";
echo str_repeat("=", 80) . "\n\n";

// 1. Check PO table structure
echo "1. PURCHASE ORDERS TABLE STRUCTURE:\n";
echo str_repeat("-", 80) . "\n";
$stmt = $db->query("DESCRIBE purchase_orders");
$columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($columns as $col) {
    echo sprintf("%-25s %-20s %s\n", $col['Field'], $col['Type'], $col['Null'] === 'NO' ? 'NOT NULL' : 'NULL');
}

// 2. Check current PO records and their status values
echo "\n2. CURRENT PO STATUS VALUES:\n";
echo str_repeat("-", 80) . "\n";
$stmt = $db->query("SELECT id, data FROM purchase_orders LIMIT 5");
$pos = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "Sample POs:\n";
foreach ($pos as $po) {
    $data = json_decode($po['data'], true);
    echo "  PO ID: {$po['id']}\n";
    echo "    PO Number: " . ($data['poNumber'] ?? 'N/A') . "\n";
    echo "    Status: " . ($data['status'] ?? 'N/A') . "\n";
    echo "    Supplier: " . ($data['supplier'] ?? 'N/A') . "\n";
    echo "    Items: " . count($data['items'] ?? []) . "\n";
    echo "\n";
}

// 3. Check unique status values
echo "3. ALL STATUS VALUES IN USE:\n";
echo str_repeat("-", 80) . "\n";
$stmt = $db->query("SELECT DISTINCT JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status, COUNT(*) as count FROM purchase_orders GROUP BY status");
$statuses = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($statuses as $status) {
    echo "  " . ($status['status'] ?? 'NULL') . ": " . $status['count'] . " POs\n";
}

// 4. Check receivings table
echo "\n4. RECEIVINGS TABLE:\n";
echo str_repeat("-", 80) . "\n";
$stmt = $db->query("SHOW TABLES LIKE 'receivings'");
if ($stmt->rowCount() > 0) {
    echo "✓ Receivings table exists\n";
    $stmt = $db->query("SELECT COUNT(*) as count FROM receivings");
    $count = $stmt->fetch()['count'];
    echo "  Total receivings: $count\n";
    
    // Sample receiving
    $stmt = $db->query("SELECT id, data FROM receivings LIMIT 1");
    $receiving = $stmt->fetch();
    if ($receiving) {
        $data = json_decode($receiving['data'], true);
        echo "\n  Sample Receiving:\n";
        echo "    ID: {$receiving['id']}\n";
        echo "    PO ID: " . ($data['poId'] ?? 'N/A') . "\n";
        echo "    Status: " . ($data['status'] ?? 'N/A') . "\n";
    }
} else {
    echo "✗ Receivings table NOT found\n";
}

// 5. Check POR table
echo "\n5. PROOF OF RECEIVING TABLE:\n";
echo str_repeat("-", 80) . "\n";
$stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
$count = $stmt->fetch()['count'];
echo "  Total PORs: $count\n";

// 6. Check if PO has approval fields
echo "\n6. PO DATA STRUCTURE CHECK:\n";
echo str_repeat("-", 80) . "\n";
$stmt = $db->query("SELECT data FROM purchase_orders LIMIT 1");
$po = $stmt->fetch();
if ($po) {
    $data = json_decode($po['data'], true);
    $fields = [
        'status' => 'Status field',
        'approvedBy' => 'ApprovedBy field',
        'approvedAt' => 'ApprovedAt field',
        'submittedBy' => 'SubmittedBy field',
        'submittedAt' => 'SubmittedAt field',
        'createdBy' => 'CreatedBy field',
        'cancelledBy' => 'CancelledBy field',
        'cancelledAt' => 'CancelledAt field',
        'cancelReason' => 'Cancel reason field'
    ];
    
    foreach ($fields as $field => $label) {
        $exists = isset($data[$field]) ? '✓' : '✗';
        $value = isset($data[$field]) ? $data[$field] : 'not present';
        echo "  $exists $label: $value\n";
    }
}

// 7. Check existing PO files
echo "\n7. PO-RELATED FILES:\n";
echo str_repeat("-", 80) . "\n";
$files = [
    'modules/purchase-orders/purchase-orders.html',
    'modules/purchase-orders/purchase-orders.js',
    'api/data.php'
];
foreach ($files as $file) {
    if (file_exists($file)) {
        echo "  ✓ $file\n";
    } else {
        echo "  ✗ $file (not found)\n";
    }
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "ANALYSIS COMPLETE\n";
