<?php
/**
 * FIX POR PRODUCT REFERENCES
 * Map POR items to actual products in catalog and recreate inventory movements
 * 
 * CRITICAL FIX: POR items reference non-existent products (prod_xxx with XXXX-001 SKUs)
 * Actual products use different ID/SKU format (DRK001, MEAT001, etc.)
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "FIX POR PRODUCT REFERENCES\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Define product mapping: POR product → Actual product
// Based on audit, mapping by product type/category
$productMapping = [
    // Ramen Noodles → Samyang Buldak Original (p1)
    'prod_ramen_noodles' => [
        'actual_id' => 'p1',
        'sku' => 'SB-001',
        'name' => 'Samyang Buldak Original',
        'reason' => 'Ramen category match'
    ],
    
    // Beef Chuck → Beef Bulgogi
    'prod_beef_chuck' => [
        'actual_id' => 'MEAT001',
        'sku' => 'MEAT001',
        'name' => 'Beef Bulgogi (500g)',
        'reason' => 'Beef meat product match'
    ],
    
    // Pork Belly → Luncheon Meat (closest available)
    'prod_pork_belly' => [
        'actual_id' => 'MEAT002',
        'sku' => 'MEAT002',
        'name' => 'Lotte Luncheon Meat (340g)',
        'reason' => 'Meat product category match'
    ],
    
    // Chicken Breast → Korean Sausage (closest meat product)
    'prod_chicken_breast' => [
        'actual_id' => 'MEAT003',
        'sku' => 'MEAT003',
        'name' => 'Korean Sausage',
        'reason' => 'Meat product category match'
    ],
    
    // Soy Sauce → Bulgogi Sauce (closest available sauce)
    'prod_soy_sauce' => [
        'actual_id' => 'SAU001',
        'sku' => 'SAU001',
        'name' => 'Bulgogi Sauce',
        'reason' => 'Sauce category match'
    ],
    
    // Cooking Oil → Sesame Oil
    'prod_cooking_oil' => [
        'actual_id' => 'OIL001',
        'sku' => 'OIL001',
        'name' => 'Sesame Oil (1L)',
        'reason' => 'Oil product match'
    ]
];

try {
    $db->beginTransaction();
    
    echo "STEP 1: VERIFY ACTUAL PRODUCTS EXIST\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $allProductsExist = true;
    foreach ($productMapping as $oldId => $mapping) {
        $stmt = $db->prepare("SELECT id, data FROM products WHERE id = ?");
        $stmt->execute([$mapping['actual_id']]);
        $product = $stmt->fetch();
        
        if ($product) {
            $data = json_decode($product['data'], true);
            echo "✓ {$mapping['actual_id']}: {$data['name']} (Stock: {$data['stock']})\n";
        } else {
            echo "✗ {$mapping['actual_id']}: NOT FOUND\n";
            $allProductsExist = false;
        }
    }
    
    if (!$allProductsExist) {
        throw new Exception("Some target products don't exist. Cannot proceed.");
    }
    
    echo "\n";
    
    echo "STEP 2: UPDATE POR ITEM PRODUCT REFERENCES\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $itemsStmt = $db->query("
        SELECT 
            pori.*,
            por.por_number,
            por.status as por_status
        FROM proof_of_receiving_items pori
        INNER JOIN proof_of_receiving por ON pori.por_id = por.id
        ORDER BY por.por_number
    ");
    $porItems = $itemsStmt->fetchAll();
    
    echo "Found " . count($porItems) . " POR items to update\n\n";
    
    $itemsUpdated = 0;
    $itemsSkipped = 0;
    
    foreach ($porItems as $item) {
        $oldProductId = $item['product_id'];
        
        if (!isset($productMapping[$oldProductId])) {
            echo "⚠ {$item['por_number']} - {$item['product_name']}: No mapping for {$oldProductId}\n";
            $itemsSkipped++;
            continue;
        }
        
        $mapping = $productMapping[$oldProductId];
        
        // Update the POR item
        $updateStmt = $db->prepare("
            UPDATE proof_of_receiving_items
            SET product_id = ?,
                sku = ?,
                product_name = ?
            WHERE id = ?
        ");
        $updateStmt->execute([
            $mapping['actual_id'],
            $mapping['sku'],
            $mapping['name'],
            $item['id']
        ]);
        
        echo "✓ {$item['por_number']} - {$item['product_name']} → {$mapping['name']}\n";
        echo "    ID: {$oldProductId} → {$mapping['actual_id']}\n";
        echo "    SKU: {$item['sku']} → {$mapping['sku']}\n";
        
        $itemsUpdated++;
    }
    
    echo "\nItems updated: {$itemsUpdated}\n";
    echo "Items skipped: {$itemsSkipped}\n";
    
    echo "\n";
    
    echo "STEP 3: RESET INVENTORY FLAGS FOR RE-PROCESSING\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    // Reset inventory_updated flags so we can recreate movements
    $resetStmt = $db->query("
        UPDATE proof_of_receiving
        SET inventory_updated = 0,
            inventory_updated_at = NULL
        WHERE status = 'Completed'
    ");
    
    $resetCount = $resetStmt->rowCount();
    echo "Reset inventory flags for {$resetCount} completed PORs\n";
    
    echo "\n";
    
    echo "STEP 4: RECREATE INVENTORY MOVEMENTS FOR COMPLETED PORs\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $completedPORs = $db->query("
        SELECT * FROM proof_of_receiving
        WHERE status = 'Completed'
        ORDER BY por_number
    ")->fetchAll();
    
    echo "Processing " . count($completedPORs) . " completed PORs\n\n";
    
    $movementsCreated = 0;
    $stockUpdates = 0;
    
    foreach ($completedPORs as $por) {
        echo "POR: {$por['por_number']}\n";
        echo "  Supplier: {$por['supplier_name']}\n";
        
        // Get POR items
        $itemsStmt = $db->prepare("
            SELECT * FROM proof_of_receiving_items
            WHERE por_id = ?
        ");
        $itemsStmt->execute([$por['id']]);
        $items = $itemsStmt->fetchAll();
        
        $porMovements = 0;
        
        foreach ($items as $item) {
            $productId = $item['product_id'];
            $acceptedQty = floatval($item['accepted_quantity']);
            
            if ($acceptedQty <= 0) {
                continue;
            }
            
            // Get current product
            $prodStmt = $db->prepare("SELECT data FROM products WHERE id = ?");
            $prodStmt->execute([$productId]);
            $productRow = $prodStmt->fetch();
            
            if (!$productRow) {
                echo "  ✗ {$item['product_name']}: Product not found (ID: {$productId})\n";
                continue;
            }
            
            $productData = json_decode($productRow['data'], true);
            $currentStock = floatval($productData['stock'] ?? 0);
            $newStock = $currentStock + $acceptedQty;
            
            // Update product stock
            $productData['stock'] = $newStock;
            $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
            
            $updateProdStmt = $db->prepare("
                UPDATE products 
                SET data = ?, 
                    updated_at = NOW() 
                WHERE id = ?
            ");
            $updateProdStmt->execute([json_encode($productData), $productId]);
            
            // Create inventory movement
            $movementId = generate_id('inv_mov');
            $movementData = [
                'id' => $movementId,
                'productId' => $productId,
                'productName' => $item['product_name'],
                'sku' => $item['sku'],
                'date' => $por['completed_at'] ?? date('Y-m-d\TH:i:s.v\Z'),
                'type' => 'Stock In',
                'referenceType' => 'POR',
                'referenceId' => $por['por_number'],
                'referencePO' => $por['po_number'],
                'quantity' => $acceptedQty,
                'previousBalance' => $currentStock,
                'newBalance' => $newStock,
                'change' => $acceptedQty,
                'reason' => 'Proof of Receiving - Accepted Quantity',
                'notes' => "POR {$por['por_number']} - {$por['supplier_name']}",
                'user' => 'System (POR Integration)',
                'unitCost' => floatval($item['unit_cost'] ?? 0)
            ];
            
            $createdAt = $por['inventory_updated_at'] ?? $por['completed_at'] ?? date('Y-m-d H:i:s');
            
            $movStmt = $db->prepare("
                INSERT INTO inventory_movements (id, data, created_at, updated_at)
                VALUES (?, ?, ?, ?)
            ");
            $movStmt->execute([
                $movementId,
                json_encode($movementData),
                $createdAt,
                $createdAt
            ]);
            
            echo "  ✓ {$item['product_name']}: {$currentStock} + {$acceptedQty} = {$newStock}\n";
            
            $movementsCreated++;
            $porMovements++;
            $stockUpdates++;
        }
        
        // Mark POR as inventory updated
        $updatePORStmt = $db->prepare("
            UPDATE proof_of_receiving
            SET inventory_updated = 1,
                inventory_updated_at = NOW()
            WHERE id = ?
        ");
        $updatePORStmt->execute([$por['id']]);
        
        echo "  ✓ Created {$porMovements} movements, updated inventory\n\n";
    }
    
    echo "Summary:\n";
    echo "  Movements created: {$movementsCreated}\n";
    echo "  Products updated: {$stockUpdates}\n";
    
    echo "\n";
    
    $db->commit();
    
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "VERIFICATION\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
    // Verify POR items
    $validItemsStmt = $db->query("
        SELECT COUNT(*) as count
        FROM proof_of_receiving_items pori
        INNER JOIN products p ON pori.product_id = p.id
    ");
    $validItems = $validItemsStmt->fetch()['count'];
    $totalItems = $db->query("SELECT COUNT(*) FROM proof_of_receiving_items")->fetchColumn();
    
    echo "POR items with valid product references: {$validItems}/{$totalItems}\n";
    
    // Verify inventory movements
    $porMovements = $db->query("
        SELECT COUNT(*) FROM inventory_movements
        WHERE JSON_EXTRACT(data, '$.referenceType') = 'POR'
    ")->fetchColumn();
    
    echo "Inventory movements with referenceType='POR': {$porMovements}\n";
    
    // Verify completed PORs
    $completedWithInventory = $db->query("
        SELECT COUNT(*) FROM proof_of_receiving
        WHERE status = 'Completed' AND inventory_updated = 1
    ")->fetchColumn();
    
    $totalCompleted = $db->query("
        SELECT COUNT(*) FROM proof_of_receiving
        WHERE status = 'Completed'
    ")->fetchColumn();
    
    echo "Completed PORs with inventory updated: {$completedWithInventory}/{$totalCompleted}\n";
    
    echo "\n";
    
    // Show detailed breakdown
    echo "DETAILED BREAKDOWN:\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $breakdown = $db->query("
        SELECT 
            JSON_EXTRACT(data, '$.referenceId') as por_number,
            COUNT(*) as movement_count,
            SUM(CAST(JSON_EXTRACT(data, '$.quantity') AS DECIMAL(10,2))) as total_qty
        FROM inventory_movements
        WHERE JSON_EXTRACT(data, '$.referenceType') = 'POR'
        GROUP BY JSON_EXTRACT(data, '$.referenceId')
        ORDER BY por_number
    ")->fetchAll();
    
    foreach ($breakdown as $row) {
        echo "{$row['por_number']}: {$row['movement_count']} movements, {$row['total_qty']} units added\n";
    }
    
    echo "\n";
    
    if ($validItems == $totalItems && $porMovements > 0 && $completedWithInventory == $totalCompleted) {
        echo "✅ SUCCESS: All POR product references fixed and inventory movements created!\n";
        echo "✅ Workflow now complete: PO → Receiving → POR → Inventory\n";
    } else {
        echo "⚠ WARNING: Some issues remain. Review output above.\n";
    }
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "FIX COMPLETE\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
