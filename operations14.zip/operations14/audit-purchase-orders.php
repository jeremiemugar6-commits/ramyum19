<?php
/**
 * PURCHASE ORDER WORKFLOW AUDIT
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "PURCHASE ORDER WORKFLOW AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. PO Count and Status
echo "1. PURCHASE ORDERS OVERVIEW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$poCount = $db->query("SELECT COUNT(*) FROM purchase_orders")->fetchColumn();
echo "Total Purchase Orders: {$poCount}\n\n";

// Status breakdown
$statusBreakdown = $db->query("
    SELECT JSON_EXTRACT(data, '$.status') as status, COUNT(*) as cnt
    FROM purchase_orders
    GROUP BY status
    ORDER BY cnt DESC
")->fetchAll();

echo "Status Breakdown:\n";
foreach ($statusBreakdown as $status) {
    $statusName = trim($status['status'], '"');
    echo "  {$statusName}: {$status['cnt']}\n";
}

echo "\n";

// 2. Sample PO Data
echo "2. SAMPLE PURCHASE ORDERS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT id, data FROM purchase_orders ORDER BY created_at DESC LIMIT 3");
while ($row = $stmt->fetch()) {
    $data = json_decode($row['data'], true);
    echo "\nPO ID: {$row['id']}\n";
    echo "  PO Number: " . ($data['poNumber'] ?? 'N/A') . "\n";
    echo "  Supplier: " . ($data['supplierName'] ?? 'N/A') . "\n";
    echo "  Status: " . ($data['status'] ?? 'N/A') . "\n";
    echo "  Date: " . ($data['poDate'] ?? 'N/A') . "\n";
    echo "  Total Items: " . (isset($data['items']) ? count($data['items']) : 0) . "\n";
    echo "  Total Amount: ₱" . number_format($data['totalAmount'] ?? 0, 2) . "\n";
    
    // Check for receiving link
    $hasReceivingLink = isset($data['receivingId']) && !empty($data['receivingId']);
    echo "  Receiving Link: " . ($hasReceivingLink ? "✓ Yes ({$data['receivingId']})" : "✗ No") . "\n";
}

echo "\n";

// 3. PO Structure Check
echo "3. PO DATA STRUCTURE CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT data FROM purchase_orders LIMIT 1");
$samplePO = $stmt->fetch();
$sampleData = json_decode($samplePO['data'], true);

echo "Required Fields in PO:\n";
$requiredFields = ['poNumber', 'supplier', 'supplierName', 'poDate', 'status', 'items', 'totalAmount'];
foreach ($requiredFields as $field) {
    $exists = isset($sampleData[$field]);
    echo ($exists ? "✓" : "✗") . " {$field}\n";
}

echo "\nOptional/Workflow Fields:\n";
$workflowFields = ['receivingId', 'receivedDate', 'approvedBy', 'approvedDate', 'expectedDeliveryDate'];
foreach ($workflowFields as $field) {
    $exists = isset($sampleData[$field]);
    echo ($exists ? "✓" : "ℹ") . " {$field}: " . ($exists ? "Present" : "Not set") . "\n";
}

echo "\n";

// 4. PO Items Check
echo "4. PO ITEMS VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT id, data FROM purchase_orders");
$totalItems = 0;
$posWithItems = 0;
$posWithProducts = 0;

while ($row = $stmt->fetch()) {
    $data = json_decode($row['data'], true);
    if (isset($data['items']) && is_array($data['items']) && count($data['items']) > 0) {
        $posWithItems++;
        $totalItems += count($data['items']);
        
        // Check if items have product IDs
        foreach ($data['items'] as $item) {
            if (isset($item['productId'])) {
                $posWithProducts++;
                break;
            }
        }
    }
}

echo "POs with items: {$posWithItems}/{$poCount}\n";
echo "Total line items: {$totalItems}\n";
echo "POs with product links: {$posWithProducts}/{$posWithItems}\n";

echo "\n";

// 5. Sample PO Item Structure
echo "5. SAMPLE PO ITEM STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT data FROM purchase_orders WHERE JSON_EXTRACT(data, '$.items') IS NOT NULL LIMIT 1");
$samplePOWithItems = $stmt->fetch();
$poData = json_decode($samplePOWithItems['data'], true);

if (isset($poData['items']) && count($poData['items']) > 0) {
    $firstItem = $poData['items'][0];
    echo "First item structure:\n";
    foreach ($firstItem as $key => $value) {
        if (!is_array($value) && !is_object($value)) {
            echo "  {$key}: " . (is_string($value) ? $value : json_encode($value)) . "\n";
        }
    }
}

echo "\n";

// 6. Workflow Connection Check
echo "6. WORKFLOW CONNECTION CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// POs → Receiving
$posWithReceiving = $db->query("
    SELECT COUNT(*) FROM purchase_orders
    WHERE JSON_EXTRACT(data, '$.receivingId') IS NOT NULL
    AND JSON_EXTRACT(data, '$.receivingId') != ''
")->fetchColumn();
echo "POs with receiving link: {$posWithReceiving}/{$poCount}\n";

// Check if receiving records reference POs
$receivingCount = $db->query("SELECT COUNT(*) FROM receivings")->fetchColumn();
$receivingsWithPO = $db->query("
    SELECT COUNT(*) FROM receivings
    WHERE JSON_EXTRACT(data, '$.poId') IS NOT NULL
    AND JSON_EXTRACT(data, '$.poId') != ''
")->fetchColumn();
echo "Receiving records: {$receivingCount}\n";
echo "Receivings with PO link: {$receivingsWithPO}/{$receivingCount}\n";

// Cross-check: Do PO IDs in receivings exist?
$stmt = $db->query("SELECT DISTINCT JSON_EXTRACT(data, '$.poId') as poId FROM receivings WHERE JSON_EXTRACT(data, '$.poId') IS NOT NULL");
$validPOLinks = 0;
$invalidPOLinks = 0;
while ($row = $stmt->fetch()) {
    $poId = trim($row['poId'], '"');
    $checkStmt = $db->prepare("SELECT COUNT(*) FROM purchase_orders WHERE id = ?");
    $checkStmt->execute([$poId]);
    if ($checkStmt->fetchColumn() > 0) {
        $validPOLinks++;
    } else {
        $invalidPOLinks++;
    }
}
echo "Valid PO→Receiving links: {$validPOLinks}\n";
echo "Invalid/broken links: {$invalidPOLinks}\n";

echo "\n";

// 7. Status Validation
echo "7. STATUS VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$validStatuses = ['Draft', 'Pending', 'Approved', 'Partially Received', 'Fully Received', 'Cancelled', 'Closed'];
echo "Valid PO Statuses: " . implode(', ', $validStatuses) . "\n\n";

$stmt = $db->query("SELECT DISTINCT JSON_EXTRACT(data, '$.status') as status FROM purchase_orders");
echo "Actual statuses in use:\n";
while ($row = $stmt->fetch()) {
    $status = trim($row['status'], '"');
    $isValid = in_array($status, $validStatuses);
    echo ($isValid ? "✓" : "⚠") . " {$status}\n";
}

echo "\n";

// 8. Supplier Links
echo "8. SUPPLIER VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$supplierCount = $db->query("SELECT COUNT(*) FROM suppliers")->fetchColumn();
echo "Total Suppliers: {$supplierCount}\n";

$posWithSupplier = $db->query("
    SELECT COUNT(*) FROM purchase_orders
    WHERE JSON_EXTRACT(data, '$.supplier') IS NOT NULL
")->fetchColumn();
echo "POs with supplier ID: {$posWithSupplier}/{$poCount}\n";

// Check for broken supplier links
$stmt = $db->query("SELECT DISTINCT JSON_EXTRACT(data, '$.supplier') as supplierId FROM purchase_orders WHERE JSON_EXTRACT(data, '$.supplier') IS NOT NULL");
$validSupplierLinks = 0;
$invalidSupplierLinks = 0;
while ($row = $stmt->fetch()) {
    $supplierId = trim($row['supplierId'], '"');
    $checkStmt = $db->prepare("SELECT COUNT(*) FROM suppliers WHERE id = ?");
    $checkStmt->execute([$supplierId]);
    if ($checkStmt->fetchColumn() > 0) {
        $validSupplierLinks++;
    } else {
        $invalidSupplierLinks++;
    }
}
echo "Valid supplier links: {$validSupplierLinks}\n";
echo "Broken supplier links: {$invalidSupplierLinks}\n";

echo "\n";

// 9. Issues Summary
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "ISSUES SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

$issues = [];

if ($posWithReceiving == 0 && $poCount > 0) {
    $issues[] = "⚠ CRITICAL: No PO→Receiving workflow links established";
}

if ($receivingsWithPO < $receivingCount) {
    $issues[] = "⚠ WARNING: " . ($receivingCount - $receivingsWithPO) . " receiving records without PO link";
}

if ($invalidPOLinks > 0) {
    $issues[] = "⚠ ERROR: {$invalidPOLinks} broken PO references in receiving";
}

if ($invalidSupplierLinks > 0) {
    $issues[] = "⚠ WARNING: {$invalidSupplierLinks} broken supplier references";
}

if ($posWithItems < $poCount) {
    $issues[] = "⚠ WARNING: " . ($poCount - $posWithItems) . " POs without items";
}

if (empty($issues)) {
    echo "✓ NO CRITICAL ISSUES\n";
} else {
    echo "ISSUES DETECTED:\n\n";
    foreach ($issues as $issue) {
        echo "{$issue}\n";
    }
}

echo "\n";

// 10. Recommended Fixes
echo "RECOMMENDED FIXES:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

if ($posWithReceiving == 0) {
    echo "1. Establish PO→Receiving workflow:\n";
    echo "   - Update receiving creation to link to PO\n";
    echo "   - Add receivingId to PO when receiving is created\n";
    echo "   - Update PO status based on receiving\n\n";
}

if ($receivingsWithPO < $receivingCount) {
    echo "2. Link existing receivings to POs:\n";
    echo "   - Match by PO number or date\n";
    echo "   - Update receiving records with poId\n\n";
}

echo "3. Workflow Status Updates:\n";
echo "   - When PO created → Status: 'Pending'\n";
echo "   - When PO approved → Status: 'Approved'\n";
echo "   - When receiving created → Status: 'Partially Received'\n";
echo "   - When fully received → Status: 'Fully Received'\n";

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
