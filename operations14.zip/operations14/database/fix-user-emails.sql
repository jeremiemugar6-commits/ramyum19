-- ============================================================
-- FIX USER EMAIL ADDRESSES
-- Updates admin, manager, and staff emails to correct addresses
-- ============================================================
-- Database: u479471141_ramyum_db2
-- Date: 2026-10-03
-- ============================================================

USE u479471141_ramyum_db2;

-- Show current user emails before update
SELECT 
    '=== BEFORE UPDATE ===' as status,
    id,
    username,
    email,
    role
FROM users
ORDER BY 
    CASE role
        WHEN 'admin' THEN 1
        WHEN 'manager' THEN 2
        WHEN 'staff' THEN 3
        ELSE 4
    END;

-- Update admin email
UPDATE users 
SET email = 'jeremiemugar6@gmail.com',
    updated_at = NOW()
WHERE username = 'admin';

-- Update manager email
UPDATE users 
SET email = 'jeremiemugar7@gmail.com',
    updated_at = NOW()
WHERE username = 'manager';

-- Update staff email
UPDATE users 
SET email = 'jeremiemugar8@gmail.com',
    updated_at = NOW()
WHERE username = 'staff';

-- Show updated user emails
SELECT 
    '=== AFTER UPDATE ===' as status,
    id,
    username,
    email,
    role,
    updated_at
FROM users
ORDER BY 
    CASE role
        WHEN 'admin' THEN 1
        WHEN 'manager' THEN 2
        WHEN 'staff' THEN 3
        ELSE 4
    END;

-- Verification
SELECT 
    CASE 
        WHEN COUNT(*) = 3 THEN '✓ All 3 users updated successfully'
        ELSE '✗ Update incomplete'
    END as verification_status,
    COUNT(*) as users_updated
FROM users
WHERE email IN (
    'jeremiemugar6@gmail.com',
    'jeremiemugar7@gmail.com', 
    'jeremiemugar8@gmail.com'
);

-- ============================================================
-- END OF UPDATE
-- ============================================================
