<?php
/**
 * RAM-YUM Capstone Demo Setup Page
 * Web interface for setting up the complete demonstration scenario
 */

require_once __DIR__ . '/config/database.php';

// Only allow demo setup when demo mode is enabled
if (!DEMO_INTEGRATION_MODE) {
    die('<h1>Demo Setup Not Available</h1><p>Demo setup is only available when DEMO_INTEGRATION_MODE is enabled in .env file.</p>');
}

$message = '';
$messageType = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        $db = getDB();
        
        if ($_POST['action'] === 'load_base_data') {
            // Load base demo data (suppliers and products)
            $response = file_get_contents('http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/database/load-demo-data.php');
            $result = json_decode($response, true);
            
            if ($result['success']) {
                $message = "Base demo data loaded successfully! Suppliers and products are now available.";
                $messageType = 'success';
            } else {
                $message = "Failed to load base data: " . $result['error'];
                $messageType = 'error';
            }
            
        } elseif ($_POST['action'] === 'load_scenario') {
            // Load capstone demo scenario
            $response = file_get_contents('http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/database/load-capstone-scenario.php');
            $result = json_decode($response, true);
            
            if ($result['success']) {
                $message = "Capstone demo scenario loaded successfully! Ready for demonstration.";
                $messageType = 'success';
            } else {
                $message = "Failed to load scenario: " . $result['error'];
                $messageType = 'error';
            }
            
        } elseif ($_POST['action'] === 'reset_data') {
            // Reset demo data
            $db->exec("DELETE FROM purchase_orders WHERE id LIKE 'demo_po_%'");
            $db->exec("DELETE FROM receivings WHERE id LIKE 'demo_gr_%'");
            $db->exec("DELETE FROM inventory_movements WHERE id LIKE 'demo_mov_%'");
            
            $message = "Demo data reset successfully.";
            $messageType = 'success';
        }
        
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
        $messageType = 'error';
    }
}

// Get current system status
try {
    $db = getDB();
    $supplierCount = $db->query("SELECT COUNT(*) as count FROM suppliers")->fetch()['count'];
    $productCount = $db->query("SELECT COUNT(*) as count FROM products")->fetch()['count'];
    $poCount = $db->query("SELECT COUNT(*) as count FROM purchase_orders WHERE id LIKE 'demo_po_%'")->fetch()['count'];
    $grCount = $db->query("SELECT COUNT(*) as count FROM receivings WHERE id LIKE 'demo_gr_%'")->fetch()['count'];
} catch (Exception $e) {
    $supplierCount = $productCount = $poCount = $grCount = 'N/A';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RAM-YUM Capstone Demo Setup</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #FF7A00 0%, #E53935 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            padding: 40px;
            width: 100%;
            max-width: 800px;
        }
        .header {
            text-align: center;
            margin-bottom: 40px;
        }
        .header h1 {
            color: #E53935;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .header p {
            color: #666;
            font-size: 1.1rem;
        }
        .demo-badge {
            background: #FEF3C7;
            border: 2px solid #F59E0B;
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 30px;
            text-align: center;
        }
        .demo-badge strong {
            color: #92400E;
            font-weight: 600;
        }
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }
        .status-card {
            background: #F8F9FA;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            border: 2px solid transparent;
        }
        .status-card.ready { border-color: #10B981; background: #D1FAE5; }
        .status-card h3 {
            font-size: 2rem;
            font-weight: 700;
            color: #E53935;
            margin-bottom: 4px;
        }
        .status-card p {
            color: #666;
            font-size: 0.9rem;
        }
        .action-section {
            margin-bottom: 30px;
        }
        .action-section h2 {
            color: #333;
            font-size: 1.3rem;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 2px solid #E53935;
        }
        .action-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
        }
        .btn {
            background: #E53935;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 24px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            background: #D32F2F;
            transform: translateY(-1px);
        }
        .btn.secondary {
            background: #6B7280;
        }
        .btn.secondary:hover {
            background: #4B5563;
        }
        .btn.danger {
            background: #EF4444;
        }
        .btn.danger:hover {
            background: #DC2626;
        }
        .message {
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .message.success {
            background: #D1FAE5;
            color: #065F46;
            border: 1px solid #10B981;
        }
        .message.error {
            background: #FEE2E2;
            color: #991B1B;
            border: 1px solid #EF4444;
        }
        .steps {
            background: #F8F9FA;
            border-radius: 8px;
            padding: 24px;
            margin-top: 30px;
        }
        .steps h3 {
            color: #333;
            margin-bottom: 16px;
        }
        .steps ol {
            list-style: none;
            counter-reset: step;
        }
        .steps li {
            counter-increment: step;
            margin-bottom: 8px;
            padding-left: 30px;
            position: relative;
        }
        .steps li::before {
            content: counter(step);
            position: absolute;
            left: 0;
            top: 0;
            background: #E53935;
            color: white;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            font-size: 0.8rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>RAM-YUM Demo Setup</h1>
            <p>Capstone Pre-Oral Defense Configuration</p>
        </div>

        <div class="demo-badge">
            <strong>DEMO INTEGRATION MODE:</strong> <?= DEMO_MODE_MESSAGE ?>
        </div>

        <?php if ($message): ?>
            <div class="message <?= $messageType ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="status-grid">
            <div class="status-card <?= $supplierCount >= 4 ? 'ready' : '' ?>">
                <h3><?= $supplierCount ?></h3>
                <p>Suppliers Loaded</p>
            </div>
            <div class="status-card <?= $productCount >= 10 ? 'ready' : '' ?>">
                <h3><?= $productCount ?></h3>
                <p>Products Available</p>
            </div>
            <div class="status-card <?= $poCount >= 3 ? 'ready' : '' ?>">
                <h3><?= $poCount ?></h3>
                <p>Demo Purchase Orders</p>
            </div>
            <div class="status-card <?= $grCount >= 1 ? 'ready' : '' ?>">
                <h3><?= $grCount ?></h3>
                <p>Demo Receivings</p>
            </div>
        </div>

        <div class="action-section">
            <h2>Setup Actions</h2>
            <div class="action-buttons">
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="load_base_data">
                    <button type="submit" class="btn">
                        1. Load Base Data
                    </button>
                </form>
                
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="load_scenario">
                    <button type="submit" class="btn">
                        2. Load Demo Scenario
                    </button>
                </form>
                
                <a href="dashboard.php" class="btn secondary">
                    Access System
                </a>
                
                <form method="POST" style="display: inline;">
                    <input type="hidden" name="action" value="reset_data">
                    <button type="submit" class="btn danger" onclick="return confirm('Are you sure you want to reset all demo data?')">
                        Reset Demo Data
                    </button>
                </form>
            </div>
        </div>

        <div class="steps">
            <h3>Demo Preparation Steps:</h3>
            <ol>
                <li>Click "Load Base Data" to add suppliers and products</li>
                <li>Click "Load Demo Scenario" to create PO-2026-0001 and sample transactions</li>
                <li>Access the system and login as "admin" / "Admin@123"</li>
                <li>Navigate through Purchase Orders → Receiving → Inventory</li>
                <li>Demonstrate the complete workflow to panelists</li>
            </ol>
        </div>

        <div class="steps" style="margin-top: 20px;">
            <h3>Demonstration Flow:</h3>
            <ol>
                <li><strong>Purchase Orders:</strong> Show PO-2026-0001 from Seoul Food Distribution</li>
                <li><strong>Receiving:</strong> Demonstrate partial receiving (Samyang: 50, Shin: 25, Ottogi: 30)</li>
                <li><strong>Inventory:</strong> Show automatic stock updates and movement logs</li>
                <li><strong>Second Receiving:</strong> Complete remaining Shin Ramyun (15 units)</li>
                <li><strong>Status Update:</strong> Show PO status change to "Fully Received"</li>
                <li><strong>Reports:</strong> Display transaction history and audit trails</li>
            </ol>
        </div>
    </div>
</body>
</html>