<!DOCTYPE html>
<html>
<head>
    <title>Stock Transfer API Test</title>
</head>
<body>
    <h1>Stock Transfer API Test</h1>
    <button onclick="testAPI()">Test API</button>
    <pre id="output"></pre>

    <script>
        async function testAPI() {
            const output = document.getElementById('output');
            output.textContent = 'Testing API...\n\n';

            try {
                // Test 1: Get transfers
                output.textContent += '=== TEST 1: Get Transfers ===\n';
                const response = await fetch('api/stock-transfers.php?action=transfers');
                output.textContent += `Status: ${response.status}\n`;
                output.textContent += `Content-Type: ${response.headers.get('content-type')}\n`;
                
                const text = await response.text();
                output.textContent += `Raw Response: ${text.substring(0, 500)}\n`;
                
                try {
                    const json = JSON.parse(text);
                    output.textContent += `JSON Parsed: ${JSON.stringify(json, null, 2)}\n`;
                } catch (e) {
                    output.textContent += `JSON Parse Error: ${e.message}\n`;
                }

                // Test 2: Get locations
                output.textContent += '\n=== TEST 2: Get Locations ===\n';
                const locResponse = await fetch('api/stock-transfers.php?action=locations');
                output.textContent += `Status: ${locResponse.status}\n`;
                const locText = await locResponse.text();
                output.textContent += `Response: ${locText.substring(0, 200)}\n`;

            } catch (error) {
                output.textContent += `\nError: ${error.message}\n`;
                output.textContent += error.stack;
            }
        }
    </script>
</body>
</html>
