<?php
/**
 * Complete End-to-End Supplier Flow Test
 * Tests: Supplier → PO → Receiving → POR
 * Validates supplier consistency at every step
 */

require_once 'config/database.php';
require_once 'includes/auth.php';
require_once 'includes/supplier-validation.php';

$db = getDB();

// Simulate authenticated user
$testUser = [
    'id' => 'u1',
    'name' => 'Test Admin',
    'role' => 'admin'
];

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "COMPLETE SUPPLIER FLOW TEST\n";
echo "Supplier → Purchase Order → Receiving → Proof of Receiving\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

$testResults = [
    'passed' => 0,
    'failed' => 0,
    'total' => 0
];

function testStep($stepName, $result, &$testResults) {
    $testResults['total']++;
    if ($result) {
        echo "✓ PASS: $stepName\n";
        $testResults['passed']++;
        return true;
    } else {
        echo "✗ FAIL: $stepName\n";
        $testResults['failed']++;
        return false;
    }
}

try {
    // ============================================================
    // STEP 1: Get existing supplier from master
    // ============================================================
    echo "STEP 1: Retrieve Supplier from Master\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $stmt = $db->query("SELECT id, data FROM suppliers LIMIT 1");
    $supplierRow = $stmt->fetch();
    
    if (!$supplierRow) {
        throw new Exception("No suppliers found in database");
    }
    
    $supplier = json_decode($supplierRow['data'], true);
    $supplierId = $supplierRow['id'];
    $supplierName = $supplier['company'] ?? $supplier['name'] ?? 'Unknown';
    
    echo "Supplier ID: $supplierId\n";
    echo "Supplier Name: $supplierName\n";
    
    testStep("Supplier retrieved from master", true, $testResults);
    testStep("Supplier has valid ID", !empty($supplierId), $testResults);
    testStep("Supplier has name/company", !empty($supplierName), $testResults);
    
    echo "\n";
    
    // ============================================================
    // STEP 2: Create Purchase Order with this supplier
    // ============================================================
    echo "STEP 2: Create Purchase Order\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $poNumber = 'PO-TEST-' . time();
    $poId = 'po_test_' . time() . '_' . bin2hex(random_bytes(4));
    
    $poData = [
        'id' => $poId,
        'poNumber' => $poNumber,
        'supplier' => $supplierName,
        'supplierId' => $supplierId,
        'orderDate' => date('Y-m-d\TH:i:s.v\Z'),
        'expectedDate' => date('Y-m-d\TH:i:s.v\Z', strtotime('+7 days')),
        'status' => 'Approved',
        'items' => [
            [
                'productId' => 'p1',
                'productName' => 'Test Product',
                'quantity' => 10,
                'unitCost' => 50.00,
                'subtotal' => 500.00,
                'receivedQuantity' => 0,
                'remainingQuantity' => 10
            ]
        ],
        'subtotal' => 500.00,
        'total' => 500.00,
        'notes' => 'Test PO for supplier flow validation',
        'createdBy' => $testUser['name'],
        'totalItems' => 10,
        'receivedItems' => 0,
        'remainingItems' => 10
    ];
    
    $stmt = $db->prepare("INSERT INTO purchase_orders (id, data) VALUES (?, ?)");
    $stmt->execute([$poId, json_encode($poData)]);
    
    echo "PO Number: $poNumber\n";
    echo "PO ID: $poId\n";
    echo "Supplier: $supplierName ($supplierId)\n";
    
    testStep("Purchase Order created", true, $testResults);
    
    // Verify PO supplier matches
    $poSupplier = getSupplierFromPO($db, $poId);
    testStep("PO supplier retrieved successfully", $poSupplier !== null, $testResults);
    testStep("PO supplier ID matches original", $poSupplier['supplierId'] === $supplierId, $testResults);
    
    echo "\n";
    
    // ============================================================
    // STEP 3: Validate PO supplier before receiving
    // ============================================================
    echo "STEP 3: Validate PO Status and Supplier\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $poValidation = validatePOStatusForReceiving($db, $poId);
    testStep("PO status is valid for receiving", $poValidation['valid'], $testResults);
    echo "PO Status: {$poValidation['status']}\n";
    
    $supplierValid = validateSupplierExists($db, $supplierId);
    testStep("Supplier exists in master", $supplierValid, $testResults);
    
    echo "\n";
    
    // ============================================================
    // STEP 4: Create Proof of Receiving (with validation)
    // ============================================================
    echo "STEP 4: Create Proof of Receiving\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $porNumber = 'POR-TEST-' . time();
    $porId = generate_id('por');
    
    // Auto-populate supplier from PO (simulating API behavior)
    $autoSupplier = autoPopulateSupplierFromPO($db, $poId);
    testStep("Supplier auto-populated from PO", $autoSupplier !== null, $testResults);
    
    if ($autoSupplier) {
        echo "Auto-populated Supplier ID: {$autoSupplier['supplierId']}\n";
        echo "Auto-populated Supplier Name: {$autoSupplier['supplierName']}\n";
        echo "Read-only: " . ($autoSupplier['readonly'] ? 'Yes' : 'No') . "\n";
        
        testStep("Auto-populated supplier matches PO", 
            $autoSupplier['supplierId'] === $supplierId, $testResults);
    }
    
    // Validate POR creation
    $porCreationData = [
        'purchaseOrderId' => $poId,
        'poNumber' => $poNumber,
        'supplierId' => $supplierId,  // This will be validated against PO
        'supplierName' => $supplierName
    ];
    
    $porValidation = validatePORCreation($db, $porCreationData);
    testStep("POR validation passed", $porValidation['valid'], $testResults);
    
    if (!$porValidation['valid']) {
        echo "Validation errors:\n";
        foreach ($porValidation['errors'] as $error) {
            echo "  - $error\n";
        }
    }
    
    // Create POR record
    $stmt = $db->prepare("
        INSERT INTO proof_of_receiving (
            id, por_number, purchase_order_id, po_number,
            supplier_id, supplier_name, receiving_date, receiving_time,
            status, received_by, received_by_name,
            remarks, created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), 'Draft', ?, ?, ?, NOW(), NOW())
    ");
    
    $stmt->execute([
        $porId,
        $porNumber,
        $poId,
        $poNumber,
        $supplierId,  // MUST match PO supplier
        $supplierName,
        $testUser['id'],
        $testUser['name'],
        'End-to-end test POR'
    ]);
    
    echo "POR Number: $porNumber\n";
    echo "POR ID: $porId\n";
    echo "POR Supplier: $supplierName ($supplierId)\n";
    
    testStep("POR record created", true, $testResults);
    
    echo "\n";
    
    // ============================================================
    // STEP 5: Validate supplier consistency across chain
    // ============================================================
    echo "STEP 5: Validate Complete Transaction Chain\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $chainValidation = validateTransactionSupplierChain($db, $porId);
    
    echo "Chain Validation Results:\n";
    foreach ($chainValidation['checks'] as $check) {
        $status = $check['status'];
        $icon = $status === 'PASS' ? '✓' : ($status === 'FAIL' ? '✗' : '⚠');
        echo "  $icon {$check['check']}: {$check['message']}\n";
    }
    
    testStep("Complete chain validation passed", $chainValidation['valid'], $testResults);
    
    echo "\n";
    
    // ============================================================
    // STEP 6: Verify supplier data matches across all records
    // ============================================================
    echo "STEP 6: Verify Supplier Data Consistency\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    // Get supplier from each level
    $supplierFromMaster = getSupplierDetails($db, $supplierId);
    $supplierFromPO = getSupplierFromPO($db, $poId);
    
    $porStmt = $db->prepare("SELECT supplier_id, supplier_name FROM proof_of_receiving WHERE id = ?");
    $porStmt->execute([$porId]);
    $porSupplier = $porStmt->fetch(PDO::FETCH_ASSOC);
    
    echo "Supplier Master ID: {$supplierFromMaster['id']}\n";
    echo "PO Supplier ID: {$supplierFromPO['supplierId']}\n";
    echo "POR Supplier ID: {$porSupplier['supplier_id']}\n";
    
    $allMatch = (
        $supplierFromMaster['id'] === $supplierFromPO['supplierId'] &&
        $supplierFromPO['supplierId'] === $porSupplier['supplier_id']
    );
    
    testStep("All supplier IDs match across chain", $allMatch, $testResults);
    
    echo "\n";
    
    // ============================================================
    // STEP 7: Test supplier mismatch prevention
    // ============================================================
    echo "STEP 7: Test Supplier Mismatch Prevention\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    // Try to create POR with wrong supplier (should fail validation)
    $wrongSupplierId = 's999';
    $wrongPorData = [
        'purchaseOrderId' => $poId,
        'poNumber' => $poNumber,
        'supplierId' => $wrongSupplierId,
        'supplierName' => 'Wrong Supplier'
    ];
    
    $mismatchValidation = validatePORCreation($db, $wrongPorData);
    
    testStep("Validation correctly rejects mismatched supplier", 
        !$mismatchValidation['valid'], $testResults);
    
    if (!$mismatchValidation['valid']) {
        echo "✓ Correctly blocked with errors:\n";
        foreach ($mismatchValidation['errors'] as $error) {
            echo "  - $error\n";
        }
    }
    
    echo "\n";
    
    // ============================================================
    // STEP 8: Check foreign key constraint
    // ============================================================
    echo "STEP 8: Test Foreign Key Constraint\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    // Try to create POR with non-existent supplier (should fail FK constraint)
    try {
        $fkTestStmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number,
                supplier_id, supplier_name, receiving_date, receiving_time,
                status, received_by, received_by_name,
                created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), 'Draft', ?, ?, NOW(), NOW())
        ");
        
        $fkTestStmt->execute([
            'por_fk_test',
            'POR-FK-TEST',
            $poId,
            $poNumber,
            'INVALID_SUPPLIER_999',
            'Invalid Supplier',
            $testUser['id'],
            $testUser['name']
        ]);
        
        // If we get here, FK constraint didn't work
        testStep("Foreign key constraint prevents invalid supplier", false, $testResults);
        
        // Clean up
        $db->exec("DELETE FROM proof_of_receiving WHERE id = 'por_fk_test'");
        
    } catch (PDOException $e) {
        // FK constraint correctly blocked the insert
        if (strpos($e->getMessage(), 'foreign key constraint') !== false ||
            strpos($e->getMessage(), 'Cannot add or update') !== false) {
            testStep("Foreign key constraint prevents invalid supplier", true, $testResults);
            echo "✓ FK constraint correctly blocked invalid supplier\n";
        } else {
            testStep("Foreign key constraint prevents invalid supplier", false, $testResults);
            echo "✗ Unexpected error: {$e->getMessage()}\n";
        }
    }
    
    echo "\n";
    
    // ============================================================
    // CLEANUP
    // ============================================================
    echo "CLEANUP: Removing Test Data\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $db->exec("DELETE FROM proof_of_receiving WHERE id = '$porId'");
    $db->exec("DELETE FROM purchase_orders WHERE id = '$poId'");
    
    echo "✓ Test data cleaned up\n";
    echo "\n";
    
    // ============================================================
    // FINAL REPORT
    // ============================================================
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "TEST SUMMARY\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "Total Tests: {$testResults['total']}\n";
    echo "Passed: {$testResults['passed']}\n";
    echo "Failed: {$testResults['failed']}\n";
    
    $passRate = round(($testResults['passed'] / $testResults['total']) * 100, 1);
    echo "Pass Rate: $passRate%\n";
    
    echo "\n";
    
    if ($testResults['failed'] === 0) {
        echo "✓✓✓ ALL TESTS PASSED ✓✓✓\n";
        echo "Supplier consistency is enforced throughout the entire flow.\n";
        echo "\nKEY VALIDATIONS CONFIRMED:\n";
        echo "  ✓ Supplier data retrieved from master\n";
        echo "  ✓ PO references valid supplier\n";
        echo "  ✓ POR auto-populates supplier from PO\n";
        echo "  ✓ Supplier consistency validated at POR creation\n";
        echo "  ✓ Complete transaction chain validated\n";
        echo "  ✓ Supplier IDs match across all records\n";
        echo "  ✓ Mismatched suppliers correctly rejected\n";
        echo "  ✓ Foreign key constraint enforced\n";
    } else {
        echo "⚠⚠⚠ SOME TESTS FAILED ⚠⚠⚠\n";
        echo "Review failed tests above for details.\n";
    }
    
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    echo "\n✗ TEST EXECUTION ERROR:\n";
    echo $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
?>
