<?php
/**
 * Add Products Script
 * This script adds 33 new Korean/Asian products to the RAMYUM inventory
 */

require_once __DIR__ . '/config/database.php';

?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Products - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        h2 { color: #FF7A00; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #FF7A00; color: white; }
        tr:nth-child(even) { background-color: #f2f2f2; }
        .status-in-stock { background-color: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px; }
        .status-low-stock { background-color: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 4px; }
        .price { text-align: right; }
        .stock { text-align: center; }
    </style>
</head>
<body>
    <h1>RAMYUM Product Addition</h1>

<?php
try {
    $pdo = get_database_connection();
    
    echo "<h2>Adding New Products...</h2>";
    
    // Define all products to add
    $products = [
        // Instant Noodles
        ['id' => 'RAM001', 'name' => 'Samyang Buldak Cheese', 'category' => 'Instant Noodles', 'price' => 55.00, 'stock' => 50, 'batch' => 'BT202608001', 'expiry_months' => 12],
        ['id' => 'RAM002', 'name' => 'Samyang Buldak Quattro Cheese', 'category' => 'Instant Noodles', 'price' => 75.00, 'stock' => 40, 'batch' => 'BT202608002', 'expiry_months' => 12],
        ['id' => 'RAM003', 'name' => 'Samyang Buldak Carbo', 'category' => 'Instant Noodles', 'price' => 60.00, 'stock' => 45, 'batch' => 'BT202608003', 'expiry_months' => 12],
        ['id' => 'RAM004', 'name' => 'Samyang Buldak Cream Carbo', 'category' => 'Instant Noodles', 'price' => 65.00, 'stock' => 35, 'batch' => 'BT202608004', 'expiry_months' => 12],
        ['id' => 'RAM005', 'name' => 'Samyang Buldak Rose', 'category' => 'Instant Noodles', 'price' => 75.00, 'stock' => 30, 'batch' => 'BT202608005', 'expiry_months' => 12],
        ['id' => 'RAM006', 'name' => 'Samyang Buldak Black Original', 'category' => 'Instant Noodles', 'price' => 55.00, 'stock' => 55, 'batch' => 'BT202608006', 'expiry_months' => 12],
        ['id' => 'RAM007', 'name' => 'Ottogi Cheese Ramen', 'category' => 'Instant Noodles', 'price' => 55.00, 'stock' => 40, 'batch' => 'BT202608007', 'expiry_months' => 12],
        ['id' => 'RAM008', 'name' => 'Ottogi Cheese Stir Fry', 'category' => 'Instant Noodles', 'price' => 65.00, 'stock' => 30, 'batch' => 'BT202608008', 'expiry_months' => 12],
        ['id' => 'RAM009', 'name' => 'Jin Ramen Spicy', 'category' => 'Instant Noodles', 'price' => 45.00, 'stock' => 60, 'batch' => 'BT202608009', 'expiry_months' => 12],
        ['id' => 'RAM010', 'name' => 'Jin Ramen Mild', 'category' => 'Instant Noodles', 'price' => 45.00, 'stock' => 50, 'batch' => 'BT202608010', 'expiry_months' => 12],
        ['id' => 'RAM011', 'name' => 'Shin Ramyun', 'category' => 'Instant Noodles', 'price' => 60.00, 'stock' => 45, 'batch' => 'BT202608011', 'expiry_months' => 12],
        ['id' => 'RAM012', 'name' => 'Shin Black', 'category' => 'Instant Noodles', 'price' => 95.00, 'stock' => 25, 'batch' => 'BT202608012', 'expiry_months' => 12],
        
        // Meat & Seafood
        ['id' => 'MEAT001', 'name' => 'Beef Bulgogi (500g)', 'category' => 'Meat & Seafood', 'price' => 320.00, 'stock' => 20, 'batch' => 'BT202608013', 'expiry_months' => 6],
        ['id' => 'MEAT002', 'name' => 'Lotte Luncheon Meat (340g)', 'category' => 'Meat & Seafood', 'price' => 120.00, 'stock' => 35, 'batch' => 'BT202608014', 'expiry_months' => 18],
        ['id' => 'MEAT003', 'name' => 'Korean Sausage', 'category' => 'Meat & Seafood', 'price' => 220.00, 'stock' => 18, 'batch' => 'BT202608016', 'expiry_months' => 3],
        ['id' => 'SEA001', 'name' => 'Fish Cake (500g)', 'category' => 'Meat & Seafood', 'price' => 170.00, 'stock' => 25, 'batch' => 'BT202608015', 'expiry_months' => 4],
        
        // Condiments & Sauces
        ['id' => 'OIL001', 'name' => 'Sesame Oil (1L)', 'category' => 'Condiments & Sauces', 'price' => 450.00, 'stock' => 15, 'batch' => 'BT202608017', 'expiry_months' => 24],
        ['id' => 'SAU001', 'name' => 'Bulgogi Sauce', 'category' => 'Condiments & Sauces', 'price' => 160.00, 'stock' => 28, 'batch' => 'BT202608018', 'expiry_months' => 18],
        
        // Rice & Pantry
        ['id' => 'PAN001', 'name' => 'Kimchi (500g)', 'category' => 'Rice & Pantry', 'price' => 180.00, 'stock' => 22, 'batch' => 'BT202608019', 'expiry_months' => 2],
        ['id' => 'PAN002', 'name' => 'Nori Seaweed', 'category' => 'Rice & Pantry', 'price' => 80.00, 'stock' => 40, 'batch' => 'BT202608020', 'expiry_months' => 12],
        
        // Snacks
        ['id' => 'SNK001', 'name' => 'Pepero', 'category' => 'Snacks', 'price' => 55.00, 'stock' => 60, 'batch' => 'BT202608021', 'expiry_months' => 9],
        ['id' => 'SNK002', 'name' => 'Lotte Binch', 'category' => 'Snacks', 'price' => 130.00, 'stock' => 30, 'batch' => 'BT202608022', 'expiry_months' => 8],
        ['id' => 'SNK003', 'name' => 'Snickers', 'category' => 'Snacks', 'price' => 45.00, 'stock' => 50, 'batch' => 'BT202608023', 'expiry_months' => 6],
        ['id' => 'SNK004', 'name' => 'Mars', 'category' => 'Snacks', 'price' => 45.00, 'stock' => 45, 'batch' => 'BT202608024', 'expiry_months' => 6],
        
        // Beverages
        ['id' => 'DRK001', 'name' => 'Welch\'s Grape', 'category' => 'Beverages', 'price' => 55.00, 'stock' => 35, 'batch' => 'BT202608025', 'expiry_months' => 12],
        ['id' => 'DRK002', 'name' => 'Welch\'s Strawberry', 'category' => 'Beverages', 'price' => 55.00, 'stock' => 30, 'batch' => 'BT202608026', 'expiry_months' => 12],
        ['id' => 'DRK003', 'name' => 'Welch\'s Peach', 'category' => 'Beverages', 'price' => 55.00, 'stock' => 28, 'batch' => 'BT202608027', 'expiry_months' => 12],
        ['id' => 'DRK004', 'name' => 'Pororo Apple', 'category' => 'Beverages', 'price' => 45.00, 'stock' => 40, 'batch' => 'BT202608028', 'expiry_months' => 10],
        ['id' => 'DRK005', 'name' => 'Pororo Milk', 'category' => 'Beverages', 'price' => 45.00, 'stock' => 35, 'batch' => 'BT202608029', 'expiry_months' => 6],
        ['id' => 'DRK006', 'name' => 'Pororo Blueberry', 'category' => 'Beverages', 'price' => 45.00, 'stock' => 32, 'batch' => 'BT202608030', 'expiry_months' => 10],
        ['id' => 'DRK007', 'name' => 'Coldtalk Peach', 'category' => 'Beverages', 'price' => 60.00, 'stock' => 25, 'batch' => 'BT202608031', 'expiry_months' => 8],
        ['id' => 'DRK008', 'name' => 'Coldtalk Grape', 'category' => 'Beverages', 'price' => 60.00, 'stock' => 25, 'batch' => 'BT202608032', 'expiry_months' => 8],
        ['id' => 'DRK009', 'name' => 'Coldtalk Lychee', 'category' => 'Beverages', 'price' => 60.00, 'stock' => 20, 'batch' => 'BT202608033', 'expiry_months' => 8]
    ];
    
    $addedCount = 0;
    $skippedCount = 0;
    
    foreach ($products as $product) {
        // Check if product already exists
        $checkStmt = $pdo->prepare("SELECT id FROM products WHERE id = ?");
        $checkStmt->execute([$product['id']]);
        
        if ($checkStmt->fetch()) {
            echo "<p style='color: orange;'>⚠️ Product {$product['id']} ({$product['name']}) already exists - skipping</p>";
            $skippedCount++;
            continue;
        }
        
        // Determine reorder level and status
        $reorderLevel = match($product['category']) {
            'Instant Noodles' => $product['stock'] <= 30 ? 15 : 20,
            'Meat & Seafood' => $product['stock'] <= 20 ? 5 : 8,
            'Condiments & Sauces' => 10,
            'Rice & Pantry' => $product['stock'] <= 25 ? 8 : 15,
            'Snacks' => $product['stock'] <= 35 ? 10 : 20,
            'Beverages' => $product['stock'] <= 30 ? 10 : 15,
            default => 10
        };
        
        $status = $product['stock'] <= $reorderLevel ? 'Low Stock' : 'In Stock';
        
        // Calculate expiration date
        $expirationDate = date('Y-m-d', strtotime("+{$product['expiry_months']} months"));
        
        // Create appropriate description
        $pname = $product['name'];
        $has = fn(string $needle): bool => str_contains($pname, $needle);
        switch ($product['category']) {
            case 'Instant Noodles':
                $description = $has('Samyang') ? 'Korean spicy instant noodles'
                    : ($has('Shin') ? 'Popular Korean ramen' : 'Korean instant noodles');
                break;
            case 'Meat & Seafood':
                $description = $has('Bulgogi') ? 'Marinated Korean beef, frozen'
                    : ($has('Sausage') ? 'Traditional Korean style sausage'
                    : ($has('Fish Cake') ? 'Korean fish cake for soup and hot pot' : 'Korean meat product'));
                break;
            case 'Condiments & Sauces':
                $description = $has('Oil') ? 'Premium cooking oil' : 'Korean sauce and marinade';
                break;
            case 'Rice & Pantry':
                $description = $has('Kimchi') ? 'Traditional Korean fermented cabbage' : 'Korean pantry staple';
                break;
            case 'Snacks':
                $description = $has('Pepero') ? 'Korean chocolate covered biscuit sticks'
                    : ($has('Korean') ? 'Korean snack' : 'Popular snack');
                break;
            case 'Beverages':
                $description = $has('Pororo') ? 'Korean brand juice drink'
                    : ($has('Coldtalk') ? 'Korean premium drink' : 'Fruit juice drink');
                break;
            default:
                $description = 'Korean food product';
        }
        
        // Assign supplier (Korean products to s1, others to s2)
        $supplierId = (str_contains($product['name'], 'Samyang') || str_contains($product['name'], 'Ottogi') || 
                      str_contains($product['name'], 'Jin') || str_contains($product['name'], 'Shin') ||
                      str_contains($product['name'], 'Korean') || str_contains($product['name'], 'Lotte') ||
                      str_contains($product['name'], 'Pepero') || str_contains($product['name'], 'Pororo') ||
                      str_contains($product['name'], 'Coldtalk') || str_contains($product['name'], 'Bulgogi') ||
                      str_contains($product['name'], 'Kimchi') || str_contains($product['name'], 'Sesame')) ? 's1' : 's2';
        
        // ====== ADD PRODUCT IMAGES HERE ======
        // Map product IDs to image filenames
        $imageFile = match($product['id']) {
            // Instant Noodles
            'RAM001' => 'samyang-cheese.jpg',
            'RAM002' => 'samyang-quattro.jpg',
            'RAM003' => 'samyang-carbo.jpg',
            'RAM004' => 'samyang-cream-carbo.jpg',
            'RAM005' => 'samyang-rose.jpg',
            'RAM006' => 'samyang-black.jpg',
            'RAM007' => 'ottogi-cheese-ramen.jpg',
            'RAM008' => 'ottogi-cheese-stirfry.jpg',
            'RAM009' => 'jin-ramen-spicy.jpg',
            'RAM010' => 'jin-ramen-mild.jpg',
            'RAM011' => 'shin-ramyun.jpg',
            'RAM012' => 'shin-black.jpg',
            
            // Meat & Seafood
            'MEAT001' => 'beef-bulgogi.jpg',
            'MEAT002' => 'lotte-luncheon-meat.jpg',
            'MEAT003' => 'korean-sausage.jpg',
            'SEA001' => 'fish-cake.jpg',
            
            // Condiments & Sauces
            'OIL001' => 'sesame-oil.jpg',
            'SAU001' => 'bulgogi-sauce.jpg',
            
            // Rice & Pantry
            'PAN001' => 'kimchi.jpg',
            'PAN002' => 'nori-seaweed.jpg',
            
            // Snacks
            'SNK001' => 'pepero.jpg',
            'SNK002' => 'lotte-binch.jpg',
            'SNK003' => 'snickers.jpg',
            'SNK004' => 'mars.jpg',
            
            // Beverages
            'DRK001' => 'uploads/product-images/welchs-grape.jpg',
            'DRK002' => 'welchs-strawberry.jpg',
            'DRK003' => 'welchs-peach.jpg',
            'DRK004' => 'pororo-apple.jpg',
            'DRK005' => 'pororo-milk.jpg',
            'DRK006' => 'pororo-blueberry.jpg',
            'DRK007' => 'coldtalk-peach.jpg',
            'DRK008' => 'coldtalk-grape.jpg',
            'DRK009' => 'coldtalk-lychee.jpg',
            
            // Default fallback image
            default => 'product-default.jpg'
        };
        
        // Build image path (put your images in: assets/images/products/)
        $imagePath = 'assets/images/products/' . $imageFile;
        // ====== END IMAGE MAPPING ======
        
        // Create JSON data
        $jsonData = json_encode([
            'id' => $product['id'],
            'name' => $product['name'],
            'sku' => $product['id'],
            'category' => $product['category'],
            'price' => $product['price'],
            'stock' => $product['stock'],
            'reorderLevel' => $reorderLevel,
            'status' => $status,
            'description' => $description,
            'image' => $imagePath,  // ← IMAGE ADDED HERE
            'lastUpdated' => date('Y-m-d\TH:i:s.000\Z'),
            'supplierId' => $supplierId,
            'expirationDate' => $expirationDate,
            'batchNumber' => $product['batch'],
            'archived' => false
        ]);
        
        // Insert product
        $stmt = $pdo->prepare("INSERT INTO products (id, data) VALUES (?, ?)");
        if ($stmt->execute([$product['id'], $jsonData])) {
            echo "<p style='color: green;'>✅ Added: {$product['id']} - {$product['name']}</p>";
            $addedCount++;
        } else {
            echo "<p style='color: red;'>❌ Failed to add: {$product['id']} - {$product['name']}</p>";
        }
    }
    
    echo "<h2>Summary</h2>";
    echo "<p><strong>Products added:</strong> {$addedCount}</p>";
    echo "<p><strong>Products skipped (already exist):</strong> {$skippedCount}</p>";
    echo "<p><strong>Total products processed:</strong> " . count($products) . "</p>";
    
    // Display all added products
    echo "<h2>Product Inventory Summary</h2>";
    $stmt = $pdo->prepare("
        SELECT id, data FROM products 
        WHERE id LIKE 'RAM%' OR id LIKE 'MEAT%' OR id LIKE 'SEA%' OR id LIKE 'OIL%' OR id LIKE 'SAU%' OR id LIKE 'PAN%' OR id LIKE 'SNK%' OR id LIKE 'DRK%'
        ORDER BY id
    ");
    $stmt->execute();
    
    echo "<table>";
    echo "<tr><th>SKU</th><th>Product Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th>Expiry Date</th><th>Batch</th></tr>";
    
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $data = json_decode($row['data'], true);
        $statusClass = $data['status'] === 'Low Stock' ? 'status-low-stock' : 'status-in-stock';
        
        echo "<tr>";
        echo "<td>{$data['sku']}</td>";
        echo "<td>{$data['name']}</td>";
        echo "<td>{$data['category']}</td>";
        echo "<td class='price'>₱" . number_format($data['price'], 2) . "</td>";
        echo "<td class='stock'>{$data['stock']}</td>";
        echo "<td><span class='{$statusClass}'>{$data['status']}</span></td>";
        echo "<td>{$data['expirationDate']}</td>";
        echo "<td>{$data['batchNumber']}</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

    <hr>
    <h3>Categories Summary:</h3>
    <ul>
        <li><strong>Instant Noodles:</strong> 12 products (RAM001-RAM012) - Samyang Buldak series, Ottogi, Jin Ramen, Shin varieties</li>
        <li><strong>Meat & Seafood:</strong> 4 products (MEAT001-MEAT003, SEA001) - Bulgogi, luncheon meat, sausage, fish cake</li>
        <li><strong>Condiments & Sauces:</strong> 2 products (OIL001, SAU001) - Sesame oil, bulgogi sauce</li>
        <li><strong>Rice & Pantry:</strong> 2 products (PAN001-PAN002) - Kimchi, nori seaweed</li>
        <li><strong>Snacks:</strong> 4 products (SNK001-SNK004) - Pepero, Lotte Binch, Snickers, Mars</li>
        <li><strong>Beverages:</strong> 9 products (DRK001-DRK009) - Welch's varieties, Pororo drinks, Coldtalk premium drinks</li>
    </ul>

    <h3>Important Notes:</h3>
    <ul>
        <li>All products have appropriate expiration dates based on product type</li>
        <li>Stock levels automatically determine reorder points</li>
        <li>Korean products are assigned to Seoul Trading Co. (s1)</li>
        <li>International brands are assigned to Osaka Premium Imports (s2)</li>
        <li>Products with stock at/below reorder level show "Low Stock" status</li>
        <li>Each product has a unique batch number for traceability</li>
    </ul>

    <p><strong>Security Note:</strong> Delete this script (<code>add-products.php</code>) after use.</p>
</body>
</html>