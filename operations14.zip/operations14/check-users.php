<?php
/**
 * Check User System Status
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config/database.php';

$db = getDB();

echo "USER SYSTEM CHECK\n";
echo str_repeat("=", 80) . "\n\n";

// 1. Check users table structure
echo "1. USERS TABLE STRUCTURE:\n";
echo str_repeat("-", 80) . "\n";
try {
    $stmt = $db->query("DESCRIBE users");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("  %-25s %-20s %s %s\n", 
            $col['Field'], 
            $col['Type'],
            $col['Null'] === 'NO' ? 'NOT NULL' : 'NULL',
            $col['Key'] ? "[$col[Key]]" : ""
        );
    }
} catch (Exception $e) {
    echo "  ERROR: " . $e->getMessage() . "\n";
}

// 2. Check existing users
echo "\n2. EXISTING USERS:\n";
echo str_repeat("-", 80) . "\n";
try {
    $stmt = $db->query("SELECT id, name, email, username, role, verified FROM users");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($users) > 0) {
        foreach ($users as $user) {
            echo "  User: {$user['username']} ({$user['name']})\n";
            echo "    ID: {$user['id']}\n";
            echo "    Email: {$user['email']}\n";
            echo "    Role: {$user['role']}\n";
            echo "    Verified: " . ($user['verified'] ? 'Yes' : 'No') . "\n";
            echo "\n";
        }
    } else {
        echo "  ⚠ No users found!\n";
    }
} catch (Exception $e) {
    echo "  ERROR: " . $e->getMessage() . "\n";
}

// 3. Check password hashes
echo "3. PASSWORD HASH CHECK:\n";
echo str_repeat("-", 80) . "\n";
try {
    $stmt = $db->query("SELECT username, password_hash FROM users LIMIT 3");
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($users as $user) {
        $hashLength = strlen($user['password_hash']);
        $hashType = $hashLength >= 60 ? 'Bcrypt' : 'Unknown/Weak';
        echo "  {$user['username']}: $hashType ($hashLength chars)\n";
    }
} catch (Exception $e) {
    echo "  ERROR: " . $e->getMessage() . "\n";
}

// 4. Test login credentials
echo "\n4. TEST LOGIN:\n";
echo str_repeat("-", 80) . "\n";
$testCredentials = [
    ['username' => 'admin', 'password' => 'admin123'],
    ['username' => 'manager', 'password' => 'manager123'],
    ['username' => 'staff', 'password' => 'staff123']
];

foreach ($testCredentials as $cred) {
    echo "  Testing: {$cred['username']} / {$cred['password']}\n";
    
    try {
        $stmt = $db->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
        $stmt->execute([$cred['username']]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            if (password_verify($cred['password'], $user['password_hash'])) {
                echo "    ✓ Login successful\n";
            } else {
                echo "    ✗ Password incorrect\n";
                echo "    Hash: " . substr($user['password_hash'], 0, 20) . "...\n";
            }
        } else {
            echo "    ✗ User not found\n";
        }
    } catch (Exception $e) {
        echo "    ERROR: " . $e->getMessage() . "\n";
    }
    echo "\n";
}

// 5. Check session/auth system
echo "5. AUTH SYSTEM FILES:\n";
echo str_repeat("-", 80) . "\n";
$authFiles = [
    'includes/auth.php',
    'api/login.php',
    'api/logout.php',
    'api/users.php',
    'index.php',
    'dashboard.php'
];

foreach ($authFiles as $file) {
    $exists = file_exists($file) ? '✓' : '✗';
    echo "  $exists $file\n";
}

echo "\n" . str_repeat("=", 80) . "\n";
echo "CHECK COMPLETE\n";
