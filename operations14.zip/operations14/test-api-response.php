<?php
session_start();

// Simulate logged-in user
$_SESSION['user'] = [
    'id' => 'u1',
    'username' => 'admin',
    'name' => 'Admin User',
    'email' => 'admin@ramyum.com',
    'role' => 'admin'
];

// Test the API endpoint
$url = 'http://localhost/operations2/api/stock-transfers.php?action=transfers';

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HEADER, true);
curl_setopt($ch, CURLOPT_COOKIE, session_name() . '=' . session_id());

$response = curl_exec($ch);
$headerSize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$headers = substr($response, 0, $headerSize);
$body = substr($response, $headerSize);

echo "HTTP Code: $httpCode\n\n";
echo "Headers:\n$headers\n";
echo "Body:\n$body\n";

// Try to decode JSON
$json = json_decode($body, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo "\nJSON Error: " . json_last_error_msg() . "\n";
} else {
    echo "\nJSON Valid: " . print_r($json, true) . "\n";
}
