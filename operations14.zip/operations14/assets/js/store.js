class Store {
    constructor() {
        this.state = { user: null, role: null, isAuthenticated: false, theme: 'light', isLoading: false, notifications: [], sidebarOpen: window.innerWidth > 768 };
        this.subscribers = [];
    }
    getState() { return this.state; }
    dispatch(newState) { this.state = { ...this.state, ...newState }; this.notify(); }
    subscribe(callback) {
        this.subscribers.push(callback);
        callback(this.state);
        return () => { this.subscribers = this.subscribers.filter(sub => sub !== callback); };
    }
    notify() { this.subscribers.forEach(callback => callback(this.state)); }
}
export const store = new Store();