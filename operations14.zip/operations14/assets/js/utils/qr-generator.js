/**
 * QR Code Generator Utility
 * Generates QR codes for stock transfer POD using qrcode.js library
 * Library: https://davidshimjs.github.io/qrcodejs/
 */

export class QRGenerator {
    /**
     * Generate QR code as Data URL
     * @param {string} text - Text to encode in QR code
     * @param {number} size - Size of QR code (default: 256)
     * @returns {Promise<string>} Data URL of QR code image
     */
    static async generateDataURL(text, size = 256) {
        return new Promise((resolve, reject) => {
            try {
                // Create temporary container
                const tempDiv = document.createElement('div');
                tempDiv.style.display = 'none';
                document.body.appendChild(tempDiv);

                // Generate QR code using QRCode.js
                const qrcode = new QRCode(tempDiv, {
                    text: text,
                    width: size,
                    height: size,
                    colorDark: "#000000",
                    colorLight: "#ffffff",
                    correctLevel: QRCode.CorrectLevel.H
                });

                // Wait for image to be generated
                setTimeout(() => {
                    const img = tempDiv.querySelector('img');
                    if (img && img.src) {
                        const dataURL = img.src;
                        document.body.removeChild(tempDiv);
                        resolve(dataURL);
                    } else {
                        document.body.removeChild(tempDiv);
                        reject(new Error('Failed to generate QR code'));
                    }
                }, 100);
            } catch (error) {
                reject(error);
            }
        });
    }

    /**
     * Generate QR code and display in a container
     * @param {string} containerId - ID of container element
     * @param {string} text - Text to encode in QR code
     * @param {number} size - Size of QR code (default: 256)
     */
    static generateInContainer(containerId, text, size = 256) {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`Container ${containerId} not found`);
            return;
        }

        // Clear previous content
        container.innerHTML = '';

        // Generate QR code
        try {
            new QRCode(container, {
                text: text,
                width: size,
                height: size,
                colorDark: "#000000",
                colorLight: "#ffffff",
                correctLevel: QRCode.CorrectLevel.H
            });
        } catch (error) {
            console.error('Failed to generate QR code:', error);
            container.innerHTML = '<p style="color:red;">Failed to generate QR code</p>';
        }
    }

    /**
     * Generate POD QR code URL for stock transfer
     * @param {string} qrToken - POD QR token
     * @returns {string} Full URL for POD scanning
     */
    static generatePODUrl(qrToken) {
        const baseUrl = window.location.origin;
        return `${baseUrl}/scan-pod.php?token=${encodeURIComponent(qrToken)}`;
    }

    /**
     * Download QR code as image
     * @param {string} dataURL - QR code data URL
     * @param {string} filename - Filename for download
     */
    static downloadQRCode(dataURL, filename = 'qr-code.png') {
        const link = document.createElement('a');
        link.href = dataURL;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    /**
     * Check if QRCode library is loaded
     * @returns {boolean}
     */
    static isLibraryLoaded() {
        return typeof QRCode !== 'undefined';
    }

    /**
     * Load QRCode library dynamically
     * @returns {Promise<void>}
     */
    static async loadLibrary() {
        if (this.isLibraryLoaded()) {
            return Promise.resolve();
        }

        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js';
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Failed to load QRCode library'));
            document.head.appendChild(script);
        });
    }
}
