import { store } from '../store.js';

export class ToastManager {
    constructor() {
        this.container = document.createElement('div');
        this.container.id = 'toast-container';
        this.container.style.cssText = `
            position: fixed; top: 20px; right: 20px; z-index: 9999;
            display: flex; flex-direction: column; gap: 10px;
            max-width: min(420px, calc(100vw - 32px));
            pointer-events: none;
        `;
        document.body.appendChild(this.container);
        this.injectStyles();
    }

    injectStyles() {
        if (document.getElementById('toast-styles')) return;
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            @keyframes toastSlideIn {
                from { transform: translateX(120%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            @keyframes toastSlideOut {
                from { transform: translateX(0); opacity: 1; }
                to { transform: translateX(120%); opacity: 0; }
            }
            .ramyum-toast {
                pointer-events: auto;
                background: var(--bg-white, #fff);
                color: var(--text-primary, #1B2A4A);
                padding: 14px 16px;
                border-radius: 12px;
                box-shadow: 0 10px 30px rgba(27, 42, 74, 0.12), 0 2px 8px rgba(227, 28, 35, 0.06);
                border: 1px solid var(--border-color, #E8E0D0);
                border-left-width: 4px;
                display: flex;
                align-items: flex-start;
                gap: 12px;
                min-width: 260px;
                animation: toastSlideIn 0.28s cubic-bezier(0.22, 1, 0.36, 1) forwards;
                font-family: inherit;
                font-size: 0.9rem;
                line-height: 1.45;
            }
            .ramyum-toast-msg { flex: 1; white-space: pre-wrap; word-break: break-word; }
            .ramyum-toast-close {
                background: transparent; border: none; cursor: pointer;
                color: var(--text-muted, #94A3B8); font-size: 1.1rem; line-height: 1;
                padding: 0 2px; flex-shrink: 0;
            }
            .ramyum-toast-close:hover { color: var(--text-primary, #1B2A4A); }
        `;
        document.head.appendChild(style);
    }

    _escape(str) {
        return String(str ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    show(message, type = 'info', duration = 4000) {
        const colors = {
            success: '#10B981',
            error: '#E31C23',
            warning: '#F5C518',
            info: '#2563EB'
        };
        const iconMap = {
            success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.2"><path d="M20 6L9 17l-5-5"/></svg>',
            error: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#E31C23" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>',
            warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#D4A017" stroke-width="2"><path d="M12 9v4M12 17h.01"/><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/></svg>',
            info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>'
        };

        const toast = document.createElement('div');
        toast.className = 'ramyum-toast';
        toast.style.borderLeftColor = colors[type] || colors.info;
        toast.innerHTML = `
            <div style="flex-shrink:0;margin-top:1px;">${iconMap[type] || iconMap.info}</div>
            <div class="ramyum-toast-msg">${this._escape(message)}</div>
            <button type="button" class="ramyum-toast-close" aria-label="Dismiss">&times;</button>
        `;

        const dismiss = () => {
            toast.style.animation = 'toastSlideOut 0.25s ease forwards';
            setTimeout(() => toast.remove(), 250);
        };

        toast.querySelector('.ramyum-toast-close').addEventListener('click', dismiss);
        this.container.appendChild(toast);

        while (this.container.children.length > 4) {
            this.container.firstChild.remove();
        }

        if (duration > 0) {
            setTimeout(dismiss, duration);
        }
        return toast;
    }
}

export const toast = new ToastManager();
