<?php
/**
 * FIX PRODUCT CATALOG ISSUES
 * - Check and fix image paths
 * - Validate cost prices
 * - Ensure min/max stock limits
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "PRODUCT CATALOG FIX SCRIPT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. Check upload directory
$uploadDir = 'uploads/product-images';
if (!is_dir($uploadDir)) {
    echo "Creating upload directory: {$uploadDir}\n";
    if (!mkdir($uploadDir, 0755, true)) {
        echo "⚠ Failed to create directory\n";
    } else {
        echo "✓ Directory created\n";
    }
} else {
    echo "✓ Upload directory exists: {$uploadDir}\n";
    $files = glob($uploadDir . '/*');
    echo "  Files in directory: " . count($files) . "\n";
}

echo "\n";

// 2. Audit products
echo "Auditing Products:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT id, data FROM products");
$products = $stmt->fetchAll();

$totalProducts = count($products);
$missingImages = 0;
$missingCost = 0;
$missingMinMax = 0;
$fixedProducts = 0;

foreach ($products as $row) {
    $data = json_decode($row['data'], true);
    $needsUpdate = false;
    
    // Check image
    if (isset($data['image']) && !empty($data['image'])) {
        if (!file_exists($data['image'])) {
            $missingImages++;
        }
    }
    
    // Check costing price
    if (!isset($data['costingPrice']) || $data['costingPrice'] == 0) {
        $missingCost++;
        // Set default cost to 80% of SRP if SRP exists
        if (isset($data['srp']) && $data['srp'] > 0) {
            $data['costingPrice'] = round($data['srp'] * 0.8, 2);
            $needsUpdate = true;
        }
    }
    
    // Check min/max stock
    if (!isset($data['minimumStock']) || !isset($data['maximumStock'])) {
        $missingMinMax++;
        
        // Set sensible defaults based on reorderLevel if it exists
        if (isset($data['reorderLevel']) && $data['reorderLevel'] > 0) {
            $data['minimumStock'] = $data['reorderLevel'];
            $data['maximumStock'] = $data['reorderLevel'] * 10;
            $needsUpdate = true;
        } else {
            // Generic defaults
            $data['minimumStock'] = 10;
            $data['maximumStock'] = 100;
            $needsUpdate = true;
        }
    }
    
    // Update if needed
    if ($needsUpdate) {
        $data['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
        $updateStmt = $db->prepare("UPDATE products SET data = ?, updated_at = NOW() WHERE id = ?");
        $updateStmt->execute([json_encode($data), $row['id']]);
        $fixedProducts++;
    }
}

echo "Total Products: {$totalProducts}\n";
echo "Products with missing images: {$missingImages}\n";
echo "Products with missing cost price: {$missingCost}\n";
echo "Products with missing min/max stock: {$missingMinMax}\n";
echo "Products fixed: {$fixedProducts}\n";

echo "\n";

// 3. Verify fixes
echo "Verification:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$withCostingPrice = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.costingPrice') IS NOT NULL 
    AND JSON_EXTRACT(data, '$.costingPrice') > 0
")->fetchColumn();

$withMinStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.minimumStock') IS NOT NULL
")->fetchColumn();

$withMaxStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.maximumStock') IS NOT NULL
")->fetchColumn();

echo "✓ Products with costing price: {$withCostingPrice}/{$totalProducts}\n";
echo "✓ Products with minimum stock: {$withMinStock}/{$totalProducts}\n";
echo "✓ Products with maximum stock: {$withMaxStock}/{$totalProducts}\n";

echo "\n";

// 4. Show sample corrected product
echo "Sample Corrected Product:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$sampleStmt = $db->query("SELECT data FROM products LIMIT 1");
$sampleRow = $sampleStmt->fetch();
$sampleData = json_decode($sampleRow['data'], true);

echo "SKU: " . ($sampleData['sku'] ?? 'N/A') . "\n";
echo "Name: " . ($sampleData['name'] ?? 'N/A') . "\n";
echo "Costing Price: ₱" . number_format($sampleData['costingPrice'] ?? 0, 2) . "\n";
echo "SRP: ₱" . number_format($sampleData['srp'] ?? 0, 2) . "\n";
echo "Stock: " . ($sampleData['stock'] ?? 0) . " " . ($sampleData['unit'] ?? 'units') . "\n";
echo "Min Stock: " . ($sampleData['minimumStock'] ?? 'Not set') . "\n";
echo "Max Stock: " . ($sampleData['maximumStock'] ?? 'Not set') . "\n";

echo "\n";

// 5. Stock Status Summary
echo "Stock Status Summary:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$outOfStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') = 0
")->fetchColumn();

$lowStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') > 0 
    AND JSON_EXTRACT(data, '$.stock') < JSON_EXTRACT(data, '$.minimumStock')
")->fetchColumn();

$normalStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') >= JSON_EXTRACT(data, '$.minimumStock')
    AND JSON_EXTRACT(data, '$.stock') <= JSON_EXTRACT(data, '$.maximumStock')
")->fetchColumn();

$overStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') > JSON_EXTRACT(data, '$.maximumStock')
")->fetchColumn();

echo "  Out of Stock: {$outOfStock}\n";
echo "  Low Stock: {$lowStock}\n";
echo "  Normal Stock: {$normalStock}\n";
echo "  Overstock: {$overStock}\n";

echo "\n";

// Summary
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "FIX SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

if ($fixedProducts > 0) {
    echo "✓ Fixed {$fixedProducts} products\n";
    echo "  - Added default costing prices (80% of SRP)\n";
    echo "  - Set minimum/maximum stock levels\n";
} else {
    echo "✓ No fixes needed - all products properly configured\n";
}

echo "\n";

echo "NOTES:\n";
echo "  • Image files are referenced at 'uploads/product-images/'\n";
echo "  • Actual image files need to be uploaded separately\n";
echo "  • Costing prices set to 80% of SRP where missing\n";
echo "  • Min/max stock levels based on reorder level or defaults\n";

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
