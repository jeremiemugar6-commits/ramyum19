<?php
/**
 * System Functionality Test Suite
 * Comprehensive testing of all major system components after database consolidation
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);
set_time_limit(300);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Functionality Test - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1400px; margin: 0 auto; padding: 20px; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .warning { background: #fff3cd; color: #856404; padding: 10px; border-radius: 4px; margin: 10px 0; }
        .info { background: #d1ecf1; color: #0c5460; padding: 10px; border-radius: 4px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .test-section { margin: 20px 0; padding: 15px; border: 1px solid #ddd; border-radius: 4px; }
        .test-pass { border-left: 4px solid #28a745; }
        .test-fail { border-left: 4px solid #dc3545; }
        .test-warning { border-left: 4px solid #ffc107; }
        pre { background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; max-height: 200px; overflow-y: auto; }
        h1 { color: #FF7A00; }
        .module-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; }
        .btn { background: #FF7A00; color: white; padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; }
        .btn:hover { background: #e06600; }
    </style>
</head>
<body>
    <h1>🔍 System Functionality Test Suite</h1>
    <p>Testing all major system components with the centralized <strong>ram_yum_inventory</strong> database.</p>

    <?php
    $testResults = [];
    $moduleResults = [];

    function runTest($testName, $testFunction, $module = 'General') {
        global $testResults, $moduleResults;
        
        if (!isset($moduleResults[$module])) {
            $moduleResults[$module] = ['total' => 0, 'passed' => 0, 'tests' => []];
        }
        
        $moduleResults[$module]['total']++;
        
        try {
            $result = $testFunction();
            $passed = $result['success'] ?? false;
            $message = $result['message'] ?? 'Test completed';
            
            if ($passed) {
                $moduleResults[$module]['passed']++;
            }
            
            $testResults[] = ['name' => $testName, 'module' => $module, 'passed' => $passed, 'message' => $message, 'details' => $result['details'] ?? null];
            $moduleResults[$module]['tests'][] = ['name' => $testName, 'passed' => $passed, 'message' => $message];
            
            return $result;
            
        } catch (Exception $e) {
            $testResults[] = ['name' => $testName, 'module' => $module, 'passed' => false, 'message' => $e->getMessage(), 'details' => null];
            $moduleResults[$module]['tests'][] = ['name' => $testName, 'passed' => false, 'message' => $e->getMessage()];
            
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    // =====================================================================
    // AUTHENTICATION MODULE TESTS
    // =====================================================================

    runTest('User Data Validation', function() {
        $db = getDB();
        
        $users = $db->query("SELECT id, name, email, username, role, verified FROM users")->fetchAll();
        if (empty($users)) {
            return ['success' => false, 'message' => 'No users found in database'];
        }
        
        $requiredRoles = ['admin', 'manager', 'staff'];
        $foundRoles = array_unique(array_column($users, 'role'));
        $missingRoles = array_diff($requiredRoles, $foundRoles);
        
        if (!empty($missingRoles)) {
            return ['success' => false, 'message' => 'Missing required roles: ' . implode(', ', $missingRoles)];
        }
        
        // Check for admin user
        $adminUsers = array_filter($users, function($u) { return $u['role'] === 'admin'; });
        if (empty($adminUsers)) {
            return ['success' => false, 'message' => 'No admin users found'];
        }
        
        return [
            'success' => true,
            'message' => count($users) . ' users found with all required roles',
            'details' => 'Roles: ' . implode(', ', $foundRoles) . "\nAdmin users: " . count($adminUsers)
        ];
    }, 'Authentication');

    runTest('Password Hash Validation', function() {
        $db = getDB();
        
        $users = $db->query("SELECT username, password_hash FROM users LIMIT 3")->fetchAll();
        if (empty($users)) {
            return ['success' => false, 'message' => 'No users to test password hashes'];
        }
        
        foreach ($users as $user) {
            if (empty($user['password_hash']) || strlen($user['password_hash']) < 50) {
                return ['success' => false, 'message' => "User {$user['username']} has invalid password hash"];
            }
            
            if (!password_get_info($user['password_hash'])['algo']) {
                return ['success' => false, 'message' => "User {$user['username']} has unrecognized hash format"];
            }
        }
        
        return ['success' => true, 'message' => 'All user password hashes are valid'];
    }, 'Authentication');

    runTest('OTP System Structure', function() {
        $db = getDB();
        
        // Check table structure
        $columns = $db->query("SHOW COLUMNS FROM otp_codes")->fetchAll();
        $columnNames = array_column($columns, 'Field');
        
        $requiredColumns = ['id', 'user_id', 'code_hash', 'purpose', 'expires_at'];
        $missing = array_diff($requiredColumns, $columnNames);
        
        if (!empty($missing)) {
            return ['success' => false, 'message' => 'OTP table missing columns: ' . implode(', ', $missing)];
        }
        
        // Check foreign key constraint
        $fks = $db->query("
            SELECT CONSTRAINT_NAME, REFERENCED_TABLE_NAME 
            FROM information_schema.KEY_COLUMN_USAGE 
            WHERE TABLE_SCHEMA = DATABASE() 
            AND TABLE_NAME = 'otp_codes' 
            AND REFERENCED_TABLE_NAME IS NOT NULL
        ")->fetchAll();
        
        if (empty($fks)) {
            return ['success' => false, 'message' => 'OTP table missing foreign key constraint to users table'];
        }
        
        return ['success' => true, 'message' => 'OTP system structure is correct'];
    }, 'Authentication');

    // =====================================================================
    // INVENTORY MODULE TESTS
    // =====================================================================

    runTest('Products JSON Structure', function() {
        $db = getDB();
        
        $products = $db->query("SELECT id, data FROM products LIMIT 5")->fetchAll();
        if (empty($products)) {
            return ['success' => false, 'message' => 'No products found to test'];
        }
        
        $requiredFields = ['id', 'name', 'category', 'price', 'stock'];
        
        foreach ($products as $product) {
            $data = json_decode($product['data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return ['success' => false, 'message' => "Product {$product['id']} has invalid JSON"];
            }
            
            foreach ($requiredFields as $field) {
                if (!isset($data[$field])) {
                    return ['success' => false, 'message' => "Product {$product['id']} missing field: $field"];
                }
            }
        }
        
        return [
            'success' => true, 
            'message' => 'All products have valid JSON structure',
            'details' => 'Tested ' . count($products) . ' products'
        ];
    }, 'Inventory');

    runTest('Locations Configuration', function() {
        $db = getDB();
        
        $locations = $db->query("SELECT id, data FROM locations")->fetchAll();
        if (empty($locations)) {
            return ['success' => false, 'message' => 'No locations configured'];
        }
        
        $locationNames = [];
        foreach ($locations as $location) {
            $data = json_decode($location['data'], true);
            if (!isset($data['name']) || !isset($data['type']) || !isset($data['status'])) {
                return ['success' => false, 'message' => "Location {$location['id']} has incomplete data"];
            }
            
            if ($data['status'] !== 'Active') {
                continue; // Skip inactive locations
            }
            
            $locationNames[] = $data['name'];
        }
        
        if (count($locationNames) < 2) {
            return ['success' => false, 'message' => 'Need at least 2 active locations for stock transfers'];
        }
        
        return [
            'success' => true,
            'message' => count($locationNames) . ' active locations configured',
            'details' => 'Active locations: ' . implode(', ', $locationNames)
        ];
    }, 'Inventory');

    runTest('Inventory Locations Data', function() {
        $db = getDB();
        
        $inventory = $db->query("SELECT id, data FROM inventory_locations LIMIT 10")->fetchAll();
        if (empty($inventory)) {
            return ['success' => true, 'message' => 'No inventory data found (acceptable for fresh installation)'];
        }
        
        foreach ($inventory as $inv) {
            $data = json_decode($inv['data'], true);
            $required = ['productId', 'locationId', 'quantity', 'availableQuantity'];
            
            foreach ($required as $field) {
                if (!isset($data[$field])) {
                    return ['success' => false, 'message' => "Inventory record {$inv['id']} missing field: $field"];
                }
            }
            
            if ($data['quantity'] < 0 || $data['availableQuantity'] < 0) {
                return ['success' => false, 'message' => "Inventory record {$inv['id']} has negative quantities"];
            }
        }
        
        return [
            'success' => true,
            'message' => 'Inventory location data structure is valid',
            'details' => 'Tested ' . count($inventory) . ' inventory records'
        ];
    }, 'Inventory');

    // =====================================================================
    // STOCK TRANSFER MODULE TESTS
    // =====================================================================

    runTest('Stock Transfer Audit Structure', function() {
        $db = getDB();
        
        $columns = $db->query("SHOW COLUMNS FROM stock_transfer_audit")->fetchAll();
        $columnNames = array_column($columns, 'Field');
        
        // Check for new structure (API compatible)
        $newColumns = ['action_type', 'user_id', 'user_name', 'details', 'ip_address'];
        $hasNew = array_intersect($newColumns, $columnNames);
        
        // Check for old structure (problematic)
        $oldColumns = ['action', 'performed_by', 'performed_by_name'];
        $hasOld = array_intersect($oldColumns, $columnNames);
        
        if (count($hasNew) !== count($newColumns)) {
            return ['success' => false, 'message' => 'Missing new audit table columns: ' . implode(', ', array_diff($newColumns, $hasNew))];
        }
        
        if (!empty($hasOld)) {
            return ['success' => false, 'message' => 'Old problematic columns still exist: ' . implode(', ', $hasOld)];
        }
        
        // Check details column is JSON type
        $detailsColumn = array_filter($columns, function($c) { return $c['Field'] === 'details'; });
        if (empty($detailsColumn)) {
            return ['success' => false, 'message' => 'Details column not found'];
        }
        
        $detailsType = strtolower(array_values($detailsColumn)[0]['Type']);
        if (strpos($detailsType, 'json') === false) {
            return ['success' => false, 'message' => "Details column should be JSON type, found: $detailsType"];
        }
        
        return ['success' => true, 'message' => 'Stock transfer audit table has correct API-compatible structure'];
    }, 'Stock Transfer');

    runTest('Stock Transfer Data Integrity', function() {
        $db = getDB();
        
        $transfers = $db->query("SELECT id, data FROM stock_transfers LIMIT 5")->fetchAll();
        if (empty($transfers)) {
            return ['success' => true, 'message' => 'No stock transfers found (acceptable for fresh installation)'];
        }
        
        foreach ($transfers as $transfer) {
            $data = json_decode($transfer['data'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                return ['success' => false, 'message' => "Transfer {$transfer['id']} has invalid JSON"];
            }
            
            $required = ['transferNumber', 'sourceLocationId', 'destinationLocationId', 'status', 'items'];
            foreach ($required as $field) {
                if (!isset($data[$field])) {
                    return ['success' => false, 'message' => "Transfer {$transfer['id']} missing field: $field"];
                }
            }
            
            if (!is_array($data['items']) || empty($data['items'])) {
                return ['success' => false, 'message' => "Transfer {$transfer['id']} has invalid items array"];
            }
        }
        
        return [
            'success' => true,
            'message' => 'Stock transfer data integrity verified',
            'details' => 'Tested ' . count($transfers) . ' transfers'
        ];
    }, 'Stock Transfer');

    // =====================================================================
    // API ENDPOINT TESTS
    // =====================================================================

    runTest('Data API Collection Access', function() {
        $collections = [
            'categories', 'suppliers', 'products', 'inventory_movements',
            'purchase_orders', 'receivings', 'stock_transfers', 'stock_adjustments'
        ];
        
        $db = getDB();
        $accessible = [];
        $errors = [];
        
        foreach ($collections as $collection) {
            try {
                $count = $db->query("SELECT COUNT(*) FROM `$collection`")->fetchColumn();
                $accessible[] = "$collection ($count records)";
            } catch (Exception $e) {
                $errors[] = "$collection: " . $e->getMessage();
            }
        }
        
        if (!empty($errors)) {
            return [
                'success' => false,
                'message' => 'Some collections not accessible',
                'details' => 'Errors: ' . implode(', ', $errors)
            ];
        }
        
        return [
            'success' => true,
            'message' => 'All API collections accessible',
            'details' => implode(', ', $accessible)
        ];
    }, 'API');

    runTest('JSON Query Performance', function() {
        $db = getDB();
        
        // Test JSON extraction query performance
        $start = microtime(true);
        
        $products = $db->query("
            SELECT 
                id,
                JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as name,
                JSON_UNQUOTE(JSON_EXTRACT(data, '$.category')) as category,
                JSON_EXTRACT(data, '$.price') as price
            FROM products 
            LIMIT 10
        ")->fetchAll();
        
        $queryTime = microtime(true) - $start;
        
        if ($queryTime > 1.0) {
            return [
                'success' => false,
                'message' => 'JSON query too slow: ' . round($queryTime * 1000, 2) . 'ms'
            ];
        }
        
        return [
            'success' => true,
            'message' => 'JSON query performance acceptable: ' . round($queryTime * 1000, 2) . 'ms',
            'details' => 'Retrieved ' . count($products) . ' products with JSON extraction'
        ];
    }, 'API');

    // =====================================================================
    // SECURITY & LOGGING TESTS
    // =====================================================================

    runTest('Security Logging Function', function() {
        $db = getDB();
        
        $initialCount = $db->query("SELECT COUNT(*) FROM security_logs")->fetchColumn();
        
        // Test logging function
        log_security_event('SYSTEM_TEST', 'test_user', 'Test User', ['test' => true, 'timestamp' => time()]);
        
        $newCount = $db->query("SELECT COUNT(*) FROM security_logs")->fetchColumn();
        
        if ($newCount <= $initialCount) {
            return ['success' => false, 'message' => 'Security logging function not working'];
        }
        
        $lastLog = $db->query("
            SELECT event_type, user_id, details, created_at 
            FROM security_logs 
            ORDER BY created_at DESC 
            LIMIT 1
        ")->fetch();
        
        if ($lastLog['event_type'] !== 'SYSTEM_TEST') {
            return ['success' => false, 'message' => 'Security log not recorded correctly'];
        }
        
        $details = json_decode($lastLog['details'], true);
        if (!isset($details['test']) || $details['test'] !== true) {
            return ['success' => false, 'message' => 'Security log details not stored correctly'];
        }
        
        return ['success' => true, 'message' => 'Security logging function working correctly'];
    }, 'Security');

    runTest('Login Attempts Table', function() {
        $db = getDB();
        
        // Check structure
        $columns = $db->query("SHOW COLUMNS FROM login_attempts")->fetchAll();
        $columnNames = array_column($columns, 'Field');
        
        $required = ['identifier', 'attempt_count', 'last_attempt'];
        $missing = array_diff($required, $columnNames);
        
        if (!empty($missing)) {
            return ['success' => false, 'message' => 'Login attempts table missing columns: ' . implode(', ', $missing)];
        }
        
        return ['success' => true, 'message' => 'Login attempts table structure correct'];
    }, 'Security');

    // =====================================================================
    // DISPLAY RESULTS
    // =====================================================================
    
    $totalTests = count($testResults);
    $passedTests = count(array_filter($testResults, function($r) { return $r['passed']; }));
    $successRate = $totalTests > 0 ? round(($passedTests / $totalTests) * 100, 1) : 0;

    echo "<div class='test-section'>";
    echo "<h2>📊 Overall Test Results</h2>";
    
    if ($passedTests == $totalTests) {
        echo "<div class='success'>";
        echo "<strong>🎉 All Tests Passed!</strong><br>";
        echo "Success Rate: $passedTests/$totalTests ($successRate%)";
        echo "</div>";
    } else {
        $failedTests = $totalTests - $passedTests;
        echo "<div class='warning'>";
        echo "<strong>⚠️ Some Tests Need Attention</strong><br>";
        echo "Passed: $passedTests/$totalTests ($successRate%)<br>";
        echo "Failed: $failedTests";
        echo "</div>";
    }
    echo "</div>";

    // Module Results Grid
    echo "<h2>📋 Results by Module</h2>";
    echo "<div class='module-grid'>";
    
    foreach ($moduleResults as $module => $result) {
        $moduleRate = $result['total'] > 0 ? round(($result['passed'] / $result['total']) * 100, 1) : 0;
        $moduleClass = $result['passed'] == $result['total'] ? 'test-pass' : 
                      ($result['passed'] == 0 ? 'test-fail' : 'test-warning');
        
        echo "<div class='test-section $moduleClass'>";
        echo "<h3>🔧 $module Module</h3>";
        echo "<div class='info'>";
        echo "<strong>Status:</strong> {$result['passed']}/{$result['total']} tests passed ($moduleRate%)<br>";
        echo "</div>";
        
        echo "<table>";
        echo "<tr><th>Test</th><th>Status</th></tr>";
        foreach ($result['tests'] as $test) {
            $status = $test['passed'] ? '✅' : '❌';
            echo "<tr><td>{$test['name']}</td><td>$status</td></tr>";
        }
        echo "</table>";
        echo "</div>";
    }
    echo "</div>";

    // Detailed Results Table
    echo "<h2>📋 Detailed Test Results</h2>";
    echo "<table>";
    echo "<tr><th>Module</th><th>Test Name</th><th>Status</th><th>Message</th></tr>";
    
    foreach ($testResults as $result) {
        $status = $result['passed'] ? '✅ PASS' : '❌ FAIL';
        $statusColor = $result['passed'] ? '#155724' : '#721c24';
        echo "<tr>";
        echo "<td>{$result['module']}</td>";
        echo "<td>{$result['name']}</td>";
        echo "<td><span style='color:$statusColor;'>$status</span></td>";
        echo "<td>{$result['message']}</td>";
        echo "</tr>";
    }
    echo "</table>";

    // Action Items
    echo "<div class='test-section'>";
    echo "<h2>📋 Action Items</h2>";
    
    if ($passedTests == $totalTests) {
        echo "<div class='success'>";
        echo "<strong>✅ System Ready for Production</strong><br>";
        echo "All functionality tests passed. The centralized database migration is complete.";
        echo "</div>";
        
        echo "<div class='info'>";
        echo "<strong>Optional Next Steps:</strong><br>";
        echo "• Archive legacy SQL files using cleanup-legacy-sql-files.php<br>";
        echo "• Set up automated backups for ram_yum_inventory database<br>";
        echo "• Monitor system performance under load<br>";
        echo "• Update any external documentation";
        echo "</div>";
        
    } else {
        echo "<div class='warning'>";
        echo "<strong>Action Required:</strong><br>";
        echo "Some tests failed. Please address the issues before going to production:";
        echo "<ul>";
        
        foreach ($testResults as $result) {
            if (!$result['passed']) {
                echo "<li><strong>{$result['module']} - {$result['name']}:</strong> {$result['message']}</li>";
            }
        }
        echo "</ul>";
        echo "</div>";
        
        echo "<div class='info'>";
        echo "<strong>Common Solutions:</strong><br>";
        echo "• Run the migration script: <a href='/migrate-to-centralized-db.php'>migrate-to-centralized-db.php</a><br>";
        echo "• Check database configuration: <a href='/verify-database-config.php'>verify-database-config.php</a><br>";
        echo "• Ensure all required tables exist<br>";
        echo "• Verify user permissions and data integrity";
        echo "</div>";
    }
    
    echo "</div>";
    ?>

    <div class="test-section">
        <h2>🔄 Test Actions</h2>
        <button class="btn" onclick="window.location.reload()">🔁 Re-run Tests</button>
        <button class="btn" onclick="window.location.href='/verify-database-config.php'">🔧 Check Database Config</button>
        <button class="btn" onclick="window.location.href='/migrate-to-centralized-db.php'">📦 Run Migration</button>
        <button class="btn" onclick="window.location.href='/test-database-integration.php'">🧪 Database Integration Test</button>
    </div>

</body>
</html>