-- ==========================================
-- FIX: Add SKU normalized column safely
-- Checks if column exists before adding
-- ==========================================

-- Check and add sku_normalized column to products table
SET @column_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'products' 
    AND COLUMN_NAME = 'sku_normalized'
);

SET @sql = IF(
    @column_exists = 0,
    'ALTER TABLE products ADD COLUMN sku_normalized VARCHAR(100) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, ''$.sku''))) STORED',
    'SELECT "Column sku_normalized already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Add index on sku_normalized if it doesn't exist
SET @index_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.STATISTICS 
    WHERE TABLE_SCHEMA = DATABASE() 
    AND TABLE_NAME = 'products' 
    AND INDEX_NAME = 'idx_sku_normalized'
);

SET @sql = IF(
    @index_exists = 0 AND @column_exists = 0,
    'ALTER TABLE products ADD INDEX idx_sku_normalized (sku_normalized)',
    'SELECT "Index already exists or column not found" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify the column
SELECT 
    COLUMN_NAME,
    COLUMN_TYPE,
    GENERATION_EXPRESSION,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = DATABASE()
AND TABLE_NAME = 'products'
AND COLUMN_NAME = 'sku_normalized';
