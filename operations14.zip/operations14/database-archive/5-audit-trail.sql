-- =====================================================================
-- STEP 5: Add Comprehensive Audit Trail
-- Run this fifth in phpMyAdmin
-- =====================================================================

USE ramyum_db;

-- Clear existing demo audit entries
DELETE FROM stock_transfer_audit WHERE transfer_id LIKE 'ST-2026-01%';

-- Add comprehensive audit trail entries
INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) VALUES

-- ST-2026-0101: Urgent restock scenario (Pending)
('audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),

-- ST-2026-0103: Completed transfer scenario  
('audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),
('audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%d %H:%i:%s')),

-- ST-2026-0104: Rejected transfer scenario
('audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d %H:%i:%s')),
('audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s'))

ON DUPLICATE KEY UPDATE id = id;

-- Verify audit trail was added
SELECT 'Step 5 Complete: Audit Trail Added' as status;
SELECT COUNT(*) as audit_count FROM stock_transfer_audit;

-- Show audit summary by transfer
SELECT 
    transfer_id,
    GROUP_CONCAT(action ORDER BY created_at SEPARATOR ' → ') as workflow
FROM stock_transfer_audit 
WHERE transfer_id LIKE 'ST-2026-01%'
GROUP BY transfer_id 
ORDER BY transfer_id;