-- =====================================================================
-- RAM-YUM: FIX-DATABASE.sql
-- Run once in phpMyAdmin (select ramyum_db -> SQL tab -> paste -> Go).
-- Safe to run more than once.
--
-- What this fixes
--   1. stock_transfer_audit had the WRONG columns. The setup scripts
--      (COMPLETE-..., SIMPLE-..., 1-schema, quick-locations-setup, the
--      setup-*.php files) created:  action / performed_by / performed_by_name
--      but api/stock-transfers.php writes:  action_type / user_id /
--      user_name / ip_address  (and expects an AUTO_INCREMENT id).
--      Result: "Unknown column 'action_type'" -> create / approve / reject
--      transfer all roll back.
--   2. Existing audit rows were keyed by the transfer NUMBER (ST-2026-0101)
--      but the app looks them up by the record id (st_demo_001), so the
--      audit trail showed empty. They are re-keyed here.
--   3. Old action names (CREATED) are renamed to what the API writes
--      (TRANSFER_CREATED), and plain-text details become JSON.
--
-- Your old audit table is kept as stock_transfer_audit_legacy.
-- =====================================================================

USE ramyum_db;

-- These two are correct in every setup file; created only if missing.
CREATE TABLE IF NOT EXISTS locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory_locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

DROP PROCEDURE IF EXISTS fix_stock_transfer_audit;

DELIMITER $$
CREATE PROCEDURE fix_stock_transfer_audit()
BEGIN
    DECLARE table_exists INT DEFAULT 0;
    DECLARE is_new_shape INT DEFAULT 0;

    SELECT COUNT(*) INTO table_exists
    FROM information_schema.tables
    WHERE table_schema = DATABASE() AND table_name = 'stock_transfer_audit';

    SELECT COUNT(*) INTO is_new_shape
    FROM information_schema.columns
    WHERE table_schema = DATABASE() AND table_name = 'stock_transfer_audit'
      AND column_name = 'action_type';

    -- Only touch the table if it exists with the old (wrong) columns.
    IF table_exists > 0 AND is_new_shape = 0 THEN
        DROP TABLE IF EXISTS stock_transfer_audit_legacy;
        RENAME TABLE stock_transfer_audit TO stock_transfer_audit_legacy;

        CREATE TABLE stock_transfer_audit (
            id          INT AUTO_INCREMENT PRIMARY KEY,
            transfer_id VARCHAR(100) NOT NULL,
            action_type VARCHAR(50)  NOT NULL,
            user_id     VARCHAR(40)  NOT NULL,
            user_name   VARCHAR(150) NOT NULL,
            details     JSON NULL,
            ip_address  VARCHAR(64) NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_transfer_id (transfer_id),
            INDEX idx_action_type (action_type),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB;

        INSERT INTO stock_transfer_audit
            (transfer_id, action_type, user_id, user_name, details, ip_address, created_at)
        SELECT
            COALESCE(
                (SELECT st.id FROM stock_transfers st
                 WHERE JSON_UNQUOTE(JSON_EXTRACT(st.data, '$.transferNumber')) = l.transfer_id
                 LIMIT 1),
                l.transfer_id
            ),
            IF(UPPER(l.action) LIKE 'TRANSFER\_%', UPPER(l.action), CONCAT('TRANSFER_', UPPER(l.action))),
            l.performed_by,
            l.performed_by_name,
            IF(l.details IS NULL OR l.details = '', NULL,
               IF(JSON_VALID(l.details), l.details, JSON_OBJECT('message', l.details))),
            NULL,
            l.created_at
        FROM stock_transfer_audit_legacy l
        ORDER BY l.created_at,
                 FIELD(UPPER(l.action), 'CREATED', 'SUBMITTED', 'APPROVED', 'REJECTED', 'COMPLETED'),
                 l.id;
    END IF;
END$$
DELIMITER ;

CALL fix_stock_transfer_audit();
DROP PROCEDURE IF EXISTS fix_stock_transfer_audit;

-- Fresh database (table did not exist at all): create it in the correct shape.
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    transfer_id VARCHAR(100) NOT NULL,
    action_type VARCHAR(50)  NOT NULL,
    user_id     VARCHAR(40)  NOT NULL,
    user_name   VARCHAR(150) NOT NULL,
    details     JSON NULL,
    ip_address  VARCHAR(64) NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action_type (action_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------
SHOW COLUMNS FROM stock_transfer_audit;

SELECT st.id AS transfer_id,
       JSON_UNQUOTE(JSON_EXTRACT(st.data, '$.transferNumber')) AS transfer_number,
       GROUP_CONCAT(a.action_type ORDER BY a.id SEPARATOR ' > ') AS audit_trail
FROM stock_transfers st
LEFT JOIN stock_transfer_audit a ON a.transfer_id = st.id
GROUP BY st.id, transfer_number
ORDER BY transfer_number;
