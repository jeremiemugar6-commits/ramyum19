-- ==========================================
-- CRITICAL FIXES MIGRATION - SIMPLE VERSION
-- RAM-YUM Operations System
-- Date: October 3, 2026
-- ==========================================
-- Run this file in phpMyAdmin for your database
-- Make sure you're in the correct database first!
-- ==========================================

-- ==========================================
-- FIX #1: ADD SKU UNIQUENESS CONSTRAINT
-- ==========================================

-- Step 1: Check for existing duplicate SKUs first
-- (Copy results before proceeding - should return 0 rows)
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) as sku,
    COUNT(*) as count,
    GROUP_CONCAT(id) as product_ids
FROM products
WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) IS NOT NULL
GROUP BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))
HAVING COUNT(*) > 1;

-- Step 2: Add generated column for SKU
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS sku_normalized VARCHAR(100) 
GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))) STORED;

-- Step 3: Add unique constraint
ALTER TABLE products 
ADD UNIQUE KEY IF NOT EXISTS unique_sku (sku_normalized);

-- Step 4: Add index for performance
CREATE INDEX IF NOT EXISTS idx_product_sku ON products(sku_normalized);

-- ==========================================
-- FIX #2: NEGATIVE STOCK PREVENTION
-- ==========================================

-- Add quantity validation for inventory_locations
ALTER TABLE inventory_locations
ADD COLUMN IF NOT EXISTS quantity_value DECIMAL(10,2)
GENERATED ALWAYS AS (CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.quantity')) AS DECIMAL(10,2))) STORED;

ALTER TABLE inventory_locations
ADD COLUMN IF NOT EXISTS available_quantity_value DECIMAL(10,2)
GENERATED ALWAYS AS (CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) AS DECIMAL(10,2))) STORED;

-- Add CHECK constraints (Note: CHECK constraints in MySQL/MariaDB)
ALTER TABLE inventory_locations
ADD CONSTRAINT IF NOT EXISTS chk_positive_quantity CHECK (quantity_value >= 0);

ALTER TABLE inventory_locations
ADD CONSTRAINT IF NOT EXISTS chk_positive_available_quantity CHECK (available_quantity_value >= 0);

-- ==========================================
-- VERIFICATION (run these to check)
-- ==========================================

-- Check if SKU constraint exists
SHOW INDEX FROM products WHERE Key_name = 'unique_sku';

-- Check if columns were added to inventory_locations
SHOW COLUMNS FROM inventory_locations LIKE '%quantity_value%';

-- Count products and verify unique SKUs
SELECT 
    COUNT(*) as total_products,
    COUNT(DISTINCT sku_normalized) as unique_skus,
    COUNT(*) - COUNT(DISTINCT sku_normalized) as duplicate_count
FROM products;

-- Show sample products with normalized SKUs
SELECT 
    id,
    sku_normalized,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as product_name,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.stock')) as stock
FROM products
LIMIT 10;

-- ==========================================
-- MIGRATION COMPLETE
-- ==========================================
-- If all queries executed successfully, you're done!
-- Test by trying to create a product with duplicate SKU
-- Test by trying to set negative stock
