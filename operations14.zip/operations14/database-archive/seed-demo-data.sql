-- =====================================================================
-- RAM-YUM Capstone Demo Data - Enhanced Suppliers and Products
-- Run this after the main schema.sql to add realistic demo data
-- =====================================================================

USE ramyum_db;

-- Delete existing demo data to ensure clean slate
DELETE FROM products WHERE id IN ('p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7', 'p8', 'p9', 'p10');
DELETE FROM suppliers WHERE id IN ('s1', 's2', 's3', 's4');

-- Insert Enhanced Suppliers for Korean/Japanese Products
INSERT INTO suppliers (id, data) VALUES
('s1', JSON_OBJECT(
    'id', 's1', 'company', 'Seoul Food Distribution', 'contactPerson', 'Minji Kim',
    'email', 'minji@seoulfood.co.kr', 'phone', '+82 10 1234 5678',
    'address', '456 Hongdae-ro, Mapo-gu, Seoul, South Korea', 'taxId', 'KR-123-45-67890',
    'paymentTerms', 'Net 30', 'notes', 'Primary supplier for Korean instant noodles and snacks. Specializes in Samyang, Nongshim, and Ottogi products.', 
    'productCount', 8, 'status', 'Active', 'rating', 4.8, 'deliveryDays', 7, 'minimumOrder', 25000,
    'created_at', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('s2', JSON_OBJECT(
    'id', 's2', 'company', 'K-Food Wholesale Trading', 'contactPerson', 'Park Jin-woo',
    'email', 'jinwoo@kfoodtrading.kr', 'phone', '+82 2 9876 5432',
    'address', '789 Gangnam-daero, Gangnam-gu, Seoul, South Korea', 'taxId', 'KR-987-65-43210',
    'paymentTerms', 'Net 15', 'notes', 'Premium Korean food products distributor. Known for authentic traditional items and modern convenience foods.', 
    'productCount', 12, 'status', 'Active', 'rating', 4.9, 'deliveryDays', 5, 'minimumOrder', 50000,
    'created_at', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('s3', JSON_OBJECT(
    'id', 's3', 'company', 'Asia Grocery Supply', 'contactPerson', 'Lee Soo-jin',
    'email', 'soojin@asiagrocery.ph', 'phone', '+63 2 8555 1234',
    'address', '123 Binondo, Manila, Philippines', 'taxId', 'PH-555-123-789',
    'paymentTerms', 'Net 21', 'notes', 'Local distributor for Asian grocery products. Handles both Korean and Japanese imports with competitive pricing.', 
    'productCount', 15, 'status', 'Active', 'rating', 4.5, 'deliveryDays', 3, 'minimumOrder', 15000,
    'created_at', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('s4', JSON_OBJECT(
    'id', 's4', 'company', 'Korean-Japanese Food Distributor', 'contactPerson', 'Tanaka Hiroshi',
    'email', 'hiroshi@kjfood.com', 'phone', '+81 3 5555 7890',
    'address', '321 Shibuya, Tokyo, Japan', 'taxId', 'JP-321-654-987',
    'paymentTerms', 'Net 30', 'notes', 'Specialized distributor for both Korean and Japanese food products. Excellent for variety and authentic flavors.', 
    'productCount', 20, 'status', 'Active', 'rating', 4.7, 'deliveryDays', 10, 'minimumOrder', 30000,
    'created_at', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- Insert Realistic Korean/Japanese Products with Philippine Peso Pricing
INSERT INTO products (id, data) VALUES
('p1', JSON_OBJECT(
    'id', 'p1', 'name', 'Samyang Buldak Original', 'sku', 'SB-001', 'category', 'Instant Noodles',
    'price', 65.00, 'stock', 45, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Korean fire noodles with spicy chicken flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0001', 'archived', false, 'brand', 'Samyang', 'origin', 'South Korea',
    'unitWeight', '140g', 'packSize', '5pcs'
)),
('p2', JSON_OBJECT(
    'id', 'p2', 'name', 'Shin Ramyun', 'sku', 'SR-002', 'category', 'Instant Noodles',
    'price', 75.00, 'stock', 32, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Premium spicy Korean ramen with beef flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 10 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0002', 'archived', false, 'brand', 'Nongshim', 'origin', 'South Korea',
    'unitWeight', '120g', 'packSize', '5pcs'
)),
('p3', JSON_OBJECT(
    'id', 'p3', 'name', 'Ottogi Jin Ramen', 'sku', 'OJ-003', 'category', 'Instant Noodles',
    'price', 50.00, 'stock', 28, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Mild Korean ramen with savory beef broth', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 9 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0003', 'archived', false, 'brand', 'Ottogi', 'origin', 'South Korea',
    'unitWeight', '120g', 'packSize', '5pcs'
)),
('p4', JSON_OBJECT(
    'id', 'p4', 'name', 'Samyang Buldak Carbonara', 'sku', 'SC-004', 'category', 'Instant Noodles',
    'price', 68.00, 'stock', 22, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Creamy carbonara version of the famous fire noodles', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0004', 'archived', false, 'brand', 'Samyang', 'origin', 'South Korea',
    'unitWeight', '130g', 'packSize', '5pcs'
)),
('p5', JSON_OBJECT(
    'id', 'p5', 'name', 'Nongshim Neoguri', 'sku', 'NN-005', 'category', 'Instant Noodles',
    'price', 72.00, 'stock', 18, 'reorderLevel', 12, 'status', 'In Stock',
    'description', 'Thick udon-style Korean ramen with seafood flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 11 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0005', 'archived', false, 'brand', 'Nongshim', 'origin', 'South Korea',
    'unitWeight', '120g', 'packSize', '5pcs'
)),
('p6', JSON_OBJECT(
    'id', 'p6', 'name', 'Nongshim Chapagetti', 'sku', 'NC-006', 'category', 'Instant Noodles',
    'price', 69.00, 'stock', 35, 'reorderLevel', 18, 'status', 'In Stock',
    'description', 'Korean black bean sauce noodles (jajangmyeon)', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 10 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0006', 'archived', false, 'brand', 'Nongshim', 'origin', 'South Korea',
    'unitWeight', '140g', 'packSize', '5pcs'
)),
('p7', JSON_OBJECT(
    'id', 'p7', 'name', 'Korean Soju - Chamisul', 'sku', 'CS-007', 'category', 'Beverages',
    'price', 180.00, 'stock', 24, 'reorderLevel', 10, 'status', 'In Stock',
    'description', 'Premium Korean soju, smooth and clean taste', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's3',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 24 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0007', 'archived', false, 'brand', 'Jinro', 'origin', 'South Korea',
    'unitWeight', '360ml', 'packSize', '1 bottle'
)),
('p8', JSON_OBJECT(
    'id', 'p8', 'name', 'Korean Kimchi - Napa Cabbage', 'sku', 'KK-008', 'category', 'Fermented Foods',
    'price', 250.00, 'stock', 15, 'reorderLevel', 8, 'status', 'In Stock',
    'description', 'Authentic Korean fermented cabbage kimchi', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's3',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 3 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0008', 'archived', false, 'brand', 'Dongwon', 'origin', 'South Korea',
    'unitWeight', '500g', 'packSize', '1 jar'
)),
('p9', JSON_OBJECT(
    'id', 'p9', 'name', 'Japanese Sushi Rice', 'sku', 'JSR-009', 'category', 'Rice & Pantry',
    'price', 320.00, 'stock', 12, 'reorderLevel', 8, 'status', 'In Stock',
    'description', 'Premium short-grain Japanese sushi rice', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's4',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 18 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0009', 'archived', false, 'brand', 'Koshihikari', 'origin', 'Japan',
    'unitWeight', '2kg', 'packSize', '1 bag'
)),
('p10', JSON_OBJECT(
    'id', 'p10', 'name', 'Korean Seaweed Snack', 'sku', 'KS-010', 'category', 'Snacks',
    'price', 95.00, 'stock', 40, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Crispy roasted seaweed with sesame oil', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's3',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0010', 'archived', false, 'brand', 'Kwangcheon', 'origin', 'South Korea',
    'unitWeight', '4.5g', 'packSize', '12pcs'
));

-- Verify the data was inserted correctly
SELECT 'Suppliers inserted:' as info, COUNT(*) as count FROM suppliers;
SELECT 'Products inserted:' as info, COUNT(*) as count FROM products;

-- Show sample of inserted data
SELECT 
    JSON_EXTRACT(data, '$.company') as company_name,
    JSON_EXTRACT(data, '$.contactPerson') as contact,
    JSON_EXTRACT(data, '$.productCount') as product_count,
    JSON_EXTRACT(data, '$.rating') as rating
FROM suppliers 
ORDER BY created_at DESC;

SELECT 
    JSON_EXTRACT(data, '$.name') as product_name,
    JSON_EXTRACT(data, '$.price') as price_php,
    JSON_EXTRACT(data, '$.stock') as current_stock,
    JSON_EXTRACT(data, '$.brand') as brand,
    JSON_EXTRACT(data, '$.origin') as origin
FROM products 
ORDER BY created_at DESC
LIMIT 5;