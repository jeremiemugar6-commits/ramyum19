-- =====================================================================
-- RAM-YUM Product & Inventory Operations System — MySQL Schema
-- Import this into a MySQL/MariaDB database (e.g. via phpMyAdmin or:
--   mysql -u root -p ramyum_db < schema.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ramyum_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ramyum_db;

-- ---------------------------------------------------------------------
-- USERS — real relational table (drives session auth, role access)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id              VARCHAR(40)  PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    username        VARCHAR(100) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('admin','manager','staff') NOT NULL DEFAULT 'staff',
    verified        TINYINT(1)   NOT NULL DEFAULT 1,
    profile_picture LONGTEXT     NULL,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- LOGIN ATTEMPTS — server-side brute-force lockout tracking
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS login_attempts (
    identifier   VARCHAR(150) PRIMARY KEY,
    attempt_count INT NOT NULL DEFAULT 0,
    last_attempt  DATETIME NOT NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- OTP CODES — one-time passcodes for two-step login verification
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS otp_codes (
    id          VARCHAR(40)  PRIMARY KEY,
    user_id     VARCHAR(40)  NOT NULL,
    code_hash   VARCHAR(255) NOT NULL,
    purpose     VARCHAR(30)  NOT NULL DEFAULT 'login',
    attempts    INT          NOT NULL DEFAULT 0,
    expires_at  DATETIME     NOT NULL,
    consumed_at DATETIME     NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- SECURITY / AUDIT LOG
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS security_logs (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    event_type  VARCHAR(100) NOT NULL,
    user_id     VARCHAR(40) NULL,
    username    VARCHAR(100) NULL,
    details     JSON NULL,
    ip_address  VARCHAR(64) NULL,
    created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- GENERIC OPERATIONAL COLLECTIONS
-- Each mirrors the original app's localStorage "collections". Records
-- are stored as JSON documents (id + data) which keeps every module's
-- existing field names (camelCase, nested items/locationStock, etc.)
-- working unchanged, while giving real, queryable MySQL persistence.
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS categories (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS suppliers (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory_movements (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS purchase_orders (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS receivings (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_transfers (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_adjustments (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- INVENTORY_PREDICTIONS — real relational table generated by the
-- AI Analytics module's linear regression demand-prediction model.
-- One row per product; re-running the model upserts (keeps only the
-- latest prediction per product).
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS inventory_predictions (
    prediction_id        VARCHAR(40)    PRIMARY KEY,
    product_id            VARCHAR(40)    NOT NULL,
    prediction_date       DATE           NOT NULL,
    historical_quantity   DECIMAL(12,2)  NOT NULL DEFAULT 0,
    predicted_quantity    DECIMAL(12,2)  NOT NULL DEFAULT 0,
    demand_status         VARCHAR(20)    NOT NULL DEFAULT 'Stable',
    recommended_stock     DECIMAL(12,2)  NOT NULL DEFAULT 0,
    accuracy_score        DECIMAL(5,2)   NOT NULL DEFAULT 0,
    created_at            DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_product (product_id),
    CONSTRAINT fk_prediction_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- SEED DATA
-- =====================================================================

-- Default accounts:
--   admin / Admin@123   (role: admin)
--   staff / Staff@123   (role: staff)
INSERT INTO users (id, name, email, username, password_hash, role, verified) VALUES
('u1', 'Admin User', 'jeremiemugar7@gmail.com', 'admin', '$2b$10$jORdZ.f9BV.WT2nFKNek5ekLliBntqCv0DaSh1RXLPoD2bffa3Hb.', 'admin', 1),
('u2', 'Staff User', 'staff@ramyum.com', 'staff', '$2b$10$U//kJkgHuyUwK24TLR9SWuhfowJHAJaq9SouO3yZWV8GekND2XbsS', 'staff', 1)
ON DUPLICATE KEY UPDATE id = id;

INSERT INTO suppliers (id, data) VALUES
('s1', JSON_OBJECT(
    'id', 's1', 'company', 'Seoul Food Distribution', 'contactPerson', 'Minji Kim',
    'email', 'minji@seoulfood.co.kr', 'phone', '+82 10 1234 5678',
    'address', '456 Hongdae-ro, Mapo-gu, Seoul, South Korea', 'taxId', 'KR-123-45-67890',
    'paymentTerms', 'Net 30', 'notes', 'Primary supplier for Korean instant noodles and snacks. Specializes in Samyang, Nongshim, and Ottogi products.', 
    'productCount', 8, 'status', 'Active', 'rating', 4.8, 'deliveryDays', 7, 'minimumOrder', 25000
)),
('s2', JSON_OBJECT(
    'id', 's2', 'company', 'K-Food Wholesale Trading', 'contactPerson', 'Park Jin-woo',
    'email', 'jinwoo@kfoodtrading.kr', 'phone', '+82 2 9876 5432',
    'address', '789 Gangnam-daero, Gangnam-gu, Seoul, South Korea', 'taxId', 'KR-987-65-43210',
    'paymentTerms', 'Net 15', 'notes', 'Premium Korean food products distributor. Known for authentic traditional items and modern convenience foods.', 
    'productCount', 12, 'status', 'Active', 'rating', 4.9, 'deliveryDays', 5, 'minimumOrder', 50000
)),
('s3', JSON_OBJECT(
    'id', 's3', 'company', 'Asia Grocery Supply', 'contactPerson', 'Lee Soo-jin',
    'email', 'soojin@asiagrocery.ph', 'phone', '+63 2 8555 1234',
    'address', '123 Binondo, Manila, Philippines', 'taxId', 'PH-555-123-789',
    'paymentTerms', 'Net 21', 'notes', 'Local distributor for Asian grocery products. Handles both Korean and Japanese imports with competitive pricing.', 
    'productCount', 15, 'status', 'Active', 'rating', 4.5, 'deliveryDays', 3, 'minimumOrder', 15000
)),
('s4', JSON_OBJECT(
    'id', 's4', 'company', 'Korean-Japanese Food Distributor', 'contactPerson', 'Tanaka Hiroshi',
    'email', 'hiroshi@kjfood.com', 'phone', '+81 3 5555 7890',
    'address', '321 Shibuya, Tokyo, Japan', 'taxId', 'JP-321-654-987',
    'paymentTerms', 'Net 30', 'notes', 'Specialized distributor for both Korean and Japanese food products. Excellent for variety and authentic flavors.', 
    'productCount', 20, 'status', 'Active', 'rating', 4.7, 'deliveryDays', 10, 'minimumOrder', 30000
))
ON DUPLICATE KEY UPDATE id = id;

INSERT INTO products (id, data) VALUES
('p1', JSON_OBJECT(
    'id', 'p1', 'name', 'Samyang Buldak Original', 'sku', 'SB-001', 'category', 'Instant Noodles',
    'price', 65.00, 'stock', 45, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Korean fire noodles with spicy chicken flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0001', 'archived', false, 'brand', 'Samyang', 'origin', 'South Korea'
)),
('p2', JSON_OBJECT(
    'id', 'p2', 'name', 'Shin Ramyun', 'sku', 'SR-002', 'category', 'Instant Noodles',
    'price', 75.00, 'stock', 32, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Premium spicy Korean ramen with beef flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 10 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0002', 'archived', false, 'brand', 'Nongshim', 'origin', 'South Korea'
)),
('p3', JSON_OBJECT(
    'id', 'p3', 'name', 'Ottogi Jin Ramen', 'sku', 'OJ-003', 'category', 'Instant Noodles',
    'price', 50.00, 'stock', 28, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Mild Korean ramen with savory beef broth', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 9 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0003', 'archived', false, 'brand', 'Ottogi', 'origin', 'South Korea'
)),
('p4', JSON_OBJECT(
    'id', 'p4', 'name', 'Samyang Buldak Carbonara', 'sku', 'SC-004', 'category', 'Instant Noodles',
    'price', 68.00, 'stock', 22, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Creamy carbonara version of the famous fire noodles', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0004', 'archived', false, 'brand', 'Samyang', 'origin', 'South Korea'
)),
('p5', JSON_OBJECT(
    'id', 'p5', 'name', 'Nongshim Neoguri', 'sku', 'NN-005', 'category', 'Instant Noodles',
    'price', 72.00, 'stock', 18, 'reorderLevel', 12, 'status', 'In Stock',
    'description', 'Thick udon-style Korean ramen with seafood flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 11 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0005', 'archived', false, 'brand', 'Nongshim', 'origin', 'South Korea'
)),
('p6', JSON_OBJECT(
    'id', 'p6', 'name', 'Nongshim Chapagetti', 'sku', 'NC-006', 'category', 'Instant Noodles',
    'price', 69.00, 'stock', 35, 'reorderLevel', 18, 'status', 'In Stock',
    'description', 'Korean black bean sauce noodles (jajangmyeon)', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 10 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0006', 'archived', false, 'brand', 'Nongshim', 'origin', 'South Korea'
)),
('p7', JSON_OBJECT(
    'id', 'p7', 'name', 'Korean Soju - Chamisul', 'sku', 'CS-007', 'category', 'Beverages',
    'price', 180.00, 'stock', 24, 'reorderLevel', 10, 'status', 'In Stock',
    'description', 'Premium Korean soju, smooth and clean taste', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's3',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 24 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0007', 'archived', false, 'brand', 'Jinro', 'origin', 'South Korea'
)),
('p8', JSON_OBJECT(
    'id', 'p8', 'name', 'Korean Kimchi - Napa Cabbage', 'sku', 'KK-008', 'category', 'Fermented Foods',
    'price', 250.00, 'stock', 15, 'reorderLevel', 8, 'status', 'In Stock',
    'description', 'Authentic Korean fermented cabbage kimchi', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's3',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 3 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0008', 'archived', false, 'brand', 'Dongwon', 'origin', 'South Korea'
)),
('p9', JSON_OBJECT(
    'id', 'p9', 'name', 'Japanese Sushi Rice', 'sku', 'JSR-009', 'category', 'Rice & Pantry',
    'price', 320.00, 'stock', 12, 'reorderLevel', 8, 'status', 'In Stock',
    'description', 'Premium short-grain Japanese sushi rice', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's4',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 18 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0009', 'archived', false, 'brand', 'Koshihikari', 'origin', 'Japan'
)),
('p10', JSON_OBJECT(
    'id', 'p10', 'name', 'Korean Seaweed Snack', 'sku', 'KS-010', 'category', 'Snacks',
    'price', 95.00, 'stock', 40, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Crispy roasted seaweed with sesame oil', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's3',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BATCH-2026-0010', 'archived', false, 'brand', 'Kwangcheon', 'origin', 'South Korea'
))
ON DUPLICATE KEY UPDATE id = id;
