<?php
/**
 * Clear OPcache to reload workflow-processor.php
 */

if (function_exists('opcache_reset')) {
    opcache_reset();
    echo "✓ OPcache cleared successfully!\n";
    echo "workflow-processor.php will be reloaded on next request.\n";
} else {
    echo "ℹ OPcache is not enabled.\n";
    echo "The file should reload automatically.\n";
}

echo "\nPlease try your receiving operation again in the browser.\n";
