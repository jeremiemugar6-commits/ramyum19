<?php
/**
 * Complete Local Stock Transfer Demo Test
 * Tests the ENTIRE workflow locally
 */

require_once 'includes/auth.php';

$db = getDB();

echo "=================================================\n";
echo "  LOCAL STOCK TRANSFER - COMPLETE TEST\n";
echo "=================================================\n\n";

echo "Environment Check:\n";
echo "  ✓ Database: " . DB_NAME . " (LOCAL)\n";
echo "  ✓ Host: " . DB_HOST . "\n";
echo "  ✓ Path: http://localhost/operations3/\n\n";

try {
    $db->beginTransaction();
    
    // STEP 1: Create Transfer
    echo "STEP 1: Create Stock Transfer\n";
    echo "-------------------------------------------------\n";
    
    $transferId = generate_id('st');
    $transferNumber = 'ST-DEMO-' . date('His');
    
    $transferData = [
        'id' => $transferId,
        'transferNumber' => $transferNumber,
        'sourceLocationId' => 'loc1',
        'sourceLocationName' => 'Main Warehouse',
        'destinationLocationId' => 'loc2',
        'destinationLocationName' => 'Branch 1 - Makati',
        'items' => [
            [
                'productId' => 'p1',
                'productName' => 'Samyang Buldak Original',
                'sku' => 'SAM-001',
                'quantity' => 10,
                'unit' => 'pcs',
                'sourceStock' => 150
            ]
        ],
        'totalItems' => 1,
        'status' => 'Pending Approval',
        'requestedBy' => 'usr_demo',
        'requestedByName' => 'Demo User',
        'createdAt' => date('Y-m-d\TH:i:s.v\Z'),
        'submittedAt' => date('Y-m-d\TH:i:s.v\Z'),
        'transferDate' => date('Y-m-d'),
        'remarks' => 'Local demo transfer - testing complete workflow'
    ];
    
    $stmt = $db->prepare("INSERT INTO stock_transfers (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
    $stmt->execute([$transferId, json_encode($transferData)]);
    
    echo "✓ Transfer Created\n";
    echo "  ID: $transferId\n";
    echo "  Number: $transferNumber\n";
    echo "  Status: Pending Approval\n\n";
    
    // STEP 2: View Transfer
    echo "STEP 2: View Transfer (Simulate API Call)\n";
    echo "-------------------------------------------------\n";
    echo "GET api/stock-transfers.php?action=transfer&id=$transferId\n";
    
    $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
    $stmt->execute([$transferId]);
    $result = $stmt->fetch();
    
    if ($result) {
        $viewedTransfer = json_decode($result['data'], true);
        echo "✓ Transfer Retrieved\n";
        echo "  Number: " . $viewedTransfer['transferNumber'] . "\n";
        echo "  From: " . $viewedTransfer['sourceLocationName'] . "\n";
        echo "  To: " . $viewedTransfer['destinationLocationName'] . "\n";
        echo "  Product: " . $viewedTransfer['items'][0]['productName'] . "\n";
        echo "  Quantity: " . $viewedTransfer['items'][0]['quantity'] . "\n";
    } else {
        throw new Exception("Transfer not found after creation!");
    }
    
    echo "\n";
    
    // STEP 3: Approve Transfer
    echo "STEP 3: Approve Transfer\n";
    echo "-------------------------------------------------\n";
    echo "POST api/stock-transfers.php?action=approve\n";
    
    $transferData['status'] = 'Approved';
    $transferData['approvedBy'] = 'usr_admin';
    $transferData['approvedByName'] = 'Admin User';
    $transferData['approvedAt'] = date('Y-m-d\TH:i:s.v\Z');
    $transferData['approvalRemarks'] = 'Approved for demo';
    
    $stmt = $db->prepare("UPDATE stock_transfers SET data = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([json_encode($transferData), $transferId]);
    
    echo "✓ Transfer Approved\n";
    echo "  Status: Approved\n";
    echo "  Approved By: Admin User\n\n";
    
    // STEP 4: Generate QR/POD
    echo "STEP 4: Generate QR Code for Delivery\n";
    echo "-------------------------------------------------\n";
    
    $qrToken = 'POD-' . strtoupper(bin2hex(random_bytes(8)));
    $podId = generate_id('pod');
    
    $stmt = $db->prepare("
        INSERT INTO proof_of_delivery (
            id, transfer_id, transfer_number, qr_token, status,
            created_at, updated_at
        ) VALUES (?, ?, ?, ?, 'Pending', NOW(), NOW())
    ");
    $stmt->execute([$podId, $transferId, $transferNumber, $qrToken]);
    
    echo "✓ QR Code Generated\n";
    echo "  POD ID: $podId\n";
    echo "  QR Token: $qrToken\n";
    echo "  Encodes: Transfer ID = $transferId\n\n";
    
    // STEP 5: Scan QR Code
    echo "STEP 5: Scan QR Code\n";
    echo "-------------------------------------------------\n";
    echo "GET api/proof-of-delivery.php?action=scan&token=$qrToken\n";
    
    $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE qr_token = ?");
    $stmt->execute([$qrToken]);
    $scannedPod = $stmt->fetch();
    
    if ($scannedPod) {
        echo "✓ QR Code Scanned\n";
        echo "  POD ID: " . $scannedPod['id'] . "\n";
        echo "  Transfer ID: " . $scannedPod['transfer_id'] . "\n";
        
        // Retrieve transfer from POD
        $stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $stmt->execute([$scannedPod['transfer_id']]);
        $retrievedTransfer = $stmt->fetch();
        
        if ($retrievedTransfer) {
            $transferInfo = json_decode($retrievedTransfer['data'], true);
            echo "✓ Transfer Retrieved from Scan\n";
            echo "  Number: " . $transferInfo['transferNumber'] . "\n";
            echo "  Product: " . $transferInfo['items'][0]['productName'] . "\n";
            echo "  Quantity: " . $transferInfo['items'][0]['quantity'] . "\n";
        } else {
            throw new Exception("Transfer not found via QR scan!");
        }
    } else {
        throw new Exception("QR code not found!");
    }
    
    echo "\n";
    
    // STEP 6: Confirm Receipt
    echo "STEP 6: Confirm Receipt\n";
    echo "-------------------------------------------------\n";
    echo "POST api/proof-of-delivery.php?action=confirm-receiving\n";
    
    // Update POD status
    $stmt = $db->prepare("
        UPDATE proof_of_delivery 
        SET status = 'Received',
            received_by = 'Staff User',
            received_at = NOW(),
            confirmation_notes = 'All items received in good condition - LOCAL DEMO'
        WHERE id = ?
    ");
    $stmt->execute([$podId]);
    
    // Update transfer status
    $transferData['status'] = 'Completed';
    $transferData['completedAt'] = date('Y-m-d\TH:i:s.v\Z');
    
    $stmt = $db->prepare("UPDATE stock_transfers SET data = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([json_encode($transferData), $transferId]);
    
    echo "✓ Receipt Confirmed\n";
    echo "  POD Status: Received\n";
    echo "  Transfer Status: Completed\n";
    echo "  Received By: Staff User\n\n";
    
    // STEP 7: Update Inventory
    echo "STEP 7: Update Inventory\n";
    echo "-------------------------------------------------\n";
    
    $productId = $transferData['items'][0]['productId'];
    $quantity = $transferData['items'][0]['quantity'];
    $sourceLocId = $transferData['sourceLocationId'];
    $destLocId = $transferData['destinationLocationId'];
    
    // Decrease source inventory
    $stmt = $db->prepare("
        UPDATE inventory_locations 
        SET data = JSON_SET(data, 
            '$.availableQuantity', 
            CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) AS UNSIGNED) - ?
        )
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ?
        AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
    ");
    $stmt->execute([$quantity, $productId, $sourceLocId]);
    
    // Increase destination inventory
    $stmt = $db->prepare("
        UPDATE inventory_locations 
        SET data = JSON_SET(data, 
            '$.availableQuantity', 
            CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) AS UNSIGNED) + ?
        )
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ?
        AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
    ");
    $stmt->execute([$quantity, $productId, $destLocId]);
    
    echo "✓ Inventory Updated\n";
    echo "  Source ($sourceLocId): -$quantity\n";
    echo "  Destination ($destLocId): +$quantity\n\n";
    
    // STEP 8: View History
    echo "STEP 8: View Transfer History\n";
    echo "-------------------------------------------------\n";
    
    echo "Transfer Timeline:\n";
    echo "  1. Created: " . $transferData['createdAt'] . "\n";
    echo "  2. Submitted: " . $transferData['submittedAt'] . "\n";
    echo "  3. Approved: " . $transferData['approvedAt'] . "\n";
    echo "  4. QR Generated: ✓\n";
    echo "  5. Scanned: ✓\n";
    echo "  6. Received: ✓\n";
    echo "  7. Completed: " . $transferData['completedAt'] . "\n";
    echo "  8. Inventory Updated: ✓\n\n";
    
    $db->commit();
    
    echo "=================================================\n";
    echo "        ALL TESTS PASSED - LOCAL SYSTEM\n";
    echo "=================================================\n\n";
    
    echo "Summary:\n";
    echo "  ✓ Transfer Created Locally\n";
    echo "  ✓ Transfer Viewed via Local API\n";
    echo "  ✓ Transfer Approved Locally\n";
    echo "  ✓ QR Code Generated Locally\n";
    echo "  ✓ QR Code Scanned Locally\n";
    echo "  ✓ Transfer Retrieved from Scan\n";
    echo "  ✓ Receipt Confirmed Locally\n";
    echo "  ✓ Inventory Updated in Local DB\n";
    echo "  ✓ Complete History Maintained\n\n";
    
    echo "Test Transfer Details:\n";
    echo "  ID: $transferId\n";
    echo "  Number: $transferNumber\n";
    echo "  QR Token: $qrToken\n";
    echo "  Status: Completed\n\n";
    
    echo "Verification:\n";
    echo "  1. Open: http://localhost/operations3/\n";
    echo "  2. Login as Admin/Manager\n";
    echo "  3. Go to Stock Transfer module\n";
    echo "  4. Find transfer: $transferNumber\n";
    echo "  5. Verify status: Completed\n";
    echo "  6. Check inventory updates\n\n";
    
    echo "QR Code Test:\n";
    echo "  1. Go to: http://localhost/operations3/scan-qr.php\n";
    echo "  2. Enter token manually: $qrToken\n";
    echo "  3. Should display: $transferNumber\n";
    echo "  4. Should show: Already Received\n\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n\n";
    exit(1);
}
