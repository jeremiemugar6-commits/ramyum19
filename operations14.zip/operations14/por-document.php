<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

// Require authentication
$currentUser = require_login_page();

// Get POR ID from query parameter
$porId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$porId) {
    die('Invalid POR ID');
}

// Fetch POR data
try {
    $db = Database::getInstance()->getConnection();
    
    // Get POR main data
    $stmt = $db->prepare("
        SELECT 
            por.*,
            po.po_number as purchase_order_number,
            s.name as supplier_name,
            s.contact_person as supplier_contact,
            s.phone as supplier_phone,
            s.email as supplier_email,
            s.address as supplier_address
        FROM proof_of_receiving por
        LEFT JOIN purchase_orders po ON por.purchase_order_id = po.id
        LEFT JOIN suppliers s ON por.supplier_id = s.id
        WHERE por.id = ?
    ");
    $stmt->execute([$porId]);
    $por = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$por) {
        die('POR not found');
    }
    
    // Get POR items
    $stmt = $db->prepare("
        SELECT 
            pori.*,
            p.name as product_name,
            p.sku,
            p.category
        FROM proof_of_receiving_items pori
        LEFT JOIN products p ON pori.product_id = p.id
        WHERE pori.por_id = ?
        ORDER BY pori.id
    ");
    $stmt->execute([$porId]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Calculate totals
    $totalOrdered = 0;
    $totalReceived = 0;
    $totalAccepted = 0;
    $totalRejected = 0;
    $totalValue = 0;
    $acceptedValue = 0;
    
    foreach ($items as $item) {
        $totalOrdered += $item['ordered_quantity'];
        $totalReceived += $item['received_quantity'];
        $totalAccepted += $item['accepted_quantity'];
        $totalRejected += $item['rejected_quantity'];
        $itemValue = $item['received_quantity'] * $item['unit_price'];
        $itemAcceptedValue = $item['accepted_quantity'] * $item['unit_price'];
        $totalValue += $itemValue;
        $acceptedValue += $itemAcceptedValue;
    }
    
    // Parse evidence files if available
    $evidenceFiles = [];
    if (!empty($por['evidence_files'])) {
        $evidenceFiles = json_decode($por['evidence_files'], true) ?: [];
    }
    
} catch (Exception $e) {
    die('Error loading POR data: ' . $e->getMessage());
}

// Helper function to format currency
function formatCurrency($amount) {
    return number_format($amount, 2);
}

// Helper function to get status badge color
function getStatusColor($status) {
    $colors = [
        'Draft' => '#F59E0B',
        'Completed' => '#10B981',
        'Cancelled' => '#EF4444'
    ];
    return $colors[$status] ?? '#9CA3AF';
}

// Helper function to get inspection status color
function getInspectionColor($status) {
    $colors = [
        'Pending' => '#F59E0B',
        'In Progress' => '#3B82F6',
        'Completed' => '#10B981',
        'Failed' => '#EF4444'
    ];
    return $colors[$status] ?? '#9CA3AF';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proof of Receiving - <?php echo htmlspecialchars($por['por_number']); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 11pt;
            line-height: 1.5;
            color: #333;
            background: #f5f5f5;
            padding: 20px;
        }
        
        .document-container {
            max-width: 210mm;
            margin: 0 auto;
            background: white;
            padding: 20mm;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #FF7A00;
        }
        
        .company-info {
            flex: 1;
        }
        
        .company-info h1 {
            color: #E31C1C;
            font-size: 28pt;
            margin-bottom: 5px;
            font-weight: 700;
        }
        
        .company-info .tagline {
            color: #FF7A00;
            font-size: 11pt;
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .company-info .details {
            font-size: 9pt;
            color: #666;
            line-height: 1.4;
        }
        
        .document-title {
            text-align: right;
        }
        
        .document-title h2 {
            font-size: 20pt;
            color: #333;
            margin-bottom: 5px;
        }
        
        .document-title .por-number {
            font-size: 14pt;
            font-weight: 700;
            color: #E31C1C;
            margin-bottom: 10px;
        }
        
        .status-badges {
            display: flex;
            gap: 8px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 4px;
            color: white;
            font-size: 9pt;
            font-weight: 600;
        }
        
        .info-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .info-box {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 6px;
            background: #f9f9f9;
        }
        
        .info-box h3 {
            font-size: 11pt;
            color: #E31C1C;
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid #FF7A00;
        }
        
        .info-row {
            display: flex;
            margin-bottom: 6px;
            font-size: 10pt;
        }
        
        .info-label {
            font-weight: 600;
            color: #555;
            min-width: 140px;
        }
        
        .info-value {
            color: #333;
        }
        
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 9pt;
        }
        
        .items-table th {
            background: #E31C1C;
            color: white;
            padding: 10px 6px;
            text-align: left;
            font-weight: 600;
            border: 1px solid #C41818;
        }
        
        .items-table td {
            padding: 8px 6px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        
        .items-table tbody tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        .items-table tbody tr:hover {
            background: #fff3e0;
        }
        
        .text-right {
            text-align: right;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-success {
            color: #10B981;
            font-weight: 600;
        }
        
        .text-danger {
            color: #EF4444;
            font-weight: 600;
        }
        
        .text-primary {
            color: #3B82F6;
            font-weight: 600;
        }
        
        .totals-section {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 25px;
        }
        
        .totals-box {
            border: 2px solid #E31C1C;
            padding: 15px;
            border-radius: 6px;
            background: #FFF5F5;
        }
        
        .totals-box h4 {
            color: #E31C1C;
            margin-bottom: 10px;
            font-size: 11pt;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            border-bottom: 1px solid #ddd;
            font-size: 10pt;
        }
        
        .total-row:last-child {
            border-bottom: none;
            font-weight: 700;
            font-size: 12pt;
            color: #E31C1C;
            padding-top: 10px;
            margin-top: 5px;
            border-top: 2px solid #E31C1C;
        }
        
        .notes-section {
            margin-bottom: 25px;
        }
        
        .notes-box {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 6px;
            background: #f9f9f9;
            margin-bottom: 15px;
        }
        
        .notes-box h4 {
            color: #E31C1C;
            margin-bottom: 8px;
            font-size: 10pt;
        }
        
        .notes-content {
            font-size: 9pt;
            color: #555;
            line-height: 1.6;
            white-space: pre-wrap;
        }
        
        .signatures-section {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            gap: 20px;
            margin-top: 40px;
            page-break-inside: avoid;
        }
        
        .signature-box {
            text-align: center;
        }
        
        .signature-line {
            border-top: 2px solid #333;
            margin-top: 50px;
            padding-top: 8px;
            font-size: 10pt;
            font-weight: 600;
        }
        
        .signature-label {
            font-size: 9pt;
            color: #666;
            margin-top: 4px;
        }
        
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
            text-align: center;
            font-size: 8pt;
            color: #999;
        }
        
        .evidence-section {
            margin-bottom: 25px;
        }
        
        .evidence-list {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
        
        .evidence-item {
            padding: 6px 12px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 9pt;
        }
        
        .inspection-result {
            display: inline-block;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 8pt;
            font-weight: 600;
        }
        
        .result-passed { background: #D1FAE5; color: #065F46; }
        .result-failed { background: #FEE2E2; color: #991B1B; }
        .result-conditional { background: #FEF3C7; color: #92400E; }
        .result-pending { background: #F3F4F6; color: #4B5563; }
        
        @media print {
            body {
                background: white;
                padding: 0;
            }
            
            .document-container {
                box-shadow: none;
                max-width: 100%;
                padding: 10mm;
            }
            
            .no-print {
                display: none !important;
            }
            
            @page {
                margin: 15mm;
                size: A4 portrait;
            }
        }
        
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #E31C1C;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 6px;
            font-size: 11pt;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            z-index: 1000;
        }
        
        .print-button:hover {
            background: #C41818;
        }
    </style>
</head>
<body>
    <button onclick="window.print()" class="print-button no-print">
        🖨️ Print Document
    </button>

    <div class="document-container">
        <!-- Header -->
        <div class="header">
            <div class="company-info">
                <h1>RAM-YUM</h1>
                <div class="tagline">Korean & Japanese Store</div>
                <div class="details">
                    Product & Inventory Operations System<br>
                    Quality Control & Receiving Department
                </div>
            </div>
            <div class="document-title">
                <h2>PROOF OF RECEIVING</h2>
                <div class="por-number"><?php echo htmlspecialchars($por['por_number']); ?></div>
                <div class="status-badges">
                    <span class="badge" style="background: <?php echo getStatusColor($por['status']); ?>">
                        <?php echo htmlspecialchars($por['status']); ?>
                    </span>
                    <span class="badge" style="background: <?php echo getInspectionColor($por['inspection_status']); ?>">
                        <?php echo htmlspecialchars($por['inspection_status']); ?>
                    </span>
                    <?php if ($por['inventory_updated'] == 1): ?>
                    <span class="badge" style="background: #3B82F6;">
                        Inventoried
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Information Section -->
        <div class="info-section">
            <div class="info-box">
                <h3>Document Information</h3>
                <div class="info-row">
                    <span class="info-label">PO Number:</span>
                    <span class="info-value"><?php echo htmlspecialchars($por['purchase_order_number'] ?? 'N/A'); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Receiving Date:</span>
                    <span class="info-value"><?php echo date('F d, Y', strtotime($por['receiving_date'])); ?></span>
                </div>
                <div class="info-row">
                    <span class="info-label">Created Date:</span>
                    <span class="info-value"><?php echo date('F d, Y H:i', strtotime($por['created_at'])); ?></span>
                </div>
                <?php if ($por['inventory_updated'] == 1): ?>
                <div class="info-row">
                    <span class="info-label">Inventory Updated:</span>
                    <span class="info-value"><?php echo date('F d, Y H:i', strtotime($por['inventory_updated_at'])); ?></span>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="info-box">
                <h3>Supplier Information</h3>
                <div class="info-row">
                    <span class="info-label">Supplier Name:</span>
                    <span class="info-value"><?php echo htmlspecialchars($por['supplier_name']); ?></span>
                </div>
                <?php if ($por['supplier_contact']): ?>
                <div class="info-row">
                    <span class="info-label">Contact Person:</span>
                    <span class="info-value"><?php echo htmlspecialchars($por['supplier_contact']); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($por['supplier_phone']): ?>
                <div class="info-row">
                    <span class="info-label">Phone:</span>
                    <span class="info-value"><?php echo htmlspecialchars($por['supplier_phone']); ?></span>
                </div>
                <?php endif; ?>
                <?php if ($por['supplier_email']): ?>
                <div class="info-row">
                    <span class="info-label">Email:</span>
                    <span class="info-value"><?php echo htmlspecialchars($por['supplier_email']); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Items Table -->
        <h3 style="color: #E31C1C; margin-bottom: 10px; font-size: 12pt;">Inspection Results</h3>
        <table class="items-table">
            <thead>
                <tr>
                    <th style="width: 25%;">Product</th>
                    <th class="text-center" style="width: 8%;">Ordered</th>
                    <th class="text-center" style="width: 8%;">Received</th>
                    <th class="text-center" style="width: 8%;">Accepted</th>
                    <th class="text-center" style="width: 8%;">Rejected</th>
                    <th class="text-center" style="width: 8%;">Damaged</th>
                    <th class="text-center" style="width: 10%;">Accept Rate</th>
                    <th class="text-center" style="width: 10%;">Inspection</th>
                    <th class="text-right" style="width: 8%;">Unit Price</th>
                    <th class="text-right" style="width: 7%;">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): 
                    $acceptanceRate = $item['received_quantity'] > 0 
                        ? round(($item['accepted_quantity'] / $item['received_quantity']) * 100, 1)
                        : 0;
                    $itemTotal = $item['received_quantity'] * $item['unit_price'];
                    
                    $inspectionClass = 'result-pending';
                    switch ($item['inspection_result']) {
                        case 'Passed': $inspectionClass = 'result-passed'; break;
                        case 'Failed': $inspectionClass = 'result-failed'; break;
                        case 'Conditional': $inspectionClass = 'result-conditional'; break;
                    }
                ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($item['product_name']); ?></strong><br>
                        <small style="color: #666;">SKU: <?php echo htmlspecialchars($item['sku']); ?></small>
                        <?php if ($item['batch_number']): ?>
                        <br><small style="color: #666;">Batch: <?php echo htmlspecialchars($item['batch_number']); ?></small>
                        <?php endif; ?>
                        <?php if ($item['expiration_date']): ?>
                        <br><small style="color: #F59E0B;">Exp: <?php echo date('M d, Y', strtotime($item['expiration_date'])); ?></small>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo $item['ordered_quantity']; ?></td>
                    <td class="text-center text-primary"><?php echo $item['received_quantity']; ?></td>
                    <td class="text-center text-success"><?php echo $item['accepted_quantity']; ?></td>
                    <td class="text-center text-danger"><?php echo $item['rejected_quantity']; ?></td>
                    <td class="text-center" style="color: #F59E0B; font-weight: 600;">
                        <?php echo $item['damaged_quantity'] ?? 0; ?>
                    </td>
                    <td class="text-center">
                        <span style="font-weight: 600; color: <?php echo $acceptanceRate >= 95 ? '#10B981' : ($acceptanceRate >= 80 ? '#F59E0B' : '#EF4444'); ?>">
                            <?php echo $acceptanceRate; ?>%
                        </span>
                    </td>
                    <td class="text-center">
                        <span class="inspection-result <?php echo $inspectionClass; ?>">
                            <?php echo htmlspecialchars($item['inspection_result']); ?>
                        </span>
                    </td>
                    <td class="text-right">₱<?php echo formatCurrency($item['unit_price']); ?></td>
                    <td class="text-right">₱<?php echo formatCurrency($itemTotal); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Totals Section -->
        <div class="totals-section">
            <div class="totals-box">
                <h4>Quantity Summary</h4>
                <div class="total-row">
                    <span>Total Ordered:</span>
                    <span><?php echo $totalOrdered; ?> units</span>
                </div>
                <div class="total-row">
                    <span>Total Received:</span>
                    <span class="text-primary"><?php echo $totalReceived; ?> units</span>
                </div>
                <div class="total-row">
                    <span>Total Accepted:</span>
                    <span class="text-success"><?php echo $totalAccepted; ?> units</span>
                </div>
                <div class="total-row">
                    <span>Total Rejected:</span>
                    <span class="text-danger"><?php echo $totalRejected; ?> units</span>
                </div>
                <div class="total-row">
                    <span>Overall Acceptance Rate:</span>
                    <span><?php echo $totalReceived > 0 ? round(($totalAccepted / $totalReceived) * 100, 1) : 0; ?>%</span>
                </div>
            </div>
            
            <div class="totals-box">
                <h4>Value Summary</h4>
                <div class="total-row">
                    <span>Received Value:</span>
                    <span>₱<?php echo formatCurrency($totalValue); ?></span>
                </div>
                <div class="total-row">
                    <span>Rejected Value:</span>
                    <span>₱<?php echo formatCurrency($totalValue - $acceptedValue); ?></span>
                </div>
                <div class="total-row">
                    <span>Accepted Value:</span>
                    <span class="text-success">₱<?php echo formatCurrency($acceptedValue); ?></span>
                </div>
            </div>
        </div>

        <!-- Notes Section -->
        <?php if ($por['notes'] || $por['inspection_notes']): ?>
        <div class="notes-section">
            <?php if ($por['notes']): ?>
            <div class="notes-box">
                <h4>General Notes</h4>
                <div class="notes-content"><?php echo htmlspecialchars($por['notes']); ?></div>
            </div>
            <?php endif; ?>
            
            <?php if ($por['inspection_notes']): ?>
            <div class="notes-box">
                <h4>Inspection Notes</h4>
                <div class="notes-content"><?php echo htmlspecialchars($por['inspection_notes']); ?></div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- Evidence Section -->
        <?php if (!empty($evidenceFiles)): ?>
        <div class="evidence-section">
            <h4 style="color: #E31C1C; margin-bottom: 10px; font-size: 10pt;">Evidence Files</h4>
            <div class="evidence-list">
                <?php foreach ($evidenceFiles as $index => $file): ?>
                <div class="evidence-item">
                    📎 Evidence #<?php echo $index + 1; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Signatures Section -->
        <div class="signatures-section">
            <div class="signature-box">
                <div class="signature-line">
                    _______________________
                </div>
                <div class="signature-label">Received By</div>
                <div class="signature-label" style="font-size: 8pt; margin-top: 2px;">Quality Control</div>
            </div>
            
            <div class="signature-box">
                <div class="signature-line">
                    _______________________
                </div>
                <div class="signature-label">Verified By</div>
                <div class="signature-label" style="font-size: 8pt; margin-top: 2px;">Warehouse Manager</div>
            </div>
            
            <div class="signature-box">
                <div class="signature-line">
                    _______________________
                </div>
                <div class="signature-label">Approved By</div>
                <div class="signature-label" style="font-size: 8pt; margin-top: 2px;">Operations Manager</div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>This is a computer-generated document for RAM-YUM Product & Inventory Operations System</p>
            <p>Printed on <?php echo date('F d, Y H:i:s'); ?> | Document ID: <?php echo $por['por_number']; ?></p>
        </div>
    </div>

    <script>
        // Auto-print on load (optional, commented out by default)
        // window.onload = function() { window.print(); }
    </script>
</body>
</html>
