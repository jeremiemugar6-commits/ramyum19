<?php
/**
 * RAM-YUM Store — Outbound Mail (SMTP via PHPMailer)
 *
 * Configuration is read from a `.env` file in the project root (never
 * commit real credentials — `.env` should be listed in .gitignore).
 * See `.env.example` for the required keys.
 *
 * If no `.env` file is present, or OTP_DEMO_MODE is on and SMTP host
 * is unset, sending is skipped gracefully and the caller (auth.php)
 * falls back to exposing the code via OTP_DEMO_MODE for local testing.
 */

// PHPMailer — support both Composer path and legacy flat path
$_phpmailer_base = null;
foreach ([
    __DIR__ . '/../vendor/phpmailer/phpmailer/src',  // Composer default
    __DIR__ . '/../vendor/phpmailer/src',            // legacy flat layout
] as $_candidate) {
    if (is_readable($_candidate . '/PHPMailer.php')) {
        $_phpmailer_base = $_candidate;
        break;
    }
}
if ($_phpmailer_base === null) {
    // Soft-fail: allow app to boot in OTP demo mode without vendor installed
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer', false)) {
        // Stub so auth.php can still load; real send will no-op in demo mode
        class_alias('stdClass', 'PHPMailer\PHPMailer\PHPMailer');
    }
} else {
    require_once $_phpmailer_base . '/Exception.php';
    require_once $_phpmailer_base . '/PHPMailer.php';
    require_once $_phpmailer_base . '/SMTP.php';
}
unset($_phpmailer_base, $_candidate);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Minimal .env parser — no external dependency needed. Lines are
 * KEY=VALUE, blank lines and lines starting with # are ignored.
 * Already-set environment variables are not overwritten.
 */
function load_env(string $path): void
{
    static $loaded = false;
    if ($loaded || !is_readable($path)) {
        return;
    }
    $loaded = true;

    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }
        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);
        // Strip matching surrounding quotes, if any.
        if (strlen($value) >= 2 && (
            ($value[0] === '"' && $value[-1] === '"') ||
            ($value[0] === "'" && $value[-1] === "'")
        )) {
            $value = substr($value, 1, -1);
        }
        if (getenv($key) === false) {
            putenv("{$key}={$value}");
        }
        $_ENV[$key] = $value;
    }
}

load_env(__DIR__ . '/../.env');

function env_val(string $key, ?string $default = null): ?string
{
    $value = getenv($key);
    return ($value === false || $value === '') ? $default : $value;
}

define('SMTP_HOST',      env_val('SMTP_HOST', ''));
define('SMTP_PORT',      (int) env_val('SMTP_PORT', '587'));
define('SMTP_USERNAME',  env_val('SMTP_USERNAME', ''));
define('SMTP_PASSWORD',  env_val('SMTP_PASSWORD', ''));
define('SMTP_ENCRYPTION', env_val('SMTP_ENCRYPTION', 'tls')); // 'tls' or 'ssl'
define('SMTP_FROM_EMAIL', env_val('SMTP_FROM_EMAIL', 'no-reply@ramyum.online'));
define('SMTP_FROM_NAME',  env_val('SMTP_FROM_NAME', 'RAM-YUM System'));

/**
 * Sends the OTP verification email via PHPMailer/SMTP. Returns true on
 * success. Never throws — failures are caught and logged by the caller
 * (log_security_event), never surfaced to the end user with technical
 * detail.
 */
function send_otp_email_smtp(string $toEmail, string $toName, string $code, int $ttlMinutes): bool
{
    if (SMTP_HOST === '') {
        // No SMTP configured (e.g. local/demo environment). Let the
        // caller fall back to OTP_DEMO_MODE instead of hard-failing.
        return false;
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->Port       = SMTP_PORT;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USERNAME;
        $mail->Password   = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_ENCRYPTION === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);

        $mail->isHTML(true);
        $mail->Subject = 'RAMYUM Login Verification Code';

        $safeName = htmlspecialchars($toName, ENT_QUOTES, 'UTF-8');
        $mail->Body = <<<HTML
            <div style="font-family:Segoe UI,Arial,sans-serif;max-width:480px;margin:0 auto;color:#1f2937;">
                <h2 style="color:#FF7A00;margin-bottom:4px;">RAM-YUM</h2>
                <p>Hello {$safeName},</p>
                <p>A login attempt was made on your RAMYUM account.</p>
                <p style="margin:24px 0;text-align:center;">
                    <span style="display:inline-block;font-size:28px;letter-spacing:6px;font-weight:700;
                        background:#FFF3E8;color:#E53935;padding:12px 20px;border-radius:8px;">{$code}</span>
                </p>
                <p>This code will expire in {$ttlMinutes} minutes.</p>
                <p style="color:#6b7280;font-size:0.85rem;">
                    If you did not attempt to log in, please ignore this email and
                    contact the system administrator if necessary.
                </p>
                <p>Regards,<br>RAMYUM System</p>
            </div>
        HTML;

        $mail->AltBody = "Hello {$toName},\n\nA login attempt was made on your RAMYUM account.\n"
            . "Your verification code is: {$code}\n\nThis code will expire in {$ttlMinutes} minutes.\n\n"
            . "If you did not attempt to log in, please ignore this email and contact the system administrator if necessary.\n\n"
            . "Regards,\nRAMYUM System";

        $mail->send();
        return true;
    } catch (PHPMailerException | Throwable $e) {
        error_log('[RAM-YUM] OTP email send failed: ' . $e->getMessage());
        return false;
    }
}
