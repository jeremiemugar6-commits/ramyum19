<?php
/**
 * CHECK INVENTORY MOVEMENTS - Detailed Analysis
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "INVENTORY MOVEMENTS - DETAILED ANALYSIS\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Get all movements
$stmt = $db->query("SELECT id, data, created_at FROM inventory_movements ORDER BY created_at DESC");
$movements = $stmt->fetchAll();

echo "Total movements: " . count($movements) . "\n\n";

// Group by reference type
$byType = [];
$byProduct = [];

foreach ($movements as $movement) {
    $data = json_decode($movement['data'], true);
    
    $refType = $data['referenceType'] ?? 'unknown';
    $productId = $data['productId'] ?? 'unknown';
    
    if (!isset($byType[$refType])) {
        $byType[$refType] = [];
    }
    $byType[$refType][] = $data;
    
    if (!isset($byProduct[$productId])) {
        $byProduct[$productId] = [];
    }
    $byProduct[$productId][] = $data;
}

echo "MOVEMENTS BY REFERENCE TYPE:\n";
echo "───────────────────────────────────────────────────────────────────────\n";
foreach ($byType as $type => $movements) {
    echo "{$type}: " . count($movements) . " movements\n";
}

echo "\n";
echo "DETAILED MOVEMENTS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

foreach ($movements as $movement) {
    $data = json_decode($movement['data'], true);
    
    echo "\nMovement ID: {$movement['id']}\n";
    echo "  Created: {$movement['created_at']}\n";
    echo "  Product: {$data['productName']} (ID: {$data['productId']})\n";
    echo "  Type: {$data['type']}\n";
    echo "  Reference: {$data['referenceType']} - {$data['referenceId']}\n";
    echo "  Quantity: {$data['quantity']}\n";
    echo "  Balance: {$data['previousBalance']} → {$data['newBalance']}\n";
    echo "  Reason: {$data['reason']}\n";
    echo "  Notes: {$data['notes']}\n";
}

echo "\n";
echo "PRODUCTS WITH MOVEMENTS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";
foreach ($byProduct as $productId => $movements) {
    echo "Product {$productId}: " . count($movements) . " movements\n";
}

echo "\n";

// Check for POR-related movements specifically
echo "CHECKING FOR POR-RELATED MOVEMENTS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$porMovements = $db->query("
    SELECT id, data FROM inventory_movements
    WHERE JSON_EXTRACT(data, '$.referenceType') = 'POR'
")->fetchAll();

echo "Movements with referenceType='POR': " . count($porMovements) . "\n";

if (count($porMovements) > 0) {
    foreach ($porMovements as $mov) {
        $data = json_decode($mov['data'], true);
        echo "  - {$data['referenceId']}: {$data['productName']} ({$data['quantity']} units)\n";
    }
} else {
    echo "  (None found - This indicates POR inventory updates may not have created movements)\n";
}

echo "\n";

// Check completed PORs
echo "COMPLETED PORS WITH INVENTORY_UPDATED:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$completedPORs = $db->query("
    SELECT 
        por.*,
        (SELECT COUNT(*) FROM proof_of_receiving_items WHERE por_id = por.id) as item_count
    FROM proof_of_receiving por
    WHERE status = 'Completed' AND inventory_updated = 1
    ORDER BY por_number
")->fetchAll();

echo "Completed PORs: " . count($completedPORs) . "\n\n";

foreach ($completedPORs as $por) {
    echo "POR: {$por['por_number']}\n";
    echo "  Supplier: {$por['supplier_name']}\n";
    echo "  Items: {$por['item_count']}\n";
    echo "  Inventory Updated: " . ($por['inventory_updated'] ? 'Yes' : 'No') . "\n";
    echo "  Updated At: {$por['inventory_updated_at']}\n";
    
    // Check if movements exist for this POR
    $porRefStmt = $db->prepare("
        SELECT id, data FROM inventory_movements
        WHERE JSON_EXTRACT(data, '$.referenceId') = ?
    ");
    $porRefStmt->execute([$por['por_number']]);
    $porMovs = $porRefStmt->fetchAll();
    
    echo "  Movements found: " . count($porMovs) . "\n";
    
    if (count($porMovs) > 0) {
        foreach ($porMovs as $mov) {
            $movData = json_decode($mov['data'], true);
            echo "    - {$movData['productName']}: +{$movData['quantity']} units\n";
        }
    }
    
    echo "\n";
}

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "ANALYSIS COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
