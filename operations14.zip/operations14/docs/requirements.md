# Proof of Receiving (POR) Feature - Requirements Document

**Project:** RAM-YUM Product & Inventory Operations System  
**Feature:** Proof of Receiving (POR) Enhancement  
**Date:** October 3, 2026  
**Type:** Feature Enhancement (NOT a rebuild)

---

## EXECUTIVE SUMMARY

Add a formal **Proof of Receiving (POR)** feature to the existing Receiving & Inspection module. This feature provides documented confirmation that products from a Purchase Order were physically received, inspected, and accepted before inventory updates occur.

**Key Principle:** Inventory should ONLY be updated based on accepted/received quantities recorded in the completed POR transaction, not automatically when a PO exists.

---

## CURRENT SYSTEM ANALYSIS

### Existing Implementation

**Database:**
- `receivings` table exists with JSON data storage
- Current fields: receivingNumber (GR-YYYY-NNNN), poId, poNumber, supplierId, supplier, receivedDate, receivedBy, totalReceived, totalValue, items[], notes, status
- `inventory_movements` table tracks stock changes with reference to receiving records
- `damage_evidence` table exists (from panel-revisions-migration.sql) but NOT integrated

**Receiving Module (`modules/receiving/receiving.js`):**
- Generates GR numbers (GR-YYYY-NNNN format)
- Two views: Pending Deliveries, Receiving History
- Receiving workflow:
  1. Select approved PO
  2. Enter quantities received per item
  3. Add notes
  4. Complete receiving → creates receiving record + updates inventory + updates PO status
- Supports partial receiving
- Automatic PO status updates: Approved → Partially Received → Fully Received
- Creates inventory_movements records linked to receiving

**Current Receiving Record Structure:**
```json
{
  "receivingNumber": "GR-2026-0001",
  "poId": "demo_po_003",
  "poNumber": "PO-2026-0003",
  "supplierId": "s3",
  "supplier": "Asia Grocery Supply",
  "receivedDate": "2026-10-01T02:21:39.000Z",
  "receivedBy": "Admin User",
  "totalReceived": 15,
  "totalValue": 1425.00,
  "items": [{
    "productId": "p10",
    "productName": "Korean Seaweed Snack",
    "orderedQuantity": 15,
    "previouslyReceived": 0,
    "quantityReceived": 15,
    "newTotalReceived": 15,
    "unitCost": 95.00,
    "subtotal": 1425.00
  }],
  "notes": "Complete delivery received in good condition",
  "status": "Completed"
}
```

**Gaps Identified:**
1. ❌ No formal inspection step with condition recording (Accepted/Damaged/Rejected/Missing/Excess)
2. ❌ No separation between "delivered quantity" and "accepted quantity"
3. ❌ No formal POR document generation (printable/PDF)
4. ❌ No damage evidence integration in receiving UI
5. ❌ No batch/lot number or expiration date tracking per receiving
6. ❌ No delivery reference or supplier invoice number tracking
7. ❌ No location/branch tracking (if multi-location)
8. ❌ No inspection results or discrepancy documentation
9. ❌ Limited receiving status workflow (only "Completed")

---

## REQUIREMENTS

### 1. POR WORKFLOW ENHANCEMENT

**Current Flow:**
```
Approved PO → Select PO → Enter Quantities → Complete → Inventory Updated
```

**New Enhanced Flow:**
```
Approved PO 
  ↓
Receive Delivery (Record Delivered Quantities)
  ↓
Inspect Items (Record Condition: Accepted/Damaged/Rejected/Missing/Excess)
  ↓
Record Discrepancies (Photos required for damaged items)
  ↓
Review Summary (Show: Ordered, Delivered, Accepted, Rejected, Damaged, Missing)
  ↓
Confirm & Create POR
  ↓
Update Inventory (ONLY accepted quantities)
  ↓
Generate Printable POR Document
```

**Acceptance Criteria:**
- Multi-step receiving process with clear progression
- Cannot skip inspection for items with discrepancies
- Cannot complete receiving without resolving all discrepancies
- Inventory only updated with accepted quantities
- POR number generated in format: `POR-YYYY-NNNNNN` (reuse existing GR number as POR number)

---

### 2. POR DATA MODEL

**Enhance existing `receivings` record to include POR fields:**

#### POR Header Fields (add to existing)
- ✅ `receivingNumber` → repurpose as `porNumber` (keep GR-YYYY-NNNN format or rename to POR-YYYY-NNNNNN)
- ✅ `poNumber` (existing)
- ✅ `supplier` (existing)
- ✅ `receivedDate` (existing)
- ✅ `receivedBy` (existing)
- ➕ `receivedTime` (extract from receivedDate or add separately)
- ➕ `location` (e.g., "Main Store", "Branch A") - optional if multi-location not supported
- ➕ `deliveryReferenceNumber` (supplier's delivery note number)
- ➕ `supplierInvoiceNumber` (supplier's invoice number)
- ➕ `inspectionStatus` (Draft / Pending Inspection / Inspected / Completed / Cancelled)
- ✅ `notes` → rename to `remarks` for clarity
- ➕ `inspectionDate` (when inspection was completed)
- ➕ `inspectedBy` (who performed inspection)

#### POR Item Detail Fields (enhance existing items array)
- ✅ `productName` (existing)
- ➕ `sku` (add if not present)
- ➕ `unit` (from product catalog)
- ✅ `orderedQuantity` (existing)
- ➕ `deliveredQuantity` (what physically arrived)
- ➕ `acceptedQuantity` (what passed inspection)
- ➕ `rejectedQuantity` (failed inspection, will NOT go to inventory)
- ➕ `damagedQuantity` (damaged, will NOT go to inventory unless repaired)
- ➕ `missingQuantity` (ordered but not delivered)
- ➕ `excessQuantity` (delivered but not ordered)
- ➕ `batchNumber` (lot number if applicable)
- ➕ `expirationDate` (if applicable)
- ➕ `inspectionResult` (Accepted / Accepted with Discrepancy / Partially Accepted / Rejected)
- ➕ `itemRemarks` (per-item notes)
- ➕ `conditionPhotos` (array of photo paths if damage evidence exists)

**Quantity Validation Logic:**
```
deliveredQuantity = acceptedQuantity + rejectedQuantity + damagedQuantity
missingQuantity = orderedQuantity - deliveredQuantity
excessQuantity = deliveredQuantity - orderedQuantity (if positive)
```

**Acceptance Criteria:**
- All quantity fields properly validated
- Photos REQUIRED for damaged items (integrate with existing damage_evidence table)
- Cannot save POR if quantities don't add up correctly
- Support for over-delivery (excess) and under-delivery (missing)

---

### 3. INSPECTION STEP

**Add inspection stage to receiving workflow:**

**Inspection Results:**
- ✅ **Accepted** - All items received in good condition
- ⚠️ **Accepted with Discrepancy** - Items accepted but with notes (e.g., near expiry)
- 🟡 **Partially Accepted** - Some items accepted, some rejected/damaged
- ❌ **Rejected** - Items rejected (will not enter inventory)

**Discrepancy Types (per item):**
- Damaged packaging
- Incorrect product
- Short quantity
- Expired product
- Near-expiry product
- Wrong SKU
- Quality issues
- Other (with remarks)

**Acceptance Criteria:**
- Inspection UI integrated into existing receiving modal
- Support recording multiple discrepancy types per item
- Photos required for damaged or rejected items
- Inspection can be saved as Draft and resumed later
- Final submission requires all discrepancies resolved

---

### 4. DAMAGE EVIDENCE INTEGRATION

**Reuse existing `damage_evidence` table:**

Current schema (from panel-revisions-migration.sql):
```sql
CREATE TABLE `damage_evidence` (
  `id` varchar(40) PRIMARY KEY,
  `receiving_id` varchar(40) NOT NULL,
  `po_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `ordered_quantity` decimal(12,2) DEFAULT 0,
  `received_quantity` decimal(12,2) DEFAULT 0,
  `damaged_quantity` decimal(12,2) DEFAULT 0,
  `damage_description` text,
  `evidence_image_path` varchar(500),
  `recorded_by` varchar(100) NOT NULL,
  `recorded_at` datetime DEFAULT current_timestamp(),
  ...
)
```

**Integration Requirements:**
- When user marks item as "Damaged" or "Rejected", prompt for photo upload
- Reuse existing `api/upload-image.php` for photo handling
- Upload rules: JPG/JPEG/PNG/WEBP only, 5MB max, real MIME validation
- Store photos in `/uploads/damage-evidence/`
- Link damage_evidence records to receiving record via `receiving_id`
- Display damage photos in POR details view

**Acceptance Criteria:**
- Camera upload + file upload fallback
- Cannot complete receiving with damaged items unless photo uploaded
- Damage evidence visible on POR document
- Photos stored securely with proper validation

---

### 5. INVENTORY UPDATE LOGIC

**CRITICAL REQUIREMENT:** Only accepted quantity goes to inventory.

**Current Implementation:**
```javascript
// modules/receiving/receiving.js line ~440
const newStock = parseInt(product.stock) + receivingItem.quantityReceived;
```

**New Logic:**
```javascript
const newStock = parseInt(product.stock) + receivingItem.acceptedQuantity;
// NOT deliveredQuantity, NOT quantityReceived
```

**Inventory Movement Record:**
```javascript
{
  type: 'Stock In',
  referenceType: 'RECEIVING',
  referenceId: porNumber,
  referencePO: poNumber,
  quantity: acceptedQuantity,  // ONLY accepted
  reason: 'Purchase Order Receiving - POR',
  notes: 'Delivered: X, Accepted: Y, Damaged: Z, Rejected: W'
}
```

**Rejected/Damaged Handling:**
- Create separate inventory_movement records with type: 'Stock Adjustment' or 'Stock Out'
- Reference type: 'DAMAGE' or 'REJECTION'
- Negative quantity for rejected/damaged
- Link to damage_evidence record

**Acceptance Criteria:**
- Inventory NEVER increases by rejected or damaged quantities
- Duplicate prevention: check if receiving already processed before updating inventory
- Transaction-safe: rollback all changes if any step fails
- Audit trail: all inventory changes traceable to POR

---

### 6. PO STATUS INTEGRATION

**Current Logic (preserve):**
```javascript
// Determine new PO status
const totalOrdered = updatedPOItems.reduce((sum, item) => sum + item.quantity, 0);
const totalNowReceived = updatedPOItems.reduce((sum, item) => sum + (item.receivedQuantity || 0), 0);

if (totalNowReceived === 0) newPOStatus = 'Approved';
else if (totalNowReceived >= totalOrdered) newPOStatus = 'Fully Received';
else newPOStatus = 'Partially Received';
```

**Enhancement:**
```javascript
// receivedQuantity should be acceptedQuantity for PO status calculation
const totalNowReceived = updatedPOItems.reduce((sum, item) => sum + (item.acceptedQuantity || 0), 0);
```

**Acceptance Criteria:**
- PO status based on accepted quantities, not just delivered
- PO marked "Fully Received" only when all ordered quantities are accepted
- Damaged/rejected items don't count toward "Fully Received"

---

### 7. POR LIST & DETAILS VIEW

**Add "Proof of Receiving" tab to existing Receiving module:**

**Current Tabs:**
- Pending Deliveries
- Receiving History

**New Structure:**
- Pending Deliveries (POs awaiting receiving)
- ➕ In Progress (Draft/Pending Inspection PORs)
- Receiving History (Completed PORs)

**POR List Columns:**
| POR No. | PO No. | Supplier | Date | Received By | Inspection Status | Action |
|---------|--------|----------|------|-------------|-------------------|--------|
| POR-2026-0001 | PO-2026-0001 | ABC Foods | Oct 3, 2026 | Admin User | Completed | View / Print |

**Filters:**
- POR Number
- PO Number
- Supplier
- Date Range
- Inspection Status

**Acceptance Criteria:**
- Integrated into existing receiving.js module
- Reuse existing DataTable component
- Search and filter functionality
- Click row to view details

---

### 8. POR DETAILS & PRINT VIEW

**Create printable POR document:**

**Layout:**
```
┌─────────────────────────────────────────────────────────┐
│            RAM-YUM KOREAN & JAPANESE STORE             │
│                  PROOF OF RECEIVING                     │
├─────────────────────────────────────────────────────────┤
│ POR No.: POR-2026-000001        Date: October 3, 2026  │
│ PO No.: PO-2026-000001          Time: 10:30 AM         │
│ Supplier: ABC Korean Food Distributor                   │
│ Delivery Ref: DEL-12345         Invoice: INV-67890     │
│ Received By: Staff Name         Location: Main Store   │
├─────────────────────────────────────────────────────────┤
│ ITEMS RECEIVED                                          │
├──────────┬─────┬────────┬──────────┬─────────┬─────────┤
│ Product  │ SKU │Ordered │Delivered │ Accepted│ Status  │
├──────────┼─────┼────────┼──────────┼─────────┼─────────┤
│ Samyang  │SAM01│   50   │    50    │    48   │ Disc.   │
│ Shin     │SHN01│   30   │    28    │    28   │ Short   │
│ Ottogi   │OTT01│   20   │    20    │    20   │ OK      │
├──────────┴─────┴────────┴──────────┴─────────┴─────────┤
│ INSPECTION SUMMARY                                      │
│ ☑ Quantity Verified    ☑ Product Verified              │
│ ☑ Condition Checked    ☑ Documentation Complete        │
├─────────────────────────────────────────────────────────┤
│ DISCREPANCIES                                           │
│ • Samyang: 2 units damaged (photo evidence attached)   │
│ • Shin Ramyun: 2 units short delivery                  │
├─────────────────────────────────────────────────────────┤
│ REMARKS                                                 │
│ Products were inspected upon delivery. Damaged items    │
│ photographed and segregated.                            │
├─────────────────────────────────────────────────────────┤
│ SIGNATURES                                              │
│                                                         │
│ Received By: ________________  Date: ___________       │
│                                                         │
│ Inspected By: _______________  Date: ___________       │
│                                                         │
│ Authorized By: ______________  Date: ___________       │
└─────────────────────────────────────────────────────────┘
```

**Print Functionality:**
- Print button opens browser print dialog
- CSS: `@media print` to hide sidebar, buttons, navigation
- Clean, professional formatting
- Optional: integrate with existing PDF generation if available

**Acceptance Criteria:**
- Printable view matches spec above
- Dynamic data from POR record
- Print-friendly CSS (no sidebar/nav/buttons)
- Damage photos included in printout if available
- Professional layout suitable for official records

---

### 9. PERMISSIONS

**Reuse existing role system:**

**Roles (from existing auth system):**
- admin
- manager  
- staff

**Permissions:**

| Action | Admin | Manager | Staff |
|--------|-------|---------|-------|
| View pending POs | ✅ | ✅ | ✅ |
| Create receiving/POR | ✅ | ✅ | ✅ |
| Perform inspection | ✅ | ✅ | ✅ |
| Upload damage photos | ✅ | ✅ | ✅ |
| Complete POR | ✅ | ✅ | ❌ |
| Cancel POR | ✅ | ✅ | ❌ |
| View all PORs | ✅ | ✅ | Own only |
| Print POR | ✅ | ✅ | ✅ |
| Edit completed POR | ✅ | ❌ | ❌ |

**Acceptance Criteria:**
- Integrate with existing `includes/auth.php`
- No new role system needed
- Staff can only view their own PORs
- Admin/Manager can view and manage all PORs

---

### 10. AUDIT TRAIL

**Use existing `security_logs` table:**

**New Event Types to Add:**
- `POR_CREATED` - POR record created
- `POR_INSPECTION_STARTED` - Inspection began
- `POR_INSPECTION_COMPLETED` - Inspection finished
- `POR_COMPLETED` - POR finalized and inventory updated
- `POR_CANCELLED` - POR cancelled
- `POR_EDITED` - POR modified (admin only)
- `POR_PRINTED` - POR document printed/viewed
- `DAMAGE_EVIDENCE_UPLOADED` - Damage photo uploaded

**Log Format:**
```javascript
log_security_event('POR_CREATED', userId, username, {
  porNumber: 'POR-2026-0001',
  poNumber: 'PO-2026-0001',
  supplier: 'ABC Foods',
  totalReceived: 98,
  totalAccepted: 95
});
```

**Acceptance Criteria:**
- All POR actions logged
- Reuse existing `log_security_event()` function from includes/functions.php
- Logs viewable in Settings → Security Logs
- No new audit system needed

---

### 11. NUMBERING CONVENTION

**Current System:** GR-YYYY-NNNN (Goods Receipt)

**Options:**

**Option A: Keep GR format**
- Pros: No migration needed, existing code works
- Cons: "GR" doesn't convey "Proof of Receiving"

**Option B: Change to POR format**
- Format: POR-YYYY-NNNNNN (6 digits for clarity)
- Pros: Clear naming, professional
- Cons: Need to update existing code, possibly confuse existing records

**RECOMMENDATION: Option A (Keep GR-YYYY-NNNN)**
- Less risk, faster implementation
- Update UI labels to show "POR #" but keep GR numbering internally
- Display as: "POR #: GR-2026-0001"

**Acceptance Criteria:**
- Reuse existing `generateReceivingNumber()` function
- No breaking changes to existing data
- UI clearly shows it's a "Proof of Receiving"

---

### 12. UI/UX INTEGRATION REQUIREMENTS

**Design Principles:**
- Reuse existing CSS from `assets/css/main.css`
- Follow existing orange (#FF7A00) / red (#E53935) theme
- Use existing modal component for multi-step workflow
- Use existing DataTable component for lists
- Use existing toast notifications
- Use existing BadgeHelper for status badges

**Step-by-Step Receiving Flow UI:**

**Step 1: Select PO** (existing, keep)
**Step 2: Record Delivered Quantities** (enhance existing)
- Show: Product, Ordered, Previously Received, Remaining, Deliver Now
- Add fields: Batch Number, Expiration Date
- Add: Delivery Reference, Supplier Invoice fields at header level

**Step 3: Inspection** (new)
- For each item: Delivered, Accepted, Rejected, Damaged, Missing
- Dropdown: Inspection Result (Accepted / Accepted with Discrepancy / Partially Accepted / Rejected)
- Textbox: Item Remarks
- Button: Upload Damage Photo (if damaged or rejected)

**Step 4: Review & Confirm** (new)
- Summary table showing all quantities
- Highlight discrepancies
- Show total accepted quantity and inventory impact
- Show damage evidence photos thumbnails
- Confirm button

**Step 5: Completion** (existing, enhance)
- Show success message with POR number
- Offer: View POR / Print POR / Return to List

**Acceptance Criteria:**
- Wizard-style multi-step flow
- Previous/Next buttons
- Cannot proceed to next step if required fields missing
- Clear visual feedback for required fields
- Mobile-responsive (inherit from existing responsive CSS)

---

## OUT OF SCOPE

The following are explicitly OUT OF SCOPE for this feature:

❌ QR code scanning for POs (this is separate feature request)  
❌ Camera-based QR scanning workflow  
❌ Real-time barcode scanning  
❌ Email notifications for completed PORs  
❌ PDF generation library installation (unless already exists)  
❌ Multi-warehouse location tracking (unless already supported)  
❌ Supplier portal integration  
❌ Automated discrepancy alerts  
❌ Return to supplier workflow  
❌ Credit note generation  
❌ Integration with accounting system  
❌ Mobile app development  
❌ Rebuilding existing receiving module from scratch  
❌ Changing database structure (continue using JSON storage)  

---

## TECHNICAL CONSTRAINTS

1. **Preserve Existing System:**
   - Do NOT rebuild existing modules
   - Do NOT drop or recreate existing tables
   - Do NOT break existing PO → Receiving → Inventory workflow

2. **Database:**
   - Continue using JSON data storage in `receivings` table
   - Reuse existing `damage_evidence` table
   - Safe, additive-only migrations

3. **Backend:**
   - PHP 8.0+
   - MySQL 5.7+ / MariaDB 10.3+
   - Reuse existing `api/data.php` patterns
   - Reuse existing `includes/auth.php` and `includes/functions.php`

4. **Frontend:**
   - Vanilla JavaScript (no frameworks)
   - Reuse existing components: modal.js, table.js, toast.js
   - Reuse existing CSS (no Bootstrap or other CSS frameworks)
   - Maintain orange/red theme

5. **Authentication:**
   - Reuse existing session-based auth
   - Reuse existing role system (admin/manager/staff)

6. **File Uploads:**
   - Reuse existing `api/upload-image.php`
   - JPG/JPEG/PNG/WEBP only
   - 5MB max size
   - Real MIME validation
   - Secure file naming

---

## SUCCESS CRITERIA

This feature will be considered successfully implemented when:

✅ Receiving workflow includes formal inspection step  
✅ POR records separate delivered vs accepted quantities  
✅ Damaged items require photo evidence  
✅ Inventory ONLY increases by accepted quantities  
✅ PO status based on accepted (not just delivered) quantities  
✅ Printable POR document generated  
✅ POR list and details views functional  
✅ Damage evidence integrated with receiving UI  
✅ All actions audit-logged  
✅ Permissions enforced by role  
✅ No existing functionality broken  
✅ No duplicate inventory updates  

---

## APPROVAL REQUIRED

This requirements document must be approved before proceeding to design.md.

**Next Steps:**
1. ✅ Review requirements accuracy
2. ✅ Confirm scope is correct
3. ✅ Verify no existing functionality will be broken
4. ➡️ Proceed to design.md

---

**Status:** ⏳ AWAITING APPROVAL
