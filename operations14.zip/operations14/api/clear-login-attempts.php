<?php
require_once __DIR__ . '/../includes/auth.php';

$admin = require_admin_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$db = getDB();
$count = (int) $db->query('SELECT COUNT(*) AS c FROM login_attempts')->fetch()['c'];
$db->exec('DELETE FROM login_attempts');

log_security_event('ADMIN_CLEARED_LOGIN_BLOCKS', $admin['id'], $admin['username'], ['cleared' => $count]);

json_response(['success' => true, 'cleared' => $count]);
