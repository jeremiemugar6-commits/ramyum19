<?php
/**
 * API endpoint to provide demo integration configuration to the frontend
 */

require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

try {
    $demoConfig = getDemoConfig();
    
    echo json_encode([
        'success' => true,
        'data' => $demoConfig
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to retrieve demo configuration'
    ]);
}