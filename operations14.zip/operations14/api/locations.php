<?php
/**
 * Locations/Branches Management API
 * Handles location CRUD operations and inventory summary per location
 */

require_once __DIR__ . '/../includes/auth.php';

require_login_api();

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Role-based access control
$currentUser = $_SESSION['user'] ?? null;
$userRole = $currentUser['role'] ?? 'staff';
$canManage = $userRole === 'admin' || $userRole === 'manager';

header('Content-Type: application/json');

try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $userRole, $currentUser);
            break;
        case 'POST':
            if (!$canManage) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Access denied']);
                return;
            }
            handlePost($db, $action, $currentUser);
            break;
        case 'PUT':
            if (!$canManage) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Access denied']);
                return;
            }
            handlePut($db, $action, $currentUser);
            break;
        case 'DELETE':
            if ($userRole !== 'admin') {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Admin access required']);
                return;
            }
            handleDelete($db, $action, $currentUser);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function handleGet($db, $action, $userRole, $currentUser) {
    switch ($action) {
        case 'all':
            getAllLocations($db);
            break;
        case 'location':
            getLocationById($db, $_GET['id'] ?? '');
            break;
        case 'inventory-summary':
            getLocationInventorySummary($db, $_GET['locationId'] ?? '');
            break;
        case 'statistics':
            getLocationsStatistics($db);
            break;
        case 'transfers':
            getLocationTransfers($db, $_GET['locationId'] ?? '');
            break;
        default:
            // Default to all locations for backward compatibility
            getAllLocations($db);
    }
}

function handlePost($db, $action, $currentUser) {
    switch ($action) {
        case 'create':
            createLocation($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePut($db, $action, $currentUser) {
    switch ($action) {
        case 'update':
            updateLocation($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handleDelete($db, $action, $currentUser) {
    switch ($action) {
        case 'delete':
            deleteLocation($db, $_GET['id'] ?? '', $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function getAllLocations($db) {
    try {
        $stmt = $db->query("
            SELECT l.id, l.data, l.created_at, l.updated_at,
                   COUNT(il.id) as inventory_count,
                   COALESCE(SUM(CAST(JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.quantity')) AS DECIMAL(10,2))), 0) as total_inventory
            FROM locations l
            LEFT JOIN inventory_locations il ON l.id = JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.locationId'))
            GROUP BY l.id, l.data, l.created_at, l.updated_at
            ORDER BY JSON_UNQUOTE(JSON_EXTRACT(l.data, '$.name'))
        ");
        
        $results = $stmt->fetchAll();

        // Count open (pending / approved / in transit) transfers touching each location
        $openCounts = [];
        $tstmt = $db->query("SELECT data FROM stock_transfers");
        foreach ($tstmt->fetchAll() as $trow) {
            $t = json_decode($trow['data'], true);
            if (!in_array($t['status'] ?? '', ['Pending Approval', 'Approved', 'In Transit'], true)) continue;
            foreach (['sourceLocationId', 'destinationLocationId'] as $k) {
                if (!empty($t[$k])) { $openCounts[$t[$k]] = ($openCounts[$t[$k]] ?? 0) + 1; }
            }
        }

        $locations = array_map(function($row) use ($openCounts) {
            $locationData = json_decode($row['data'], true);
            $locationData['openTransfers'] = $openCounts[$row['id']] ?? 0;
            $locationData['inventoryCount'] = (int)$row['inventory_count'];
            $locationData['totalInventory'] = (float)$row['total_inventory'];
            $locationData['createdAt'] = $row['created_at'];
            $locationData['updatedAt'] = $row['updated_at'];
            return $locationData;
        }, $results);

        echo json_encode(['success' => true, 'data' => $locations]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch locations: ' . $e->getMessage());
    }
}

function getLocationById($db, $locationId) {
    if (empty($locationId)) {
        echo json_encode(['success' => false, 'error' => 'Location ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT data FROM locations WHERE id = ?");
        $stmt->execute([$locationId]);
        $result = $stmt->fetch();

        if (!$result) {
            echo json_encode(['success' => false, 'error' => 'Location not found']);
            return;
        }

        $location = json_decode($result['data'], true);
        echo json_encode(['success' => true, 'data' => $location]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch location: ' . $e->getMessage());
    }
}

function getLocationInventorySummary($db, $locationId) {
    if (empty($locationId)) {
        echo json_encode(['success' => false, 'error' => 'Location ID required']);
        return;
    }

    try {
        // Get inventory items for this location with product details
        $stmt = $db->prepare("
            SELECT il.data as inventory_data, p.data as product_data
            FROM inventory_locations il
            JOIN products p ON JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.productId')) = p.id
            WHERE JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.locationId')) = ?
            ORDER BY JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.name'))
        ");
        $stmt->execute([$locationId]);
        $results = $stmt->fetchAll();

        $inventory = array_map(function($row) {
            $inventoryData = json_decode($row['inventory_data'], true);
            $productData = json_decode($row['product_data'], true);
            
            return [
                'productId' => $inventoryData['productId'],
                'productName' => $productData['name'],
                'sku' => $productData['sku'],
                'category' => $productData['category'],
                'quantity' => $inventoryData['quantity'],
                'availableQuantity' => $inventoryData['availableQuantity'],
                'reservedQuantity' => $inventoryData['reservedQuantity'] ?? 0,
                'price' => $productData['price'],
                'reorderLevel' => $productData['reorderLevel'] ?? 0,
                'status' => $inventoryData['quantity'] <= ($productData['reorderLevel'] ?? 0) ? 
                    ($inventoryData['quantity'] === 0 ? 'Out of Stock' : 'Low Stock') : 'In Stock'
            ];
        }, $results);

        // Calculate summary statistics
        $summary = [
            'totalProducts' => count($inventory),
            'totalQuantity' => array_sum(array_column($inventory, 'quantity')),
            'totalValue' => array_sum(array_map(function($item) {
                return $item['quantity'] * $item['price'];
            }, $inventory)),
            'lowStockItems' => count(array_filter($inventory, function($item) {
                return $item['status'] === 'Low Stock';
            })),
            'outOfStockItems' => count(array_filter($inventory, function($item) {
                return $item['status'] === 'Out of Stock';
            }))
        ];

        echo json_encode([
            'success' => true, 
            'data' => [
                'inventory' => $inventory,
                'summary' => $summary
            ]
        ]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch inventory summary: ' . $e->getMessage());
    }
}

function getLocationTransfers($db, $locationId) {
    if (empty($locationId)) {
        echo json_encode(['success' => false, 'error' => 'Location ID required']);
        return;
    }

    try {
        $stmt = $db->query("SELECT data FROM stock_transfers ORDER BY created_at DESC");
        $outgoing = [];
        $incoming = [];
        $counts = ['pending' => 0, 'approved' => 0, 'inTransit' => 0, 'completed' => 0, 'rejected' => 0];

        foreach ($stmt->fetchAll() as $row) {
            $t = json_decode($row['data'], true);
            $isSource = ($t['sourceLocationId'] ?? '') === $locationId;
            $isDest   = ($t['destinationLocationId'] ?? '') === $locationId;
            if (!$isSource && !$isDest) continue;

            // Tidy product names saved by older versions
            $itemNames = [];
            foreach (($t['items'] ?? []) as $item) {
                $lines = array_values(array_filter(array_map('trim', preg_split('/\R/', (string)($item['productName'] ?? '')))));
                $itemNames[] = $lines[0] ?? '';
            }

            $summary = [
                'id' => $t['id'] ?? '',
                'transferNumber' => $t['transferNumber'] ?? '',
                'status' => $t['status'] ?? '',
                'sourceLocationName' => $t['sourceLocationName'] ?? '',
                'destinationLocationName' => $t['destinationLocationName'] ?? '',
                'totalItems' => $t['totalItems'] ?? 0,
                'products' => array_slice(array_filter($itemNames), 0, 3),
                'createdAt' => $t['createdAt'] ?? ''
            ];

            if ($isSource) { $outgoing[] = $summary; }
            if ($isDest)   { $incoming[] = $summary; }

            switch ($t['status'] ?? '') {
                case 'Pending Approval': $counts['pending']++; break;
                case 'Approved':         $counts['approved']++; break;
                case 'In Transit':       $counts['inTransit']++; break;
                case 'Completed':        $counts['completed']++; break;
                case 'Rejected':         $counts['rejected']++; break;
            }
        }

        echo json_encode([
            'success' => true,
            'data' => [
                'outgoing' => array_slice($outgoing, 0, 10),
                'incoming' => array_slice($incoming, 0, 10),
                'counts' => $counts
            ]
        ]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch location transfers: ' . $e->getMessage());
    }
}

function getLocationsStatistics($db) {
    try {
        // Get overall statistics
        $stats = [
            'totalLocations' => 0,
            'activeLocations' => 0,
            'totalInventoryValue' => 0,
            'averageInventoryPerLocation' => 0
        ];

        // Count locations
        $stmt = $db->query("SELECT COUNT(*) as total FROM locations");
        $stats['totalLocations'] = (int)$stmt->fetch()['total'];

        $stmt = $db->query("SELECT COUNT(*) as active FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Active'");
        $stats['activeLocations'] = (int)$stmt->fetch()['active'];

        // Calculate inventory value across all locations
        $stmt = $db->query("
            SELECT 
                COALESCE(SUM(
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.quantity')) AS DECIMAL(10,2)) * 
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.price')) AS DECIMAL(10,2))
                ), 0) as total_value,
                COALESCE(AVG(
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.quantity')) AS DECIMAL(10,2)) * 
                    CAST(JSON_UNQUOTE(JSON_EXTRACT(p.data, '$.price')) AS DECIMAL(10,2))
                ), 0) as avg_value
            FROM inventory_locations il
            JOIN products p ON JSON_UNQUOTE(JSON_EXTRACT(il.data, '$.productId')) = p.id
        ");
        $result = $stmt->fetch();
        $stats['totalInventoryValue'] = (float)$result['total_value'];
        $stats['averageInventoryPerLocation'] = $stats['activeLocations'] > 0 ? 
            $stats['totalInventoryValue'] / $stats['activeLocations'] : 0;

        echo json_encode(['success' => true, 'data' => $stats]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch statistics: ' . $e->getMessage());
    }
}

function createLocation($db, $currentUser) {
    $input = get_json_input();
    
    // Validation
    $required = ['name', 'code', 'type'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            echo json_encode(['success' => false, 'error' => "Field '$field' is required"]);
            return;
        }
    }

    try {
        $db->beginTransaction();

        // Check if code already exists
        $stmt = $db->prepare("SELECT id FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.code')) = ?");
        $stmt->execute([$input['code']]);
        if ($stmt->fetch()) {
            throw new Exception('Location code already exists');
        }

        // Create location record
        $locationId = generate_id('loc');
        $locationData = [
            'id' => $locationId,
            'name' => $input['name'],
            'code' => strtoupper($input['code']),
            'type' => $input['type'],
            'address' => $input['address'] ?? '',
            'manager' => $input['manager'] ?? '',
            'phone' => $input['phone'] ?? '',
            'email' => $input['email'] ?? '',
            'status' => $input['status'] ?? 'Active',
            'capacity' => floatval($input['capacity'] ?? 1000),
            'description' => $input['description'] ?? '',
            'createdBy' => $currentUser['name'],
            'createdAt' => date('Y-m-d\TH:i:s.v\Z')
        ];

        $stmt = $db->prepare("INSERT INTO locations (id, data) VALUES (?, ?)");
        $stmt->execute([$locationId, json_encode($locationData)]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => $locationData,
            'message' => "Location '{$locationData['name']}' created successfully"
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function updateLocation($db, $currentUser) {
    $input = get_json_input();
    $locationId = $input['id'] ?? '';

    if (empty($locationId)) {
        echo json_encode(['success' => false, 'error' => 'Location ID required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get current location
        $stmt = $db->prepare("SELECT data FROM locations WHERE id = ?");
        $stmt->execute([$locationId]);
        $result = $stmt->fetch();
        
        if (!$result) {
            throw new Exception('Location not found');
        }

        $currentLocation = json_decode($result['data'], true);

        // Check if code is being changed and if new code exists
        if (isset($input['code']) && $input['code'] !== $currentLocation['code']) {
            $stmt = $db->prepare("SELECT id FROM locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.code')) = ? AND id != ?");
            $stmt->execute([$input['code'], $locationId]);
            if ($stmt->fetch()) {
                throw new Exception('Location code already exists');
            }
        }

        // Merge updates
        $updatedLocation = array_merge($currentLocation, array_filter([
            'name' => $input['name'] ?? null,
            'code' => isset($input['code']) ? strtoupper($input['code']) : null,
            'type' => $input['type'] ?? null,
            'address' => $input['address'] ?? null,
            'manager' => $input['manager'] ?? null,
            'phone' => $input['phone'] ?? null,
            'email' => $input['email'] ?? null,
            'status' => $input['status'] ?? null,
            'capacity' => isset($input['capacity']) ? floatval($input['capacity']) : null,
            'description' => $input['description'] ?? null
        ], function($value) { return $value !== null; }));

        $updatedLocation['updatedBy'] = $currentUser['name'];
        $updatedLocation['updatedAt'] = date('Y-m-d\TH:i:s.v\Z');

        $updateStmt = $db->prepare("UPDATE locations SET data = ? WHERE id = ?");
        $updateStmt->execute([json_encode($updatedLocation), $locationId]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'data' => $updatedLocation,
            'message' => "Location '{$updatedLocation['name']}' updated successfully"
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

function deleteLocation($db, $locationId, $currentUser) {
    if (empty($locationId)) {
        echo json_encode(['success' => false, 'error' => 'Location ID required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Check if location has inventory
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM inventory_locations WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?");
        $stmt->execute([$locationId]);
        $inventoryCount = $stmt->fetch()['count'];

        if ($inventoryCount > 0) {
            throw new Exception('Cannot delete location with existing inventory. Transfer inventory first.');
        }

        // Check if location is used in pending transfers
        $stmt = $db->prepare("
            SELECT COUNT(*) as count FROM stock_transfers 
            WHERE (JSON_UNQUOTE(JSON_EXTRACT(data, '$.sourceLocationId')) = ? 
                   OR JSON_UNQUOTE(JSON_EXTRACT(data, '$.destinationLocationId')) = ?)
            AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) IN ('Pending Approval', 'Approved', 'In Transit')
        ");
        $stmt->execute([$locationId, $locationId]);
        $transferCount = $stmt->fetch()['count'];

        if ($transferCount > 0) {
            throw new Exception('Cannot delete location with active transfers. Complete or cancel transfers first.');
        }

        // Get location name for response
        $stmt = $db->prepare("SELECT JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as name FROM locations WHERE id = ?");
        $stmt->execute([$locationId]);
        $result = $stmt->fetch();
        $locationName = $result ? $result['name'] : 'Unknown Location';

        // Delete location
        $stmt = $db->prepare("DELETE FROM locations WHERE id = ?");
        $stmt->execute([$locationId]);

        if ($stmt->rowCount() === 0) {
            throw new Exception('Location not found');
        }

        $db->commit();

        echo json_encode([
            'success' => true,
            'message' => "Location '$locationName' deleted successfully"
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}
?>