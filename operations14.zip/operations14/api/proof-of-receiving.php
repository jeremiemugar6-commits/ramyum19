<?php
/**
 * Proof of Receiving API Endpoints
 * Handles receiving workflow, POR documentation, photo evidence, and validation
 * Standardized to match other module patterns (stock-transfers, data)
 * 
 * SUPPLIER CONSISTENCY ENFORCEMENT:
 * - POR supplier MUST match PO supplier
 * - Supplier auto-populated from PO (readonly)
 * - Backend validation prevents supplier mismatches
 */

require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/supplier-validation.php';

header('Content-Type: application/json');

$currentUser = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

// Role-based access control
$userRole = $currentUser['role'] ?? 'staff';
$canApprove = $userRole === 'admin' || $userRole === 'manager';

try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $currentUser, $userRole);
            break;
        case 'POST':
            handlePost($db, $action, $currentUser);
            break;
        case 'PUT':
            handlePut($db, $action, $currentUser);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function handleGet($db, $action, $currentUser, $userRole) {
    switch ($action) {
        case 'list':
            listPORRecords($db, $userRole, $currentUser);
            break;
        case 'por':
            getPORById($db, $_GET['id'] ?? '');
            break;
        case 'by-po':
            getPORByPurchaseOrder($db, $_GET['poId'] ?? '');
            break;
        case 'pending':
            getPendingReceivings($db);
            break;
        case 'items':
            getPORItems($db, $_GET['porId'] ?? '');
            break;
        case 'photos':
            getPORPhotos($db, $_GET['porId'] ?? '');
            break;
        case 'stats':
            getReceivingStats($db);
            break;
        case 'po-supplier':
            // NEW: Get supplier info from PO for auto-population
            getPOSupplierInfo($db, $_GET['poId'] ?? '');
            break;
        case 'validate-chain':
            // NEW: Validate supplier consistency for a POR
            validateSupplierChain($db, $_GET['porId'] ?? '');
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePost($db, $action, $currentUser) {
    switch ($action) {
        case 'create':
            createPOR($db, $currentUser);
            break;
        case 'receive':
            recordReceiving($db, $currentUser);
            break;
        case 'add-photo':
            addPORPhoto($db, $currentUser);
            break;
        case 'record-damage':
            recordDamageEvidence($db, $currentUser);
            break;
        case 'complete':
            completePOR($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePut($db, $action, $currentUser) {
    switch ($action) {
        case 'update':
            updatePOR($db, $currentUser);
            break;
        case 'update-item':
            updatePORItem($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

/**
 * List all POR records with filtering
 */
function listPORRecords($db, $userRole, $currentUser) {
    try {
        // Staff can only see their own POR records, admin/manager can see all
        if ($userRole === 'staff') {
            $stmt = $db->prepare("
                SELECT * FROM proof_of_receiving 
                WHERE received_by = ? 
                ORDER BY created_at DESC
            ");
            $stmt->execute([$currentUser['id']]);
        } else {
            $stmt = $db->query("SELECT * FROM proof_of_receiving ORDER BY created_at DESC");
        }
        
        $porRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get items count for each POR
        foreach ($porRecords as &$por) {
            $itemsStmt = $db->prepare("SELECT COUNT(*) as count FROM proof_of_receiving_items WHERE por_id = ?");
            $itemsStmt->execute([$por['id']]);
            $por['itemsCount'] = $itemsStmt->fetch()['count'];
        }

        echo json_encode(['success' => true, 'data' => $porRecords]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch POR records: ' . $e->getMessage());
    }
}

/**
 * Get POR by ID with full details
 */
function getPORById($db, $porId) {
    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    try {
        // Get POR header
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $por = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$por) {
            echo json_encode(['success' => false, 'error' => 'POR not found']);
            return;
        }

        // Get POR items
        $itemsStmt = $db->prepare("SELECT * FROM proof_of_receiving_items WHERE por_id = ? ORDER BY created_at ASC");
        $itemsStmt->execute([$porId]);
        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

        // Get photos (if any)
        $photosStmt = $db->prepare("SELECT * FROM pod_photos WHERE pod_id = ? ORDER BY uploaded_at ASC");
        $photosStmt->execute([$porId]);
        $photos = $photosStmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => [
                'por' => $por,
                'items' => $items,
                'photos' => $photos
            ]
        ]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch POR: ' . $e->getMessage());
    }
}

/**
 * Get POR records by Purchase Order ID
 */
function getPORByPurchaseOrder($db, $poId) {
    if (empty($poId)) {
        echo json_encode(['success' => false, 'error' => 'Purchase Order ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE purchase_order_id = ? ORDER BY created_at DESC");
        $stmt->execute([$poId]);
        $porRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Get items for each POR
        foreach ($porRecords as &$por) {
            $itemsStmt = $db->prepare("SELECT * FROM proof_of_receiving_items WHERE por_id = ?");
            $itemsStmt->execute([$por['id']]);
            $por['items'] = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
        }

        echo json_encode(['success' => true, 'data' => $porRecords]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch POR records: ' . $e->getMessage());
    }
}

/**
 * Get pending receivings (approved POs that need receiving)
 * Includes auto-populated supplier information for each PO
 */
function getPendingReceivings($db) {
    try {
        $stmt = $db->query("
            SELECT data, id FROM purchase_orders 
            WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = 'Approved'
            AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.remainingItems')) > 0
            ORDER BY created_at ASC
        ");
        
        $pendingPOs = [];
        foreach ($stmt->fetchAll() as $row) {
            $po = json_decode($row['data'], true);
            
            // Add supplier details for display
            if (!empty($po['supplierId'])) {
                $supplierDetails = getSupplierDetails($db, $po['supplierId']);
                $po['supplierDetails'] = $supplierDetails;
            }
            
            $pendingPOs[] = $po;
        }

        echo json_encode(['success' => true, 'data' => $pendingPOs]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch pending receivings: ' . $e->getMessage());
    }
}

/**
 * Get POR items
 */
function getPORItems($db, $porId) {
    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving_items WHERE por_id = ? ORDER BY created_at ASC");
        $stmt->execute([$porId]);
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $items]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch POR items: ' . $e->getMessage());
    }
}

/**
 * Get POR photos
 */
function getPORPhotos($db, $porId) {
    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM pod_photos WHERE pod_id = ? ORDER BY uploaded_at ASC");
        $stmt->execute([$porId]);
        $photos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $photos]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch photos: ' . $e->getMessage());
    }
}

/**
 * Get receiving statistics
 */
function getReceivingStats($db) {
    try {
        $stats = [
            'totalPORs' => 0,
            'completedPORs' => 0,
            'pendingPORs' => 0,
            'totalItemsReceived' => 0,
            'damagedItems' => 0
        ];

        // Total PORs
        $totalStmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
        $stats['totalPORs'] = $totalStmt->fetch()['count'];

        // Completed PORs
        $completedStmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving WHERE status = 'Completed'");
        $stats['completedPORs'] = $completedStmt->fetch()['count'];

        // Pending PORs (Draft status in this schema)
        $pendingStmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving WHERE status = 'Draft'");
        $stats['pendingPORs'] = $pendingStmt->fetch()['count'];

        // Total items received
        $itemsStmt = $db->query("SELECT SUM(received_quantity) as total FROM proof_of_receiving_items");
        $stats['totalItemsReceived'] = $itemsStmt->fetch()['total'] ?? 0;

        // Damaged items
        $damagedStmt = $db->query("SELECT COUNT(*) as count FROM damage_evidence WHERE reference_type = 'RECEIVING'");
        $stats['damagedItems'] = $damagedStmt->fetch()['count'];

        echo json_encode(['success' => true, 'data' => $stats]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch stats: ' . $e->getMessage());
    }
}

/**
 * Create new POR record
 * ENFORCES SUPPLIER CONSISTENCY - Supplier must match PO
 */
function createPOR($db, $currentUser) {
    $input = get_json_input();
    
    // Basic field validation
    $required = ['purchaseOrderId', 'poNumber'];
    foreach ($required as $field) {
        if (empty($input[$field])) {
            echo json_encode(['success' => false, 'error' => "Field '$field' is required"]);
            return;
        }
    }

    try {
        $db->beginTransaction();
        
        // === CRITICAL: Auto-populate supplier from PO ===
        // This ensures supplier consistency and prevents manual tampering
        $autoSupplier = autoPopulateSupplierFromPO($db, $input['purchaseOrderId']);
        
        if (!$autoSupplier) {
            throw new Exception('Unable to retrieve supplier information from Purchase Order');
        }
        
        // Override any user-provided supplier data with PO supplier
        $input['supplierId'] = $autoSupplier['supplierId'];
        $input['supplierName'] = $autoSupplier['supplierName'];
        
        // === VALIDATION: Comprehensive POR creation validation ===
        $validation = validatePORCreation($db, $input);
        
        if (!$validation['valid']) {
            throw new Exception('Validation failed: ' . implode(', ', $validation['errors']));
        }

        // Generate POR number
        $porNumber = generatePORNumber($db);
        
        // Verify PO exists and is approved
        $poStmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $poStmt->execute([$input['purchaseOrderId']]);
        $poResult = $poStmt->fetch();
        
        if (!$poResult) {
            throw new Exception('Purchase order not found');
        }

        $po = json_decode($poResult['data'], true);
        
        if ($po['status'] !== 'Approved') {
            throw new Exception('Purchase order must be approved before receiving');
        }

        // Create POR record
        $porId = generate_id('por');
        $insertStmt = $db->prepare("
            INSERT INTO proof_of_receiving (
                id, por_number, purchase_order_id, po_number,
                supplier_id, supplier_name, receiving_date, receiving_time,
                status, received_by, received_by_name,
                remarks, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW(), 'Draft', ?, ?, ?, NOW(), NOW())
        ");
        
        $insertStmt->execute([
            $porId,
            $porNumber,
            $input['purchaseOrderId'],
            $input['poNumber'],
            $input['supplierId'],
            $input['supplierName'],
            $currentUser['id'],
            $currentUser['name'],
            $input['notes'] ?? null
        ]);

        // Log activity
        logReceivingActivity($db, $porId, 'POR_CREATED', $currentUser, [
            'porNumber' => $porNumber,
            'poNumber' => $input['poNumber'],
            'supplier' => $input['supplierName']
        ]);

        $db->commit();

        // Fetch created POR
        $newPORStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $newPORStmt->execute([$porId]);
        $newPOR = $newPORStmt->fetch(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => $newPOR,
            'message' => "POR $porNumber created successfully"
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Record receiving items
 */
function recordReceiving($db, $currentUser) {
    $input = get_json_input();
    
    $porId = $input['porId'] ?? '';
    $items = $input['items'] ?? [];

    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    if (empty($items) || !is_array($items)) {
        echo json_encode(['success' => false, 'error' => 'Items required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get POR
        $porStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $porStmt->execute([$porId]);
        $por = $porStmt->fetch(PDO::FETCH_ASSOC);

        if (!$por) {
            throw new Exception('POR not found');
        }

        // Get PO
        $poStmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $poStmt->execute([$por['purchase_order_id']]);
        $poResult = $poStmt->fetch();
        
        if (!$poResult) {
            throw new Exception('Purchase order not found');
        }

        $po = json_decode($poResult['data'], true);

        // Process each item
        $totalReceived = 0;
        foreach ($items as $item) {
            if (!isset($item['productId']) || !isset($item['quantity'])) {
                throw new Exception('Invalid item data');
            }

            if ($item['quantity'] <= 0) {
                throw new Exception('Received quantity must be greater than 0');
            }

            $totalReceived += $item['quantity'];

            // Create POR item record
            $itemId = generate_id('pori');
            $itemStmt = $db->prepare("
                INSERT INTO proof_of_receiving_items (
                    id, por_id, product_id, product_name, sku,
                    ordered_quantity, received_quantity, accepted_quantity, unit,
                    inspection_result, remarks, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $condition = $item['condition'] ?? 'Good';
            $inspectionResult = $condition === 'Good' ? 'Passed' : 'Failed';
            $acceptedQty = $condition === 'Good' ? $item['quantity'] : 0;
            
            $itemStmt->execute([
                $itemId,
                $porId,
                $item['productId'],
                $item['productName'],
                $item['sku'] ?? null,
                $item['orderedQuantity'] ?? $item['quantity'],
                $item['quantity'],
                $acceptedQty,
                $item['unit'] ?? 'pcs',
                $inspectionResult,
                $item['notes'] ?? null
            ]);

            // Update inventory
            updateInventoryForReceiving($db, $item, $por, $po, $currentUser);

            // Update PO item quantities
            updatePOItemQuantities($db, $po, $item);
        }

        // Update POR totals
        $updatePORStmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET total_received = COALESCE(total_received, 0) + ?,
                updated_at = NOW()
            WHERE id = ?
        ");
        $updatePORStmt->execute([$totalReceived, $porId]);

        // Log activity
        logReceivingActivity($db, $porId, 'ITEMS_RECEIVED', $currentUser, [
            'porNumber' => $por['por_number'],
            'itemsCount' => count($items),
            'totalQuantity' => $totalReceived
        ]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'message' => "Received $totalReceived items successfully",
            'data' => [
                'porId' => $porId,
                'itemsCount' => count($items),
                'totalReceived' => $totalReceived
            ]
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Complete POR
 */
function completePOR($db, $currentUser) {
    $input = get_json_input();
    $porId = $input['porId'] ?? '';
    $finalNotes = $input['notes'] ?? '';

    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get POR
        $porStmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $porStmt->execute([$porId]);
        $por = $porStmt->fetch(PDO::FETCH_ASSOC);

        if (!$por) {
            throw new Exception('POR not found');
        }

        if ($por['status'] === 'Completed') {
            throw new Exception('POR already completed');
        }

        // Work out the final totals + inspection result from the received items,
        // so a completed POR is never left showing the default 'Pending'.
        $sumStmt = $db->prepare("
            SELECT COALESCE(SUM(received_quantity), 0) AS received,
                   COALESCE(SUM(accepted_quantity), 0) AS accepted,
                   COALESCE(SUM(rejected_quantity), 0) AS rejected,
                   COUNT(*) AS item_count
            FROM proof_of_receiving_items WHERE por_id = ?
        ");
        $sumStmt->execute([$porId]);
        $sums = $sumStmt->fetch(PDO::FETCH_ASSOC);
        $received = (float)$sums['received'];
        $accepted = (float)$sums['accepted'];
        $rejected = (float)$sums['rejected'];
        // Items that were received but not accepted count as rejected for the result
        $notAccepted = max(0, $received - $accepted - $rejected);
        $finalInspection = derive_por_inspection_status($received, $accepted, $rejected + $notAccepted);

        // Update POR status
        $updateStmt = $db->prepare("
            UPDATE proof_of_receiving 
            SET status = 'Completed',
                inspection_status = ?,
                total_items = ?,
                total_received = ?,
                total_accepted = ?,
                total_rejected = ?,
                completed_at = NOW(),
                completed_by = ?,
                completed_by_name = ?,
                inspection_notes = ?,
                updated_at = NOW()
            WHERE id = ?
        ");
        $updateStmt->execute([
            $finalInspection,
            (int)$sums['item_count'],
            $received,
            $accepted,
            $rejected,
            $currentUser['id'],
            $currentUser['name'],
            $finalNotes,
            $porId
        ]);

        // Update PO status if all items received
        $poStmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $poStmt->execute([$por['purchase_order_id']]);
        $poResult = $poStmt->fetch();
        
        if ($poResult) {
            $po = json_decode($poResult['data'], true);
            
            if (isset($po['remainingItems']) && $po['remainingItems'] <= 0) {
                $po['status'] = 'Fully Received';
                $po['lastReceived'] = date('Y-m-d\TH:i:s.v\Z');
                
                $updatePOStmt = $db->prepare("UPDATE purchase_orders SET data = ? WHERE id = ?");
                $updatePOStmt->execute([json_encode($po), $por['purchase_order_id']]);
            }
        }

        // Log activity
        logReceivingActivity($db, $porId, 'POR_COMPLETED', $currentUser, [
            'porNumber' => $por['por_number'],
            'notes' => $finalNotes
        ]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'message' => "POR {$por['por_number']} completed successfully"
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Add photo to POR
 */
function addPORPhoto($db, $currentUser) {
    $porId = $_POST['porId'] ?? '';
    $photoType = $_POST['photoType'] ?? 'receiving';
    $caption = $_POST['caption'] ?? '';

    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    // Verify POR exists
    $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
    $stmt->execute([$porId]);
    $por = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$por) {
        echo json_encode(['success' => false, 'error' => 'POR not found']);
        return;
    }

    // Handle file upload
    if (empty($_FILES['photo'])) {
        echo json_encode(['success' => false, 'error' => 'Photo file required']);
        return;
    }

    try {
        $file = $_FILES['photo'];
        $uploadDir = __DIR__ . '/../uploads/receiving/';
        
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $fileExt = pathinfo($file['name'], PATHINFO_EXTENSION);
        $fileName = 'por_' . $porId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $fileExt;
        $filePath = $uploadDir . $fileName;

        if (move_uploaded_file($file['tmp_name'], $filePath)) {
            $photoId = generate_id('photo');
            $relativePathstmt = $db->prepare("
                INSERT INTO pod_photos (
                    id, pod_id, photo_type, file_path, caption,
                    uploaded_by_id, uploaded_by_name, uploaded_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            
            $relativePath = 'uploads/receiving/' . $fileName;
            $stmt->execute([
                $photoId,
                $porId,
                $photoType,
                $relativePath,
                $caption,
                $currentUser['id'],
                $currentUser['name']
            ]);

            echo json_encode([
                'success' => true,
                'data' => [
                    'photoId' => $photoId,
                    'path' => $relativePath
                ],
                'message' => 'Photo uploaded successfully'
            ]);
        } else {
            throw new Exception('Failed to upload photo');
        }
    } catch (Exception $e) {
        throw new Exception('Photo upload failed: ' . $e->getMessage());
    }
}

/**
 * Record damage evidence
 */
function recordDamageEvidence($db, $currentUser) {
    $input = get_json_input();
    
    $porId = $input['porId'] ?? '';
    $productId = $input['productId'] ?? '';
    $productName = $input['productName'] ?? '';
    $orderedQty = $input['orderedQuantity'] ?? 0;
    $receivedQty = $input['receivedQuantity'] ?? 0;
    $damagedQty = $input['damagedQuantity'] ?? 0;
    $damageType = $input['damageType'] ?? '';
    $description = $input['description'] ?? '';
    $imagePath = $input['imagePath'] ?? '';

    if (empty($porId) || empty($productId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID and Product ID required']);
        return;
    }

    try {
        // Get POR
        $stmt = $db->prepare("SELECT * FROM proof_of_receiving WHERE id = ?");
        $stmt->execute([$porId]);
        $por = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$por) {
            throw new Exception('POR not found');
        }

        $evidenceId = generate_id('dmg');
        
        $insertStmt = $db->prepare("
            INSERT INTO damage_evidence (
                id, reference_type, reference_id, reference_number,
                pod_id, product_id, product_name, expected_quantity,
                received_quantity, damaged_quantity, damage_type,
                damage_description, evidence_image_path,
                recorded_by_id, recorded_by_name, recorded_at
            ) VALUES (?, 'RECEIVING', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $insertStmt->execute([
            $evidenceId,
            $por['purchase_order_id'],
            $por['por_number'],
            $porId,
            $productId,
            $productName,
            $orderedQty,
            $receivedQty,
            $damagedQty,
            $damageType,
            $description,
            $imagePath,
            $currentUser['id'],
            $currentUser['name']
        ]);

        echo json_encode([
            'success' => true,
            'data' => ['evidenceId' => $evidenceId],
            'message' => 'Damage evidence recorded successfully'
        ]);

    } catch (Exception $e) {
        throw new Exception('Failed to record damage evidence: ' . $e->getMessage());
    }
}

/**
 * Update POR
 */
function updatePOR($db, $currentUser) {
    $input = get_json_input();
    $porId = $input['porId'] ?? '';

    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    try {
        $updates = [];
        $params = [];

        if (isset($input['notes'])) {
            $updates[] = "remarks = ?";
            $params[] = $input['notes'];
        }

        if (isset($input['inspectionNotes'])) {
            $updates[] = "inspection_notes = ?";
            $params[] = $input['inspectionNotes'];
        }

        if (isset($input['status'])) {
            $updates[] = "status = ?";
            $params[] = $input['status'];
        }

        if (empty($updates)) {
            echo json_encode(['success' => false, 'error' => 'No fields to update']);
            return;
        }

        $updates[] = "updated_at = NOW()";
        $params[] = $porId;

        $sql = "UPDATE proof_of_receiving SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        echo json_encode(['success' => true, 'message' => 'POR updated successfully']);

    } catch (Exception $e) {
        throw new Exception('Failed to update POR: ' . $e->getMessage());
    }
}

/**
 * Update POR item
 */
function updatePORItem($db, $currentUser) {
    $input = get_json_input();
    $itemId = $input['itemId'] ?? '';

    if (empty($itemId)) {
        echo json_encode(['success' => false, 'error' => 'Item ID required']);
        return;
    }

    try {
        $updates = [];
        $params = [];

        if (isset($input['receivedQuantity'])) {
            $updates[] = "received_quantity = ?";
            $params[] = $input['receivedQuantity'];
        }

        if (isset($input['acceptedQuantity'])) {
            $updates[] = "accepted_quantity = ?";
            $params[] = $input['acceptedQuantity'];
        }

        if (isset($input['condition'])) {
            $inspectionResult = $input['condition'] === 'Good' ? 'Passed' : 'Failed';
            $updates[] = "inspection_result = ?";
            $params[] = $inspectionResult;
        }

        if (isset($input['notes'])) {
            $updates[] = "remarks = ?";
            $params[] = $input['notes'];
        }

        if (empty($updates)) {
            echo json_encode(['success' => false, 'error' => 'No fields to update']);
            return;
        }

        $updates[] = "updated_at = NOW()";
        $params[] = $itemId;

        $sql = "UPDATE proof_of_receiving_items SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);

        echo json_encode(['success' => true, 'message' => 'Item updated successfully']);

    } catch (Exception $e) {
        throw new Exception('Failed to update item: ' . $e->getMessage());
    }
}

// Helper functions

function generatePORNumber($db) {
    $currentYear = date('Y');
    $stmt = $db->prepare("SELECT por_number FROM proof_of_receiving WHERE por_number LIKE ?");
    $stmt->execute(["POR-$currentYear-%"]);
    $results = $stmt->fetchAll();
    
    $maxNumber = 0;
    foreach ($results as $row) {
        if (preg_match("/POR-$currentYear-(\d{4})/", $row['por_number'], $matches)) {
            $maxNumber = max($maxNumber, intval($matches[1]));
        }
    }
    
    $nextNumber = str_pad($maxNumber + 1, 4, '0', STR_PAD_LEFT);
    return "POR-$currentYear-$nextNumber";
}

function updateInventoryForReceiving($db, $item, $por, $po, $currentUser) {
    $productId = $item['productId'];
    $quantity = $item['quantity'];

    // Update product stock in products table
    $productStmt = $db->prepare("SELECT data FROM products WHERE id = ?");
    $productStmt->execute([$productId]);
    $productResult = $productStmt->fetch();
    
    if ($productResult) {
        $productData = json_decode($productResult['data'], true);
        $productData['stock'] = ($productData['stock'] ?? 0) + $quantity;
        $productData['lastUpdated'] = date('Y-m-d\TH:i:s.v\Z');
        
        $updateProductStmt = $db->prepare("UPDATE products SET data = ? WHERE id = ?");
        $updateProductStmt->execute([json_encode($productData), $productId]);
    }

    // Create inventory movement record
    $movementId = generate_id('mov');
    $movementData = [
        'id' => $movementId,
        'productId' => $productId,
        'productName' => $item['productName'],
        'movementType' => 'Stock In',
        'quantity' => $quantity,
        'referenceType' => 'RECEIVING',
        'referenceId' => $por['por_number'],
        'performedBy' => $currentUser['id'],
        'performedByName' => $currentUser['name'],
        'reason' => 'Goods Received',
        'notes' => "Received from {$por['supplier_name']} - PO {$por['po_number']}",
        'createdAt' => date('Y-m-d\TH:i:s.v\Z')
    ];

    $stmt = $db->prepare("INSERT INTO inventory_movements (id, data) VALUES (?, ?)");
    $stmt->execute([$movementId, json_encode($movementData)]);
}

function updatePOItemQuantities($db, &$po, $receivedItem) {
    // Find and update the matching item in PO
    foreach ($po['items'] as &$poItem) {
        if ($poItem['productId'] === $receivedItem['productId']) {
            $poItem['receivedQuantity'] = ($poItem['receivedQuantity'] ?? 0) + $receivedItem['quantity'];
            $poItem['remainingQuantity'] = $poItem['quantity'] - $poItem['receivedQuantity'];
            break;
        }
    }

    // Recalculate totals
    $po['receivedItems'] = array_sum(array_column($po['items'], 'receivedQuantity'));
    $po['remainingItems'] = $po['totalItems'] - $po['receivedItems'];
    
    // Update status
    if ($po['remainingItems'] <= 0) {
        $po['status'] = 'Fully Received';
    } elseif ($po['receivedItems'] > 0) {
        $po['status'] = 'Partially Received';
    }

    // Save updated PO
    $updateStmt = $db->prepare("UPDATE purchase_orders SET data = ? WHERE id = ?");
    $updateStmt->execute([json_encode($po), $po['id']]);
}

function logReceivingActivity($db, $porId, $actionType, $currentUser, $details) {
    try {
        $stmt = $db->prepare("
            INSERT INTO security_logs (event_type, user_id, username, details, ip_address, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $actionType,
            $currentUser['id'],
            $currentUser['name'],
            json_encode(array_merge($details, ['porId' => $porId])),
            $_SERVER['REMOTE_ADDR'] ?? null
        ]);
    } catch (Exception $e) {
        // Log error but don't fail the operation
        error_log("Failed to log receiving activity: " . $e->getMessage());
    }
}
?>


/**
 * Get supplier information from PO for auto-population
 * NEW: Supports supplier consistency enforcement
 */
function getPOSupplierInfo($db, $poId) {
    if (empty($poId)) {
        echo json_encode(['success' => false, 'error' => 'PO ID required']);
        return;
    }

    try {
        $supplierInfo = autoPopulateSupplierFromPO($db, $poId);
        
        if (!$supplierInfo) {
            echo json_encode(['success' => false, 'error' => 'Unable to retrieve supplier from PO']);
            return;
        }

        echo json_encode([
            'success' => true,
            'data' => $supplierInfo,
            'message' => 'Supplier information auto-populated from Purchase Order'
        ]);
    } catch (Exception $e) {
        throw new Exception('Failed to get PO supplier info: ' . $e->getMessage());
    }
}

/**
 * Validate supplier consistency chain for a POR
 * NEW: Data integrity validation endpoint
 */
function validateSupplierChain($db, $porId) {
    if (empty($porId)) {
        echo json_encode(['success' => false, 'error' => 'POR ID required']);
        return;
    }

    try {
        $validation = validateTransactionSupplierChain($db, $porId);
        
        echo json_encode([
            'success' => true,
            'data' => $validation
        ]);
    } catch (Exception $e) {
        throw new Exception('Failed to validate supplier chain: ' . $e->getMessage());
    }
}
