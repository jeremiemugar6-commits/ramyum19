<?php
/**
 * Supplier Data Integrity Checker
 * Comprehensive validation tool for supplier consistency across all transactions
 */

require_once 'config/database.php';
require_once 'includes/supplier-validation.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "SUPPLIER DATA INTEGRITY CHECK\n";
echo "RAM-YUM Product & Inventory Operations System\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

$totalIssues = 0;
$totalChecks = 0;

// ============================================================
// CHECK 1: Verify all suppliers exist in master
// ============================================================
echo "CHECK 1: Supplier Master Data Validation\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT COUNT(*) as count FROM suppliers");
$supplierCount = $stmt->fetch()['count'];
echo "Total suppliers in master: $supplierCount\n";

// Check for suppliers with missing names
$stmt = $db->query("SELECT * FROM suppliers");
$suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);

$missingNames = 0;
foreach ($suppliers as $supplier) {
    $data = json_decode($supplier['data'], true);
    if (empty($data['name']) && empty($data['company'])) {
        $missingNames++;
        echo "⚠ Supplier {$supplier['id']}: Missing name/company\n";
    }
}

if ($missingNames > 0) {
    echo "✗ Found $missingNames suppliers with missing names\n";
    $totalIssues += $missingNames;
} else {
    echo "✓ All suppliers have names\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// CHECK 2: Purchase Order supplier references
// ============================================================
echo "CHECK 2: Purchase Order Supplier References\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT id, data FROM purchase_orders");
$pos = $stmt->fetchAll();

$poIssues = 0;
foreach ($pos as $po) {
    $poData = json_decode($po['data'], true);
    $supplierId = $poData['supplierId'] ?? null;
    $poNumber = $poData['poNumber'] ?? $po['id'];
    
    if (empty($supplierId)) {
        echo "✗ PO $poNumber: Missing supplier ID\n";
        $poIssues++;
    } else if (!validateSupplierExists($db, $supplierId)) {
        echo "✗ PO $poNumber: Invalid supplier ID ($supplierId)\n";
        $poIssues++;
    }
}

if ($poIssues > 0) {
    echo "✗ Found $poIssues PO supplier issues\n";
    $totalIssues += $poIssues;
} else {
    echo "✓ All POs have valid supplier references\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// CHECK 3: POR → PO supplier consistency
// ============================================================
echo "CHECK 3: POR-PO Supplier Consistency\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
$porCount = $stmt->fetch()['count'];
echo "Total POR records: $porCount\n";

$validationQuery = "SELECT * FROM v_por_supplier_validation";
$stmt = $db->query($validationQuery);
$validations = $stmt->fetchAll(PDO::FETCH_ASSOC);

$consistencyIssues = 0;
foreach ($validations as $val) {
    if ($val['validation_status'] !== 'VALID') {
        echo "✗ {$val['por_number']}: Supplier mismatch\n";
        echo "  POR Supplier: {$val['por_supplier_id']} ({$val['por_supplier_name']})\n";
        echo "  PO Supplier: {$val['po_supplier_id']} ({$val['po_supplier_name']})\n";
        $consistencyIssues++;
    }
}

if ($consistencyIssues > 0) {
    echo "✗ Found $consistencyIssues POR-PO consistency issues\n";
    $totalIssues += $consistencyIssues;
} else {
    echo "✓ All POR records match their PO supplier\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// CHECK 4: POR supplier master reference
// ============================================================
echo "CHECK 4: POR Supplier Master References\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("
    SELECT COUNT(*) as count
    FROM proof_of_receiving por
    LEFT JOIN suppliers s ON por.supplier_id = s.id
    WHERE s.id IS NULL
");
$orphanedPORs = $stmt->fetch()['count'];

if ($orphanedPORs > 0) {
    echo "✗ Found $orphanedPORs POR records with invalid supplier references\n";
    
    // Show details
    $detailStmt = $db->query("
        SELECT por.por_number, por.supplier_id, por.supplier_name
        FROM proof_of_receiving por
        LEFT JOIN suppliers s ON por.supplier_id = s.id
        WHERE s.id IS NULL
    ");
    
    foreach ($detailStmt->fetchAll(PDO::FETCH_ASSOC) as $orphan) {
        echo "  - {$orphan['por_number']}: {$orphan['supplier_id']} ({$orphan['supplier_name']})\n";
    }
    
    $totalIssues += $orphanedPORs;
} else {
    echo "✓ All POR records reference valid suppliers\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// CHECK 5: Transaction chain integrity
// ============================================================
echo "CHECK 5: Complete Transaction Chain Validation\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT id, por_number FROM proof_of_receiving LIMIT 5");
$samplePORs = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo "Validating " . count($samplePORs) . " sample POR records...\n";

$chainIssues = 0;
foreach ($samplePORs as $por) {
    $validation = validateTransactionSupplierChain($db, $por['id']);
    
    if (!$validation['valid']) {
        echo "✗ {$por['por_number']}: Chain validation failed\n";
        foreach ($validation['checks'] as $check) {
            if ($check['status'] !== 'PASS') {
                echo "  - {$check['check']}: {$check['message']}\n";
            }
        }
        $chainIssues++;
    }
}

if ($chainIssues > 0) {
    echo "✗ Found $chainIssues transaction chain issues\n";
    $totalIssues += $chainIssues;
} else {
    echo "✓ All sampled transactions have valid supplier chains\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// CHECK 6: Foreign key constraints
// ============================================================
echo "CHECK 6: Foreign Key Constraints\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$fkQuery = "
    SELECT 
        CONSTRAINT_NAME,
        TABLE_NAME,
        COLUMN_NAME,
        REFERENCED_TABLE_NAME,
        REFERENCED_COLUMN_NAME
    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
    WHERE TABLE_SCHEMA = DATABASE()
    AND REFERENCED_TABLE_NAME IS NOT NULL
    AND (TABLE_NAME = 'proof_of_receiving' OR TABLE_NAME = 'purchase_orders')
    ORDER BY TABLE_NAME
";

$stmt = $db->query($fkQuery);
$fks = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($fks) > 0) {
    echo "✓ Found " . count($fks) . " foreign key constraints:\n";
    foreach ($fks as $fk) {
        echo "  - {$fk['TABLE_NAME']}.{$fk['COLUMN_NAME']} → {$fk['REFERENCED_TABLE_NAME']}.{$fk['REFERENCED_COLUMN_NAME']}\n";
    }
} else {
    echo "⚠ No foreign key constraints found\n";
    echo "  Note: PO uses JSON data field, FK not possible\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// CHECK 7: Duplicate suppliers
// ============================================================
echo "CHECK 7: Duplicate Supplier Detection\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT data FROM suppliers");
$allSuppliers = $stmt->fetchAll();

$names = [];
foreach ($allSuppliers as $row) {
    $data = json_decode($row['data'], true);
    $name = strtolower(trim($data['company'] ?? $data['name'] ?? ''));
    if (!empty($name)) {
        if (isset($names[$name])) {
            $names[$name]++;
        } else {
            $names[$name] = 1;
        }
    }
}

$duplicates = array_filter($names, function($count) { return $count > 1; });

if (count($duplicates) > 0) {
    echo "⚠ Found " . count($duplicates) . " potential duplicate supplier names:\n";
    foreach ($duplicates as $name => $count) {
        echo "  - \"$name\" appears $count times\n";
    }
    $totalIssues += count($duplicates);
} else {
    echo "✓ No duplicate supplier names found\n";
}
$totalChecks++;

echo "\n";

// ============================================================
// SUMMARY
// ============================================================
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "INTEGRITY CHECK SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "Total checks performed: $totalChecks\n";
echo "Total issues found: $totalIssues\n";

if ($totalIssues == 0) {
    echo "\n✓✓✓ SYSTEM STATUS: EXCELLENT ✓✓✓\n";
    echo "All supplier data is consistent across the purchasing flow.\n";
} else {
    echo "\n⚠⚠⚠ ACTION REQUIRED ⚠⚠⚠\n";
    echo "Supplier data inconsistencies detected. Review issues above.\n";
}

echo "═══════════════════════════════════════════════════════════════════════\n";

// Generate detailed report
echo "\nDETAILED STATISTICS:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stats = [
    'Suppliers' => $db->query("SELECT COUNT(*) as cnt FROM suppliers")->fetch()['cnt'],
    'Purchase Orders' => $db->query("SELECT COUNT(*) as cnt FROM purchase_orders")->fetch()['cnt'],
    'Receivings' => $db->query("SELECT COUNT(*) as cnt FROM receivings")->fetch()['cnt'],
    'POR Records' => $db->query("SELECT COUNT(*) as cnt FROM proof_of_receiving")->fetch()['cnt'],
    'Valid POR-PO Matches' => $db->query("SELECT COUNT(*) as cnt FROM v_por_supplier_validation WHERE validation_status = 'VALID'")->fetch()['cnt']
];

foreach ($stats as $label => $value) {
    echo sprintf("%-25s: %d\n", $label, $value);
}

echo "\n";
?>
