<?php
/**
 * Canonical status helpers for PO and Stock Transfers.
 * One source of truth for allowed values and transitions.
 */

/** Canonical Purchase Order statuses */
const PO_STATUSES = [
    'Draft',
    'Pending',
    'Approved',
    'Partially Received',
    'Fully Received',
    'Cancelled',
];

/**
 * Normalize any legacy PO status string to a canonical value.
 */
function normalize_po_status(?string $status): string
{
    $s = trim((string) $status);
    $map = [
        'PENDING' => 'Pending',
        'pending' => 'Pending',
        'APPROVED' => 'Approved',
        'approved' => 'Approved',
        'RECEIVED' => 'Fully Received',
        'Received' => 'Fully Received',
        'Fully Received' => 'Fully Received',
        'Partially Received' => 'Partially Received',
        'DRAFT' => 'Draft',
        'draft' => 'Draft',
        'CANCELLED' => 'Cancelled',
        'Cancelled' => 'Cancelled',
        'Canceled' => 'Cancelled',
        'Archived' => 'Cancelled',
    ];
    if (isset($map[$s])) {
        return $map[$s];
    }
    if (in_array($s, PO_STATUSES, true)) {
        return $s;
    }
    return $s !== '' ? $s : 'Draft';
}

/**
 * Allowed PO status transitions (from => list of to).
 */
function po_allowed_transitions(): array
{
    return [
        'Draft' => ['Pending', 'Cancelled'],
        'Pending' => ['Approved', 'Cancelled', 'Draft'],
        'Approved' => ['Partially Received', 'Fully Received', 'Cancelled'],
        'Partially Received' => ['Fully Received', 'Cancelled'],
        'Fully Received' => [], // terminal for normal flow
        'Cancelled' => [], // terminal
    ];
}

function po_can_transition(string $from, string $to): bool
{
    $from = normalize_po_status($from);
    $to = normalize_po_status($to);
    if ($from === $to) {
        return true;
    }
    $allowed = po_allowed_transitions();
    return isset($allowed[$from]) && in_array($to, $allowed[$from], true);
}

/** Canonical Stock Transfer statuses */
const TRANSFER_STATUSES = [
    'Draft',
    'Pending Approval',
    'Approved',
    'In Transit',
    'Completed',
    'Cancelled',
    'Rejected',
];

function normalize_transfer_status(?string $status): string
{
    $s = trim((string) $status);
    $map = [
        'Pending' => 'Pending Approval',
        'PENDING' => 'Pending Approval',
        'pending' => 'Pending Approval',
        'Pending Approval' => 'Pending Approval',
        'Submitted' => 'Pending Approval',
        'APPROVED' => 'Approved',
        'Dispatched' => 'In Transit',
        'In Transit' => 'In Transit',
        'Received' => 'Completed',
        'Completed' => 'Completed',
        'COMPLETE' => 'Completed',
        'Cancelled' => 'Cancelled',
        'Canceled' => 'Cancelled',
        'Rejected' => 'Rejected',
        'Draft' => 'Draft',
        'Created' => 'Draft',
    ];
    if (isset($map[$s])) {
        return $map[$s];
    }
    if (in_array($s, TRANSFER_STATUSES, true)) {
        return $s;
    }
    return $s !== '' ? $s : 'Draft';
}

function transfer_allowed_transitions(): array
{
    return [
        'Draft' => ['Pending Approval', 'Cancelled'],
        'Pending Approval' => ['Approved', 'Rejected', 'Cancelled'],
        'Approved' => ['In Transit', 'Cancelled'],
        'In Transit' => ['Completed', 'Cancelled'],
        'Completed' => [],
        'Cancelled' => [],
        'Rejected' => [],
    ];
}

function transfer_can_transition(string $from, string $to): bool
{
    $from = normalize_transfer_status($from);
    $to = normalize_transfer_status($to);
    if ($from === $to) {
        return true;
    }
    $allowed = transfer_allowed_transitions();
    return isset($allowed[$from]) && in_array($to, $allowed[$from], true);
}
