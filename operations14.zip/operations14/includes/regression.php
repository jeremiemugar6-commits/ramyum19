<?php
/**
 * Simple Linear Regression (Ordinary Least Squares) utility used by the
 * AI Inventory Analytics module to predict product demand.
 *
 * Model:  Y = b0 + b1 * X
 *   Y  = predicted quantity (demand)
 *   X  = time period index (0, 1, 2, ... one per historical period)
 *   b0 = intercept
 *   b1 = slope / regression coefficient (trend direction & strength)
 */
class LinearRegression
{
    /**
     * Fits a regression line to the given (x, y) data points.
     *
     * @param float[] $x Time period indices (0, 1, 2, ...)
     * @param float[] $y Historical quantities for each period
     * @return array{b0: float, b1: float, r2: float} Intercept, slope, and
     *         R-squared (goodness of fit, 0-1) used as the accuracy score.
     */
    public static function fit(array $x, array $y): array
    {
        $n = count($x);

        if ($n === 0 || $n !== count($y)) {
            return ['b0' => 0.0, 'b1' => 0.0, 'r2' => 0.0];
        }

        if ($n === 1) {
            // A single data point has no trend to fit; treat it as flat.
            return ['b0' => (float) $y[0], 'b1' => 0.0, 'r2' => 0.0];
        }

        $sumX  = array_sum($x);
        $sumY  = array_sum($y);
        $sumXY = 0.0;
        $sumXX = 0.0;

        for ($i = 0; $i < $n; $i++) {
            $sumXY += $x[$i] * $y[$i];
            $sumXX += $x[$i] * $x[$i];
        }

        $denominator = ($n * $sumXX - $sumX * $sumX);
        $b1 = $denominator != 0 ? ($n * $sumXY - $sumX * $sumY) / $denominator : 0.0;
        $b0 = ($sumY - $b1 * $sumX) / $n;

        // R^2: proportion of variance in Y explained by the fitted line.
        $meanY = $sumY / $n;
        $ssTot = 0.0;
        $ssRes = 0.0;

        for ($i = 0; $i < $n; $i++) {
            $yPred = $b0 + $b1 * $x[$i];
            $ssRes += ($y[$i] - $yPred) ** 2;
            $ssTot += ($y[$i] - $meanY) ** 2;
        }

        $r2 = $ssTot > 0 ? max(0.0, 1 - ($ssRes / $ssTot)) : ($ssRes == 0 ? 1.0 : 0.0);

        return ['b0' => $b0, 'b1' => $b1, 'r2' => $r2];
    }

    /**
     * Predicts Y for a given X using a fitted model's intercept and slope.
     */
    public static function predict(float $b0, float $b1, float $x): float
    {
        return $b0 + $b1 * $x;
    }
}
