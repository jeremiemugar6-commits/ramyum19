<?php
/**
 * Shared helper functions used across the API and pages.
 */

// Force Philippines timezone for all date()/strtotime operations
// (timestamps that must be true UTC should use gmdate() instead)
if (function_exists('date_default_timezone_set')) {
    date_default_timezone_set('Asia/Manila');
}

/**
 * Send a JSON response and terminate the script.
 */
function json_response($data, int $statusCode = 200): void
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Send a JSON error response and terminate the script.
 */
function json_error(string $message, int $statusCode = 400): void
{
    json_response(['success' => false, 'error' => $message], $statusCode);
}

/**
 * Read and decode the raw JSON body of the current request.
 * Checks for cached input first (since php://input can only be read once)
 */
function get_json_input(): array
{
    // Check if input was already cached by the API
    global $cachedInput;
    if ($cachedInput !== null && is_array($cachedInput)) {
        return $cachedInput;
    }
    
    $raw = file_get_contents('php://input');
    if ($raw === false || $raw === '') {
        return [];
    }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

/**
 * Generate a unique record id in the same style the original
 * localStorage-based app used: `{collection}_{timestamp}{random}`.
 */
function generate_id(string $prefix): string
{
    return $prefix . '_' . (string) round(microtime(true) * 1000) . '_' . bin2hex(random_bytes(3));
}

/**
 * Recursively strip HTML-significant characters from strings within
 * an array/object, mirroring the original client-side Sanitizer.
 */
function sanitize_recursive($value)
{
    if (is_string($value)) {
        return str_replace(
            ['&', '<', '>', '"', "'", '/'],
            ['&amp;', '&lt;', '&gt;', '&quot;', '&#x27;', '&#x2F;'],
            $value
        );
    }
    if (is_array($value)) {
        $out = [];
        foreach ($value as $k => $v) {
            $out[$k] = sanitize_recursive($v);
        }
        return $out;
    }
    return $value;
}

/**
 * Masks an email address for display during the OTP step, e.g.
 * "admin@ramyum.com" -> "ad***@ramyum.com".
 */
function mask_email(string $email): string
{
    $parts = explode('@', $email);
    if (count($parts) !== 2) {
        return $email;
    }
    [$local, $domain] = $parts;
    $visible = mb_substr($local, 0, min(2, mb_strlen($local)));
    return $visible . str_repeat('*', max(3, mb_strlen($local) - mb_strlen($visible))) . '@' . $domain;
}

/**
 * Log a security/audit event to the security_logs table.
 */
function log_security_event(string $eventType, ?string $userId = null, ?string $username = null, array $details = []): void
{
    try {
        $db = getDB();
        $stmt = $db->prepare(
            'INSERT INTO security_logs (event_type, user_id, username, details, ip_address) VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $eventType,
            $userId,
            $username,
            json_encode($details),
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (Throwable $e) {
        // Never let logging failures break the request.
    }
}

// =====================================================================
// PROOF OF RECEIVING (POR) - INSPECTION STATUS HELPERS
//
// ONE canonical vocabulary is used everywhere (API, database, UI):
//   header  proof_of_receiving.inspection_status : Pending | In Progress | Passed | Partial | Failed
//   item    proof_of_receiving_items.inspection_result : Pending | Passed | Partial | Failed | Conditional
//
// Older code/data used other words (Pass, Fail, Approved, Rejected,
// Pending Inspection, Completed...). Those are mapped by the helpers below
// so an inspection that PASSED can never silently fall back to "Pending".
// =====================================================================

/**
 * Map any legacy/variant header status to the canonical one.
 * Returns null when the value is blank/unknown/"Completed" (i.e. the real
 * result must be derived from the quantities instead).
 */
function normalize_por_inspection_status($status): ?string
{
    $key = strtolower(trim((string)$status));
    $map = [
        'pending'            => 'Pending',
        'pending inspection' => 'Pending',
        'in progress'        => 'In Progress',
        'passed'             => 'Passed',
        'pass'               => 'Passed',
        'approved'           => 'Passed',
        'partial'            => 'Partial',
        'partially approved' => 'Partial',
        'conditional'        => 'Partial',
        'failed'             => 'Failed',
        'fail'               => 'Failed',
        'rejected'           => 'Failed',
    ];
    return $map[$key] ?? null;
}

/**
 * Derive the header inspection status from the quantities.
 * (Same rules the receiving workflow has always used, plus: goods that were
 * received but none accepted are "Failed", not "Pending".)
 */
function derive_por_inspection_status(float $received, float $accepted, float $rejected): string
{
    if ($received <= 0 && $accepted <= 0 && $rejected <= 0) {
        return 'Pending';          // nothing inspected yet
    }
    if ($rejected > 0) {
        return 'Failed';           // any rejection fails the inspection
    }
    if ($accepted <= 0) {
        return 'Failed';           // received, but nothing usable (all damaged)
    }
    return ($accepted >= $received) ? 'Passed' : 'Partial';
}

/**
 * Canonical item-level result. Blank/unknown values become 'Pending'.
 */
function normalize_por_item_result($result): string
{
    $key = strtolower(trim((string)$result));
    $map = [
        'pending'     => 'Pending',
        'passed'      => 'Passed',
        'pass'        => 'Passed',
        'approved'    => 'Passed',
        'failed'      => 'Failed',
        'fail'        => 'Failed',
        'rejected'    => 'Failed',
        'partial'     => 'Partial',
        'conditional' => 'Conditional',
    ];
    return $map[$key] ?? 'Pending';
}

/**
 * Item result derived from its quantities (used when a stored value is blank).
 */
function derive_por_item_result(array $item): string
{
    $received = (float)($item['received_quantity'] ?? 0);
    $accepted = (float)($item['accepted_quantity'] ?? 0);
    $rejected = (float)($item['rejected_quantity'] ?? 0);
    if ($received <= 0 && $accepted <= 0 && $rejected <= 0) {
        return 'Pending';
    }
    if ($rejected > 0 || $accepted <= 0) {
        return 'Failed';
    }
    return ($accepted >= $received) ? 'Passed' : 'Partial';
}

/**
 * Resolve the status to SHOW/FILTER on for a POR row read from the database.
 * Uses the stored value when it is valid; otherwise (blank, or the legacy
 * "Completed" that older code wrote) it is derived from the totals.
 */
function resolve_por_inspection_status(array $por): string
{
    $stored = normalize_por_inspection_status($por['inspection_status'] ?? '');
    if ($stored !== null) {
        return $stored;
    }
    // A POR still in Draft with no usable status is simply awaiting inspection
    if (($por['status'] ?? '') === 'Draft') {
        return 'Pending';
    }
    return derive_por_inspection_status(
        (float)($por['total_received'] ?? 0),
        (float)($por['total_accepted'] ?? 0),
        (float)($por['total_rejected'] ?? 0)
    );
}

/**
 * Resolve an item's result for display (stored value if valid, else derived).
 */
function resolve_por_item_result(array $item): string
{
    $raw = trim((string)($item['inspection_result'] ?? ''));
    if ($raw !== '') {
        return normalize_por_item_result($raw);
    }
    return derive_por_item_result($item);
}
