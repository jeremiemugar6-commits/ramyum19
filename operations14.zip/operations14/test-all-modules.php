<?php
/**
 * Module Integrity Test
 * Verifies all modules have required files and proper structure
 */

echo "=== RAM-YUM MODULE INTEGRITY TEST ===\n\n";

$modules = [
    'dashboard' => 'dashboard.js',
    'products' => 'catalog.js',
    'inventory' => 'inventory.js',
    'suppliers' => 'suppliers.js',
    'purchase-orders' => 'purchase-orders.js',
    'receiving' => 'receiving.js',
    'por' => 'index.js',
    'stock-transfer' => 'stock-transfer.js',
    'locations' => 'locations.js',
    'reports' => 'reports.js',
    'ai-analytics' => 'ai-analytics.js',
    'settings' => 'settings.js'
];

$passed = [];
$failed = [];

foreach ($modules as $moduleName => $mainFile) {
    $modulePath = "modules/$moduleName/$mainFile";
    
    if (file_exists($modulePath)) {
        $content = file_get_contents($modulePath);
        
        // Check if module has a render function
        $renderFunctionName = match($moduleName) {
            'dashboard' => 'renderDashboard',
            'products' => 'renderProductCatalog',
            'inventory' => 'renderInventory',
            'suppliers' => 'renderSuppliers',
            'purchase-orders' => 'renderPurchaseOrders',
            'receiving' => 'renderReceiving',
            'por' => 'renderPOR',
            'stock-transfer' => 'renderStockTransfer',
            'locations' => 'renderLocations',
            'reports' => 'renderReports',
            'ai-analytics' => 'renderAIAnalytics',
            'settings' => 'renderSettings',
            default => null
        };
        
        if ($renderFunctionName && strpos($content, "export function $renderFunctionName") !== false) {
            $passed[] = "✓ $moduleName ($mainFile) - Has $renderFunctionName()";
        } elseif ($renderFunctionName && strpos($content, "function $renderFunctionName") !== false) {
            $passed[] = "✓ $moduleName ($mainFile) - Has $renderFunctionName() (not exported properly)";
        } else {
            $failed[] = "✗ $moduleName ($mainFile) - Missing $renderFunctionName()";
        }
    } else {
        $failed[] = "✗ $moduleName - File not found: $modulePath";
    }
}

// Check critical utility files
echo "=== CHECKING UTILITY FILES ===\n";
$utilFiles = [
    'assets/js/store.js',
    'assets/js/components/toast.js',
    'assets/js/components/modal.js',
    'assets/js/components/table.js',
    'assets/js/utils/data-service.js',
    'assets/js/utils/format.js',
    'assets/js/utils/validator.js',
    'assets/js/utils/sanitizer.js'
];

foreach ($utilFiles as $utilFile) {
    if (file_exists($utilFile)) {
        $passed[] = "✓ Utility: $utilFile";
    } else {
        $failed[] = "✗ Utility: $utilFile - NOT FOUND";
    }
}

// Check API endpoints
echo "\n=== CHECKING API ENDPOINTS ===\n";
$apiFiles = [
    'api/data.php',
    'api/users.php',
    'api/locations.php',
    'api/stock-transfers.php',
    'api/por.php',
    'api/proof-of-delivery.php',
    'api/reports.php',
    'api/login.php',
    'api/logout.php',
    'api/profile.php'
];

foreach ($apiFiles as $apiFile) {
    if (file_exists($apiFile)) {
        $passed[] = "✓ API: $apiFile";
    } else {
        $failed[] = "✗ API: $apiFile - NOT FOUND";
    }
}

// Output results
echo "\n=== PASSED (" . count($passed) . ") ===\n";
foreach ($passed as $p) {
    echo "$p\n";
}

if (!empty($failed)) {
    echo "\n=== FAILED (" . count($failed) . ") ===\n";
    foreach ($failed as $f) {
        echo "$f\n";
    }
    echo "\n❌ Some checks failed!\n";
} else {
    echo "\n✅ All module integrity checks passed!\n";
}

// Check dashboard.php routing configuration
echo "\n=== CHECKING DASHBOARD ROUTING ===\n";
$dashboardContent = file_get_contents('dashboard.php');

$expectedRoutes = [
    'dashboard', 'products', 'inventory', 'suppliers', 
    'purchase-orders', 'receiving', 'por', 'stock-transfer',
    'locations', 'reports', 'ai-analytics', 'settings'
];

$routingPassed = true;
foreach ($expectedRoutes as $route) {
    if (strpos($dashboardContent, "'$route'") === false && strpos($dashboardContent, "\"$route\"") === false) {
        echo "✗ Route '$route' not found in dashboard.php\n";
        $routingPassed = false;
    }
}

if ($routingPassed) {
    echo "✓ All routes properly configured in dashboard.php\n";
}

echo "\n=== MODULE TEST COMPLETE ===\n";
