<?php
/**
 * Execute Supplier Consistency Migration
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "SUPPLIER CONSISTENCY MIGRATION\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

try {
    // Step 1: Create backup
    echo "Step 1: Creating backup of proof_of_receiving table...\n";
    $db->exec("DROP TABLE IF EXISTS por_backup_20261003");
    $db->exec("CREATE TABLE por_backup_20261003 AS SELECT * FROM proof_of_receiving");
    
    $backupCount = $db->query("SELECT COUNT(*) as cnt FROM por_backup_20261003")->fetch()['cnt'];
    echo "✓ Backup created: $backupCount records\n\n";
    
    // Step 2: Check current mismatches
    echo "Step 2: Checking for supplier mismatches...\n";
    $mismatchQuery = "
        SELECT 
            por.id,
            por.por_number,
            por.supplier_id as current_supplier,
            JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId')) as correct_supplier,
            JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplier')) as supplier_name
        FROM proof_of_receiving por
        INNER JOIN purchase_orders po ON por.purchase_order_id = po.id
        WHERE por.supplier_id != JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId'))
    ";
    
    $stmt = $db->query($mismatchQuery);
    $mismatches = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Found " . count($mismatches) . " records with supplier mismatches:\n";
    foreach ($mismatches as $m) {
        echo "  - {$m['por_number']}: {$m['current_supplier']} → {$m['correct_supplier']} ({$m['supplier_name']})\n";
    }
    echo "\n";
    
    // Step 3: Fix supplier mismatches
    echo "Step 3: Fixing supplier mismatches...\n";
    $updateQuery = "
        UPDATE proof_of_receiving por
        INNER JOIN purchase_orders po ON por.purchase_order_id = po.id
        SET 
            por.supplier_id = JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId')),
            por.supplier_name = JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplier')),
            por.updated_at = NOW()
        WHERE por.supplier_id != JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId'))
    ";
    
    $stmt = $db->prepare($updateQuery);
    $stmt->execute();
    $updated = $stmt->rowCount();
    
    echo "✓ Updated $updated POR records\n\n";
    
    // Step 4: Verify fixes
    echo "Step 4: Verifying fixes...\n";
    $verifyQuery = "
        SELECT COUNT(*) as cnt
        FROM proof_of_receiving por
        INNER JOIN purchase_orders po ON por.purchase_order_id = po.id
        WHERE por.supplier_id != JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId'))
    ";
    
    $remaining = $db->query($verifyQuery)->fetch()['cnt'];
    
    if ($remaining == 0) {
        echo "✓ All supplier mismatches resolved!\n";
    } else {
        echo "⚠ Warning: $remaining mismatches still remain\n";
    }
    echo "\n";
    
    // Step 5: Check for invalid supplier IDs
    echo "Step 5: Checking for invalid supplier references...\n";
    $invalidQuery = "
        SELECT COUNT(*) as cnt
        FROM proof_of_receiving por
        LEFT JOIN suppliers s ON por.supplier_id = s.id
        WHERE s.id IS NULL
    ";
    
    $invalid = $db->query($invalidQuery)->fetch()['cnt'];
    
    if ($invalid == 0) {
        echo "✓ All POR records reference valid suppliers\n";
    } else {
        echo "⚠ Warning: $invalid POR records have invalid supplier IDs\n";
    }
    echo "\n";
    
    // Step 6: Try to add foreign key constraint
    echo "Step 6: Adding foreign key constraint...\n";
    try {
        $db->exec("
            ALTER TABLE proof_of_receiving
            ADD CONSTRAINT fk_por_supplier
            FOREIGN KEY (supplier_id) 
            REFERENCES suppliers(id)
            ON DELETE RESTRICT
            ON UPDATE CASCADE
        ");
        echo "✓ Foreign key constraint added\n";
    } catch (Exception $e) {
        if (strpos($e->getMessage(), 'Duplicate key') !== false || 
            strpos($e->getMessage(), 'already exists') !== false) {
            echo "⚠ Foreign key already exists (skipped)\n";
        } else {
            echo "✗ Could not add foreign key: " . $e->getMessage() . "\n";
        }
    }
    echo "\n";
    
    // Step 7: Create validation view
    echo "Step 7: Creating validation view...\n";
    $db->exec("DROP VIEW IF EXISTS v_por_supplier_validation");
    $db->exec("
        CREATE VIEW v_por_supplier_validation AS
        SELECT 
            por.id as por_id,
            por.por_number,
            por.purchase_order_id,
            por.supplier_id as por_supplier_id,
            por.supplier_name as por_supplier_name,
            JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId')) as po_supplier_id,
            JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplier')) as po_supplier_name,
            s.id as supplier_master_id,
            JSON_UNQUOTE(JSON_EXTRACT(s.data, '$.company')) as supplier_master_name,
            CASE 
                WHEN por.supplier_id = JSON_UNQUOTE(JSON_EXTRACT(po.data, '$.supplierId')) 
                THEN 'VALID'
                ELSE 'MISMATCH'
            END as validation_status
        FROM proof_of_receiving por
        INNER JOIN purchase_orders po ON por.purchase_order_id = po.id
        LEFT JOIN suppliers s ON por.supplier_id = s.id
    ");
    echo "✓ Validation view created\n\n";
    
    // Step 8: Final report
    echo "Step 8: Final validation report...\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $report = $db->query("
        SELECT 
            validation_status,
            COUNT(*) as count
        FROM v_por_supplier_validation
        GROUP BY validation_status
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($report as $row) {
        echo sprintf("%-20s: %d records\n", $row['validation_status'], $row['count']);
    }
    
    echo "\n";
    
    // Show supplier distribution
    $suppliers = $db->query("
        SELECT 
            supplier_id,
            supplier_name,
            COUNT(*) as por_count
        FROM proof_of_receiving
        GROUP BY supplier_id, supplier_name
        ORDER BY por_count DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    echo "POR records by supplier:\n";
    foreach ($suppliers as $s) {
        echo "  - {$s['supplier_id']} ({$s['supplier_name']}): {$s['por_count']} PORs\n";
    }
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "MIGRATION COMPLETE ✓\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
?>
