<?php
/**
 * Test the receive_and_inspect_items endpoint
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "=== Testing Receive & Inspect Endpoint ===\n\n";

// Simulate the request
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['REMOTE_ADDR'] = '127.0.0.1';

// Set up session for authentication (simulate logged-in user)
session_start();
$_SESSION['user_id'] = 'test_user';
$_SESSION['role'] = 'admin';

// Mock JSON input
$testInput = [
    'action' => 'receive_and_inspect_items',
    'purchase_order_id' => 'test_po_id',
    'items' => [
        [
            'product_id' => 'DRK001',
            'product_name' => 'Welchs Grape',
            'sku' => 'DRK001',
            'ordered_quantity' => 1,
            'received_quantity' => 1,
            'accepted_quantity' => 1,
            'rejected_quantity' => 0,
            'damaged_quantity' => 0,
            'unit_cost' => 45.00,
            'inspection_result' => 'Passed'
        ]
    ],
    'inspection_notes' => 'Test receiving',
    'received_by' => 'Test User'
];

// Override the global cached input
$GLOBALS['cachedInput'] = $testInput;

echo "Request data:\n";
echo json_encode($testInput, JSON_PRETTY_PRINT) . "\n\n";

echo "Calling workflow-processor.php...\n\n";

// Capture output
ob_start();

try {
    // Include the processor
    include 'api/workflow-processor.php';
} catch (Exception $e) {
    echo "EXCEPTION CAUGHT: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}

$output = ob_get_clean();

echo "=== Response ===\n";
echo $output . "\n";

// Try to decode as JSON
echo "\n=== JSON Parse Test ===\n";
$decoded = json_decode($output);
if (json_last_error() === JSON_ERROR_NONE) {
    echo "✓ Valid JSON response\n";
    print_r($decoded);
} else {
    echo "✗ Invalid JSON: " . json_last_error_msg() . "\n";
    echo "First 500 chars of response:\n";
    echo substr($output, 0, 500) . "\n";
}
