/**
 * Proof of Receiving (POR) Module - Complete Implementation
 */

import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

// Module state
let porState = {
    list: [],
    filters: {
        status: '',
        search: ''
    }
};

let porTable = null;

// Main render function
export async function renderPOR() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canCreate = userRole === 'admin' || userRole === 'manager' || userRole === 'staff';
    
    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">📋 Proof of Receiving (POR)</h1>
                <p class="page-subtitle">View inspection results and quality check records (auto-created during receiving).</p>
                <p id="lastUpdateTime" style="font-size:0.75rem; color:var(--text-muted); margin-top:4px;">Last updated: Loading...</p>
            </div>
            <div style="display:flex; gap:12px; align-items:center;">
                <button id="refreshPORBtn" style="padding:10px 16px; background:var(--primary-orange); color:white; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px; transition:all 0.2s; box-shadow:var(--shadow-sm);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
                    </svg>
                    Refresh
                </button>
                <div style="background:#F0F9FF; padding:8px 16px; border-radius:6px; border:1px solid #3B82F6;">
                    <span style="color:#1E40AF; font-size:0.9rem; font-weight:500;">ℹ️ Auto-updates when receiving completes</span>
                </div>
            </div>
        </div>

        <!-- Status Badges (Simplified) -->
        <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:16px; margin-bottom:20px;">
            <!-- Pending -->
            <div class="status-tab" data-status="Pending Inspection" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:8px; padding:16px; text-align:center; cursor:pointer; transition:all 0.2s;">
                <div style="color:#F59E0B; font-size:0.9rem; font-weight:600; margin-bottom:8px;">⏳ Pending</div>
                <div class="tab-count" style="color:#F59E0B; font-size:2rem; font-weight:700;">0</div>
            </div>
            
            <!-- Passed -->
            <div class="status-tab" data-status="Passed" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:8px; padding:16px; text-align:center; cursor:pointer; transition:all 0.2s;">
                <div style="color:#10B981; font-size:0.9rem; font-weight:600; margin-bottom:8px;">✓ Passed</div>
                <div class="tab-count" style="color:#10B981; font-size:2rem; font-weight:700;">0</div>
            </div>
            
            <!-- Failed -->
            <div class="status-tab" data-status="Failed" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:8px; padding:16px; text-align:center; cursor:pointer; transition:all 0.2s;">
                <div style="color:#EF4444; font-size:0.9rem; font-weight:600; margin-bottom:8px;">✕ Failed</div>
                <div class="tab-count" style="color:#EF4444; font-size:2rem; font-weight:700;">0</div>
            </div>
            
            <!-- Damaged/Partial -->
            <div class="status-tab" data-status="Partial" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:8px; padding:16px; text-align:center; cursor:pointer; transition:all 0.2s;">
                <div style="color:#F97316; font-size:0.9rem; font-weight:600; margin-bottom:8px;">⚠️ Partial</div>
                <div class="tab-count" style="color:#F97316; font-size:2rem; font-weight:700;">0</div>
            </div>
        </div>

        <!-- All Records Tab -->
        <div class="status-tab active" data-status="" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:8px; padding:12px 20px; margin-bottom:16px; cursor:pointer; display:flex; justify-content:space-between; align-items:center;">
            <span style="font-weight:600; color:var(--text-primary);">📋 All Records</span>
            <span class="tab-count" style="background:var(--primary-orange); color:white; padding:4px 12px; border-radius:20px; font-weight:700;">0</span>
        </div>

        <!-- Search Filter -->
        <div style="margin-bottom:20px;">
            <input type="text" id="porSearch" placeholder="🔍 Search by POR #, PO #, Supplier..." style="width:100%; padding:12px 16px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-white); color:var(--text-primary); font-size:0.95rem;">
        </div>

        <style>
            .status-tab {
                transition: all 0.2s;
            }
            .status-tab:hover {
                transform: translateY(-2px);
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            }
            .status-tab.active {
                border-color: var(--primary-orange);
                box-shadow: 0 0 0 2px rgba(255, 122, 0, 0.2);
            }
        </style>

        <!-- Table Container -->
        <div id="porTableContainer"></div>
    `;

    // Load data and attach events
    await loadPORList();
    attachEventListeners();
    
    // Start auto-refresh polling (every 30 seconds)
    startAutoRefresh();
}

// Attach global event listeners for cross-module communication
// These stay active even when navigating away from POR page
function attachGlobalEventListeners() {
    console.log('🎯 [POR Module] Setting up global event listeners...');
    
    // Remove existing listeners first to avoid duplicates
    window.removeEventListener('porCreated', handlePORCreated);
    window.removeEventListener('porUpdated', handlePORUpdated);
    
    // Add fresh listeners
    window.addEventListener('porCreated', handlePORCreated);
    window.addEventListener('porUpdated', handlePORUpdated);
    
    console.log('✅ [POR Module] Global event listeners registered');
}

// Initialize global listeners immediately when module loads
console.log('📦 [POR Module] Module loaded - initializing...');
attachGlobalEventListeners();

// Attach event listeners
function attachEventListeners() {
    const createBtn = document.getElementById('createPORBtn');
    const refreshBtn = document.getElementById('refreshPORBtn');
    const searchInput = document.getElementById('porSearch');
    const tabs = document.querySelectorAll('.status-tab');

    if (createBtn) {
        createBtn.addEventListener('click', showCreatePORModal);
    }

    if (refreshBtn) {
        refreshBtn.addEventListener('click', async () => {
            console.log('🔄 [POR Module] Manual refresh button clicked');
            
            // Disable button and show loading state
            refreshBtn.disabled = true;
            refreshBtn.style.opacity = '0.6';
            const originalHTML = refreshBtn.innerHTML;
            refreshBtn.innerHTML = `
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation: spin 1s linear infinite;">
                    <path d="M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
                </svg>
                Refreshing...
            `;
            
            // Add spin animation
            if (!document.getElementById('spinKeyframes')) {
                const style = document.createElement('style');
                style.id = 'spinKeyframes';
                style.textContent = '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
                document.head.appendChild(style);
            }
            
            // Reload data
            await loadPORList();
            
            // Show success toast
            toast.show('✅ POR records refreshed', 'success');
            
            // Restore button
            setTimeout(() => {
                refreshBtn.disabled = false;
                refreshBtn.style.opacity = '1';
                refreshBtn.innerHTML = originalHTML;
            }, 1000);
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', filterPORData);
    }

    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            filterPORData();
        });
    });
}

// Load POR list from API
async function loadPORList() {
    console.log('🔄 [POR Module] Loading POR list from API...');
    
    try {
        const response = await fetch('api/por.php?action=list');
        const data = await response.json();

        if (data.success) {
            // Filter out archived POR records by default
            porState.list = (data.data || []).filter(por => por.status !== 'Archived');
            console.log(`✅ [POR Module] Loaded ${porState.list.length} POR records (archived filtered out)`);
            await updateSummaryStats();
            renderPORTable();
            updateLastRefreshTime();
        } else {
            throw new Error(data.error || 'Failed to load POR records');
        }
    } catch (error) {
        console.error('❌ [POR Module] Load error:', error);
        toast.show('Failed to load POR records: ' + error.message, 'error');
        // Show empty table
        porState.list = [];
        renderPORTable();
    }
}

// Update last refresh timestamp
function updateLastRefreshTime() {
    const timeElement = document.getElementById('lastUpdateTime');
    if (timeElement) {
        const now = new Date();
        const timeString = now.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            second: '2-digit',
            hour12: true 
        });
        timeElement.textContent = `Last updated: ${timeString}`;
        timeElement.style.color = '#10B981'; // Green to show fresh data
        
        // Fade back to gray after 3 seconds
        setTimeout(() => {
            timeElement.style.color = 'var(--text-muted)';
        }, 3000);
    }
}

// Update tab counts with real-time data from database
async function updateSummaryStats() {
    console.log('📊 [POR Module] Updating badge counts...');
    
    try {
        // Fetch real counts from database API
        const response = await fetch('api/por.php?action=stats');
        const result = await response.json();
        
        console.log('📊 [POR Module] Badge counts response:', result);
        
        if (result.success && result.data) {
            const counts = result.data;
            console.log('📊 [POR Module] Badge counts:', counts);
            
            const tabs = document.querySelectorAll('.status-tab');
            tabs.forEach(tab => {
                const status = tab.getAttribute('data-status');
                const countSpan = tab.querySelector('.tab-count');
                if (countSpan) {
                    let newCount = 0;
                    if (status === '') {
                        newCount = counts.all || 0;
                    } else if (status === 'Pending Inspection') {
                        newCount = counts.pending || 0;
                    } else if (status === 'Passed') {
                        newCount = counts.passed || 0;
                    } else if (status === 'Failed') {
                        newCount = counts.failed || 0;
                    } else if (status === 'Partial') {
                        newCount = counts.damaged || 0;
                    }
                    
                    // Update count with animation
                    if (countSpan.textContent !== String(newCount)) {
                        countSpan.style.transition = 'all 0.3s ease';
                        countSpan.style.transform = 'scale(1.3)';
                        countSpan.style.color = '#10B981'; // Green flash
                        countSpan.textContent = newCount;
                        
                        setTimeout(() => {
                            countSpan.style.transform = 'scale(1)';
                            countSpan.style.color = ''; // Reset to default
                        }, 300);
                    } else {
                        countSpan.textContent = newCount;
                    }
                }
            });
            
            console.log('✅ [POR Module] Badge counts updated successfully');
        } else {
            console.warn('⚠️ [POR Module] API response not successful, using fallback');
            // Fallback to local calculation
            calculateLocalCounts();
        }
    } catch (error) {
        console.error('❌ [POR Module] Error updating badge counts:', error);
        // Fallback to local calculation on error
        calculateLocalCounts();
    }
}

// Fallback: Calculate counts from loaded list
function calculateLocalCounts() {
    const counts = {
        all: porState.list.length,
        pending: porState.list.filter(p => resolveInspectionStatus(p) === 'Pending').length,
        passed: porState.list.filter(p => resolveInspectionStatus(p) === 'Passed').length,
        failed: porState.list.filter(p => resolveInspectionStatus(p) === 'Failed').length,
        damaged: porState.list.filter(p => resolveInspectionStatus(p) === 'Partial').length
    };
    
    const tabs = document.querySelectorAll('.status-tab');
    tabs.forEach(tab => {
        const status = tab.getAttribute('data-status');
        const countSpan = tab.querySelector('.tab-count');
        if (countSpan) {
            if (status === '') {
                countSpan.textContent = counts.all;
            } else if (status === 'Pending Inspection') {
                countSpan.textContent = counts.pending;
            } else if (status === 'Passed') {
                countSpan.textContent = counts.passed;
            } else if (status === 'Failed') {
                countSpan.textContent = counts.failed;
            } else if (status === 'Partial') {
                countSpan.textContent = counts.damaged;
            }
        }
    });
}

// Canonical inspection status for a POR row. The API already resolves this, but
// if a blank/legacy value ever slips through, derive it from the totals instead of
// showing a misleading "Pending" for an inspection that already passed.
function resolveInspectionStatus(por) {
    const map = {
        'pending': 'Pending', 'pending inspection': 'Pending', 'in progress': 'Pending',
        'passed': 'Passed', 'pass': 'Passed', 'approved': 'Passed',
        'partial': 'Partial', 'partially approved': 'Partial', 'conditional': 'Partial',
        'failed': 'Failed', 'fail': 'Failed', 'rejected': 'Failed'
    };
    const stored = map[String(por.inspection_status || '').trim().toLowerCase()];
    if (stored) return stored;
    if (por.status === 'Draft') return 'Pending';
    const received = parseFloat(por.total_received) || 0;
    const accepted = parseFloat(por.total_accepted) || 0;
    const rejected = parseFloat(por.total_rejected) || 0;
    if (received <= 0 && accepted <= 0 && rejected <= 0) return 'Pending';
    if (rejected > 0 || accepted <= 0) return 'Failed';
    return accepted >= received ? 'Passed' : 'Partial';
}

// Get status badge
function getInspectionStatusBadge(status) {
    const badges = {
        'Pending Inspection': { bg: '#FEF3C7', color: '#92400E', label: '⏳ Pending' },
        'Pending': { bg: '#FEF3C7', color: '#92400E', label: '⏳ Pending' },
        'Passed': { bg: '#D1FAE5', color: '#065F46', label: '✓ Passed' },
        'Approved': { bg: '#D1FAE5', color: '#065F46', label: '✓ Passed' },
        'Failed': { bg: '#FEE2E2', color: '#991B1B', label: '✕ Failed' },
        'Rejected': { bg: '#FEE2E2', color: '#991B1B', label: '✕ Failed' },
        'Partial': { bg: '#FFEDD5', color: '#9A3412', label: '⚠️ Partial' },
        'Partially Approved': { bg: '#FFEDD5', color: '#9A3412', label: '⚠️ Partial' }
    };
    
    const badge = badges[status] || { bg: '#F3F4F6', color: '#6B7280', label: status || 'Unknown' };
    
    return `<span style="padding:4px 12px; border-radius:999px; font-size:0.75rem; 
            font-weight:600; background:${badge.bg}; color:${badge.color};">
                ${badge.label}
            </span>`;
}

// Filter POR data
function filterPORData() {
    const searchTerm = document.getElementById('porSearch')?.value.toLowerCase() || '';
    const activeTab = document.querySelector('.status-tab.active');
    const statusFilter = activeTab ? activeTab.getAttribute('data-status') : '';

    const filtered = porState.list.filter(por => {
        const matchesSearch = 
            (por.por_number || '').toLowerCase().includes(searchTerm) || 
            (por.po_number || '').toLowerCase().includes(searchTerm) ||
            (por.supplier_name || '').toLowerCase().includes(searchTerm);
        
        let matchesStatus = true;
        if (statusFilter) {
            const resolved = resolveInspectionStatus(por);
            if (statusFilter === 'Pending Inspection') {
                matchesStatus = resolved === 'Pending';
            } else {
                matchesStatus = resolved === resolveInspectionStatus({ inspection_status: statusFilter });
            }
        }
        
        return matchesSearch && matchesStatus;
    });

    renderPORTable(filtered);
}

// Render POR table
function renderPORTable(filteredData = null) {
    const dataToRender = filteredData || porState.list;
    const container = document.getElementById('porTableContainer');
    const userRole = store.getState().role;

    const columns = [
        { key: 'por_number', label: 'POR #' },
        { key: 'po_number', label: 'PO #' },
        { key: 'supplier_name', label: 'Supplier' },
        { key: 'received_date', label: 'Received Date' },
        { key: 'received_by_name', label: 'Received By' },
        { key: 'inspection_status', label: 'Status' }
    ];

    const formattedData = dataToRender.map(por => ({
        ...por,
        received_date: por.receiving_date ? new Date(por.receiving_date).toLocaleDateString() : 'N/A',
        inspection_status: getInspectionStatusBadge(resolveInspectionStatus(por)),
        rawStatus: resolveInspectionStatus(por)
    }));

    const actionsConfig = {
        actions: true,
        // Always show Details button so user can view products/items that were received
        onView: (rowData) => viewPORDetails(rowData),
        viewLabel: 'Details'
    };

    // Only show Edit for records that are still editable (Pending)
    const hasEditable = dataToRender.some(p => {
        const st = resolveInspectionStatus(p);
        return st === 'Pending' && p.status !== 'Completed';
    });
    if (hasEditable) {
        actionsConfig.onEdit = (rowData) => {
            if (rowData.rawStatus === 'Pending' && rowData.status !== 'Completed') {
                editPOR(rowData);
            } else {
                toast.show('Can only edit pending inspections.', 'warning');
            }
        };
        actionsConfig.editLabel = 'Edit';
    }

    // Only admins can archive, and only pending records
    if (userRole === 'admin') {
        actionsConfig.onDelete = (rowData) => {
            if (rowData.rawStatus === 'Pending' && rowData.status !== 'Completed') {
                confirmArchivePOR(rowData);
            } else {
                toast.show('Cannot archive completed POR records.', 'warning');
            }
        };
        actionsConfig.deleteLabel = 'Archive';
    }

    if (!porTable) {
        porTable = new DataTable('porTableContainer', columns, formattedData, actionsConfig);
    } else {
        porTable.updateData(formattedData);
    }
}

// View POR details
async function viewPORDetails(por) {
    try {
        const response = await fetch(`api/por.php?action=get&id=${por.id}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Failed to load POR details');
        }
        
        const porDetails = data.data;
        
        const detailsHTML = `
            <div style="max-height:70vh; overflow-y:auto;">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px;">
                    <div>
                        <h4 style="margin:0 0 12px 0; color:var(--text-primary);">POR Information</h4>
                        <table style="width:100%; font-size:0.9rem;">
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">POR Number:</td><td style="padding:6px 0;"><strong>${porDetails.por_number}</strong></td></tr>
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">PO Number:</td><td style="padding:6px 0;">${porDetails.po_number}</td></tr>
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">Supplier:</td><td style="padding:6px 0;">${porDetails.supplier_name}</td></tr>
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">Status:</td><td style="padding:6px 0;">${getInspectionStatusBadge(porDetails.inspection_status)}</td></tr>
                        </table>
                    </div>
                    <div>
                        <h4 style="margin:0 0 12px 0; color:var(--text-primary);">Receiving Details</h4>
                        <table style="width:100%; font-size:0.9rem;">
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">Received Date:</td><td style="padding:6px 0;">${porDetails.receiving_date ? new Date(porDetails.receiving_date).toLocaleDateString() : 'N/A'}</td></tr>
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">Received By:</td><td style="padding:6px 0;">${porDetails.received_by_name || 'N/A'}</td></tr>
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">Total Items:</td><td style="padding:6px 0;">${porDetails.total_items || 0}</td></tr>
                            <tr><td style="padding:6px 0; color:var(--text-secondary); font-weight:600;">Total Value:</td><td style="padding:6px 0;">₱${parseFloat(porDetails.total_value || 0).toLocaleString('en-PH', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td></tr>
                        </table>
                    </div>
                </div>
                
                ${porDetails.remarks ? `
                    <div style="margin-bottom:20px;">
                        <h4 style="margin:0 0 8px 0; color:var(--text-primary);">Remarks</h4>
                        <p style="background:var(--bg-gray); padding:12px; border-radius:6px; margin:0;">${porDetails.remarks}</p>
                    </div>
                ` : ''}
                
                <div>
                    <h4 style="margin:0 0 12px 0; color:var(--text-primary);">Items</h4>
                    <div style="overflow-x:auto;">
                        <table style="width:100%; border-collapse:collapse; font-size:0.85rem;">
                            <thead>
                                <tr style="background:var(--bg-gray);">
                                    <th style="padding:10px; text-align:left; border:1px solid var(--border-color);">Product</th>
                                    <th style="padding:10px; text-align:center; border:1px solid var(--border-color);">Ordered</th>
                                    <th style="padding:10px; text-align:center; border:1px solid var(--border-color);">Received</th>
                                    <th style="padding:10px; text-align:center; border:1px solid var(--border-color);">Accepted</th>
                                    <th style="padding:10px; text-align:center; border:1px solid var(--border-color);">Rejected</th>
                                    <th style="padding:10px; text-align:left; border:1px solid var(--border-color);">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${porDetails.items ? porDetails.items.map(item => `
                                    <tr>
                                        <td style="padding:10px; border:1px solid var(--border-color);">${item.product_name}</td>
                                        <td style="padding:10px; text-align:center; border:1px solid var(--border-color);">${item.ordered_quantity || 0}</td>
                                        <td style="padding:10px; text-align:center; border:1px solid var(--border-color);">${item.received_quantity || 0}</td>
                                        <td style="padding:10px; text-align:center; border:1px solid var(--border-color); color:#10B981; font-weight:600;">${item.accepted_quantity || 0}</td>
                                        <td style="padding:10px; text-align:center; border:1px solid var(--border-color); color:#EF4444; font-weight:600;">${item.rejected_quantity || 0}</td>
                                        <td style="padding:10px; border:1px solid var(--border-color);">${item.inspection_result || 'Pending'}</td>
                                    </tr>
                                `).join('') : '<tr><td colspan="6" style="padding:20px; text-align:center; color:var(--text-secondary);">No items found</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
        
        modal.open(`POR Details - ${porDetails.por_number}`, detailsHTML, {
            confirmText: 'Close',
            cancelText: 'Save as Receipt',
            width: '1100px',
            onCancel: () => {
                savePORReceipt(porDetails);
            },
            onConfirm: () => modal.close()
        });
        
    } catch (error) {
        toast.show('Failed to load POR details: ' + error.message, 'error');
        console.error(error);
    }
}

// Show create POR modal
async function showCreatePORModal() {
    try {
        const response = await fetch('api/por.php?action=available_receivings');
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Failed to load receivings');
        }
        
        const receivings = data.data || [];
        
        if (receivings.length === 0) {
            toast.show('No approved receivings available for POR creation.', 'info');
            return;
        }
        
        const formHTML = `
            <form id="createPORForm" style="display:grid; gap:16px;">
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Select Receiving *</label>
                    <select id="por_receiving" class="form-input" required style="width:100%;">
                        <option value="">-- Select a receiving record --</option>
                        ${receivings.map(r => `
                            <option value="${r.id}">
                                ${r.receiving_number} - ${r.po_number} - ${r.supplier} (${new Date(r.received_date).toLocaleDateString()})
                            </option>
                        `).join('')}
                    </select>
                </div>
                
                <div>
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Inspection Notes (Optional)</label>
                    <textarea id="por_remarks" class="form-input" rows="3" placeholder="Any notes about the inspection..."></textarea>
                </div>
            </form>
        `;
        
        modal.open('Create Proof of Receiving', formHTML, {
            confirmText: 'Create POR',
            onConfirm: async () => {
                const receivingId = document.getElementById('por_receiving').value;
                const remarks = document.getElementById('por_remarks').value.trim();
                
                if (!receivingId) {
                    toast.show('Please select a receiving record.', 'error');
                    return;
                }
                
                try {
                    const createResponse = await fetch('api/por.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            action: 'create-from-receiving',
                            receiving_id: receivingId,
                            remarks: remarks
                        })
                    });
                    
                    const result = await createResponse.json();
                    
                    if (!result.success) {
                        throw new Error(result.error || 'Failed to create POR');
                    }
                    
                    toast.show('POR created successfully!', 'success');
                    modal.close();
                    await loadPORList();
                    
                } catch (error) {
                    toast.show('Failed to create POR: ' + error.message, 'error');
                    console.error(error);
                }
            }
        });
        
    } catch (error) {
        toast.show('Failed to load receivings: ' + error.message, 'error');
        console.error(error);
    }
}

// Edit POR (Inspection)
async function editPOR(por) {
    try {
        // Fetch full POR details with items
        const response = await fetch(`api/por.php?action=get&id=${por.id}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.error || 'Failed to load POR details');
        }
        
        const porDetails = data.data;
        const items = porDetails.items || [];
        
        // Create form HTML for inspection
        const formHTML = `
            <form id="editPORForm" style="display:grid; gap:16px; max-height:60vh; overflow-y:auto;">
                <div>
                    <h4 style="margin:0 0 12px 0;">POR: ${porDetails.por_number}</h4>
                    <p style="color:var(--text-secondary); font-size:0.9rem;">Update inspection results for each item</p>
                </div>
                
                ${items.map((item, index) => `
                    <div style="background:var(--bg-gray); padding:16px; border-radius:8px;">
                        <h5 style="margin:0 0 12px 0;">${item.product_name}</h5>
                        
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
                            <div>
                                <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Ordered</label>
                                <input type="number" value="${item.ordered_quantity}" disabled style="width:100%; padding:8px; border:1px solid var(--border-color); border-radius:4px; background:#f9f9f9;">
                            </div>
                            <div>
                                <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Received</label>
                                <input type="number" value="${item.received_quantity}" disabled style="width:100%; padding:8px; border:1px solid var(--border-color); border-radius:4px; background:#f9f9f9;">
                            </div>
                        </div>
                        
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:12px;">
                            <div>
                                <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Accepted Qty *</label>
                                <input type="number" id="accepted_${index}" value="${item.accepted_quantity}" min="0" max="${item.received_quantity}" class="form-input" required style="width:100%;">
                            </div>
                            <div>
                                <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Rejected Qty *</label>
                                <input type="number" id="rejected_${index}" value="${item.rejected_quantity}" min="0" max="${item.received_quantity}" class="form-input" required style="width:100%;">
                            </div>
                        </div>
                        
                        <div style="margin-bottom:12px;">
                            <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Inspection Result *</label>
                            <select id="result_${index}" class="form-input" required style="width:100%;">
                                <option value="Pending" ${item.inspection_result === 'Pending' ? 'selected' : ''}>Pending</option>
                                <option value="Passed" ${item.inspection_result === 'Passed' ? 'selected' : ''}>Passed</option>
                                <option value="Failed" ${item.inspection_result === 'Failed' ? 'selected' : ''}>Failed</option>
                                <option value="Partial" ${item.inspection_result === 'Partial' ? 'selected' : ''}>Partial</option>
                            </select>
                        </div>
                        
                        <div>
                            <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Inspection Notes</label>
                            <textarea id="notes_${index}" class="form-input" rows="2" placeholder="Optional notes...">${item.inspection_notes || ''}</textarea>
                        </div>
                        
                        <input type="hidden" id="itemId_${index}" value="${item.id}">
                    </div>
                `).join('')}
                
                <div>
                    <label style="display:block; font-size:0.85rem; color:var(--text-secondary); margin-bottom:4px;">Overall Status *</label>
                    <select id="overallStatus" class="form-input" required style="width:100%;">
                        <option value="Pending" ${resolveInspectionStatus(porDetails) === 'Pending' ? 'selected' : ''}>Pending Inspection</option>
                        <option value="Passed" ${resolveInspectionStatus(porDetails) === 'Passed' ? 'selected' : ''}>Passed</option>
                        <option value="Failed" ${resolveInspectionStatus(porDetails) === 'Failed' ? 'selected' : ''}>Failed</option>
                        <option value="Partial" ${resolveInspectionStatus(porDetails) === 'Partial' ? 'selected' : ''}>Partial</option>
                    </select>
                </div>
            </form>
        `;
        
        modal.open(`Edit POR - ${porDetails.por_number}`, formHTML, {
            confirmText: 'Save Changes',
            onConfirm: async () => {
                try {
                    // Collect updated item data
                    const updatedItems = items.map((item, index) => {
                        const acceptedQty = parseFloat(document.getElementById(`accepted_${index}`).value);
                        const rejectedQty = parseFloat(document.getElementById(`rejected_${index}`).value);
                        const receivedQty = parseFloat(item.received_quantity);
                        
                        // Validate that accepted + rejected = received
                        if (acceptedQty + rejectedQty !== receivedQty) {
                            throw new Error(`${item.product_name}: Accepted (${acceptedQty}) + Rejected (${rejectedQty}) must equal Received (${receivedQty})`);
                        }
                        
                        return {
                            id: document.getElementById(`itemId_${index}`).value,
                            accepted_quantity: acceptedQty,
                            rejected_quantity: rejectedQty,
                            inspection_result: document.getElementById(`result_${index}`).value,
                            inspection_notes: document.getElementById(`notes_${index}`).value
                        };
                    });
                    
                    const overallStatus = document.getElementById('overallStatus').value;
                    
                    // Update POR via API
                    const updateResponse = await fetch('api/por.php', {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            action: 'update',
                            por_id: por.id,
                            inspection_status: overallStatus,
                            items: updatedItems
                        })
                    });
                    
                    const result = await updateResponse.json();
                    
                    if (!result.success) {
                        throw new Error(result.error || 'Failed to update POR');
                    }
                    
                    toast.show('POR updated successfully!', 'success');
                    modal.close();
                    await loadPORList();
                    
                } catch (error) {
                    toast.show(error.message, 'error');
                    console.error(error);
                }
            }
        });
        
        // Add validation listeners
        items.forEach((item, index) => {
            const acceptedInput = document.getElementById(`accepted_${index}`);
            const rejectedInput = document.getElementById(`rejected_${index}`);
            
            const validate = () => {
                const accepted = parseFloat(acceptedInput.value) || 0;
                const rejected = parseFloat(rejectedInput.value) || 0;
                const received = parseFloat(item.received_quantity);
                
                if (accepted + rejected > received) {
                    const diff = (accepted + rejected) - received;
                    rejectedInput.value = Math.max(0, rejected - diff);
                }
            };
            
            acceptedInput.addEventListener('input', validate);
            rejectedInput.addEventListener('input', validate);
        });
        
    } catch (error) {
        toast.show('Failed to load POR for editing: ' + error.message, 'error');
        console.error(error);
    }
}

// Confirm archive POR
function confirmArchivePOR(por) {
    modal.open(
        'Archive POR Record',
        `<p>Are you sure you want to archive <strong>${por.por_number}</strong>?</p>
         <p style="color:var(--text-secondary); font-size:0.9rem;">Archived records can be restored later if needed.</p>`,
        {
            confirmText: 'Archive',
            onConfirm: async () => {
                try {
                    // Update status to Archived instead of deleting
                    const response = await fetch(`api/por.php?action=archive&id=${por.id}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            status: 'Archived',
                            archived_at: new Date().toISOString(),
                            archived_by: store.getState().name
                        })
                    });
                    const result = await response.json();
                    
                    if (!result.success) {
                        throw new Error(result.error || 'Failed to archive POR');
                    }
                    
                    toast.show('POR archived successfully.', 'success');
                    modal.close();
                    await loadPORList();
                    
                } catch (error) {
                    toast.show('Failed to archive POR: ' + error.message, 'error');
                    console.error(error);
                }
            }
        }
    );
}


// Auto-refresh functionality
let autoRefreshInterval = null;

function startAutoRefresh() {
    // Clear any existing interval
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
    }
    
    // Refresh every 30 seconds
    autoRefreshInterval = setInterval(async () => {
        // Only refresh if we're still on the POR page
        if (window.location.hash === '#por') {
            await loadPORList();
        } else {
            // Stop auto-refresh if navigated away
            stopAutoRefresh();
        }
    }, 30000); // 30 seconds
}

function stopAutoRefresh() {
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
        autoRefreshInterval = null;
    }
}

// Event handlers for cross-module communication
function handlePORCreated(event) {
    console.log('✅ [POR Module] Event received: porCreated', event.detail);
    console.log('📍 Current page hash:', window.location.hash);
    
    // Only reload if we're currently on the POR page
    if (window.location.hash === '#por') {
        console.log('🔄 Reloading POR list now...');
        loadPORList();
    } else {
        console.log('⏭️ Not on POR page - will reload when navigating to POR');
    }
}

function handlePORUpdated(event) {
    console.log('✅ [POR Module] Event received: porUpdated', event.detail);
    console.log('📍 Current page hash:', window.location.hash);
    
    // Only reload if we're currently on the POR page
    if (window.location.hash === '#por') {
        console.log('🔄 Reloading POR list now...');
        loadPORList();
    } else {
        console.log('⏭️ Not on POR page - will reload when navigating to POR');
    }
}

// Clean up when navigating away (but keep event listeners active)
window.addEventListener('hashchange', () => {
    if (window.location.hash !== '#por') {
        stopAutoRefresh();
        // Don't remove event listeners - keep them active for cross-module updates
    } else {
        // Re-attach if coming back to POR page
        startAutoRefresh();
        loadPORList(); // Refresh data when returning to page
    }
});


// Save POR as receipt/PDF
function savePORReceipt(porDetails) {
    const receiptWindow = window.open('', '_blank', 'width=800,height=600');
    
    const itemsHTML = porDetails.items ? porDetails.items.map(item => {
        const damaged = item.damaged_quantity || 0;
        return `
            <tr>
                <td style="padding:8px; border:1px solid #ddd;">
                    <strong>${item.product_name}</strong><br>
                    <small style="color:#666;">SKU: ${item.sku || 'N/A'}</small>
                </td>
                <td style="padding:8px; border:1px solid #ddd; text-align:center;">${item.ordered_quantity || 0}</td>
                <td style="padding:8px; border:1px solid #ddd; text-align:center; font-weight:bold;">${item.received_quantity || 0}</td>
                <td style="padding:8px; border:1px solid #ddd; text-align:center; color:#10B981; font-weight:bold; background:#F0FDF4;">${item.accepted_quantity || 0}</td>
                <td style="padding:8px; border:1px solid #ddd; text-align:center; color:#EF4444; font-weight:bold; background:#FEF2F2;">${item.rejected_quantity || 0}</td>
                <td style="padding:8px; border:1px solid #ddd; text-align:center; color:#F59E0B; font-weight:bold; background:#FFFBEB;">${damaged}</td>
                <td style="padding:8px; border:1px solid #ddd; text-align:center;">
                    <span style="padding:2px 8px; border-radius:3px; font-size:0.85em; background:${item.inspection_result === 'Passed' || item.inspection_result === 'Pass' ? '#10B981' : item.inspection_result === 'Conditional' ? '#F59E0B' : '#EF4444'}; color:white;">
                        ${item.inspection_result || 'Pending'}
                    </span>
                </td>
            </tr>
        `;
    }).join('') : '';
    
    const totalDamaged = calculateTotalDamaged(porDetails.items);
    
    receiptWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>POR Receipt - ${porDetails.por_number}</title>
            <style>
                @media print {
                    .no-print { display: none; }
                    body { margin: 0; }
                }
                
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    max-width: 1100px;
                    margin: 20px auto;
                    padding: 20px;
                    background: #fff;
                }
                
                .header {
                    text-align: center;
                    border-bottom: 3px solid #FF7A00;
                    padding-bottom: 20px;
                    margin-bottom: 30px;
                }
                
                .header h1 {
                    color: #FF7A00;
                    margin: 0;
                    font-size: 2em;
                }
                
                .header p {
                    color: #666;
                    margin: 5px 0;
                }
                
                .document-title {
                    background: linear-gradient(135deg, #FF7A00, #DC143C);
                    color: white;
                    padding: 15px;
                    text-align: center;
                    font-size: 1.5em;
                    font-weight: bold;
                    border-radius: 8px;
                    margin-bottom: 20px;
                }
                
                .info-grid {
                    display: grid;
                    grid-template-columns: 1fr 1fr;
                    gap: 20px;
                    margin-bottom: 25px;
                }
                
                .info-section {
                    padding: 15px;
                    background: #F0F9FF;
                    border-left: 4px solid #3B82F6;
                    border-radius: 5px;
                }
                
                .info-section h3 {
                    margin: 0 0 10px 0;
                    color: #333;
                    font-size: 1.1em;
                }
                
                .info-section table {
                    width: 100%;
                    border: none;
                }
                
                .info-section td {
                    padding: 5px 0;
                    border: none;
                    font-size: 0.9em;
                }
                
                .info-section td:first-child {
                    color: #666;
                    font-weight: 600;
                }
                
                .summary-cards {
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    gap: 15px;
                    margin-bottom: 25px;
                }
                
                .summary-card {
                    padding: 15px;
                    border-radius: 8px;
                    text-align: center;
                    border: 2px solid;
                }
                
                .summary-card .label {
                    font-size: 0.85em;
                    margin-bottom: 5px;
                }
                
                .summary-card .value {
                    font-size: 2em;
                    font-weight: bold;
                }
                
                .summary-card .note {
                    font-size: 0.75em;
                    margin-top: 5px;
                }
                
                table.items {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                }
                
                table.items th {
                    background: #333;
                    color: white;
                    padding: 10px;
                    text-align: left;
                    font-weight: 600;
                }
                
                table.items td {
                    padding: 8px;
                    border: 1px solid #ddd;
                }
                
                table.items tr:nth-child(even) {
                    background: #f9f9f9;
                }
                
                .notes-section {
                    background: #FFFBEB;
                    padding: 15px;
                    border-left: 4px solid #F59E0B;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                
                .inventory-notice {
                    background: #F0FDF4;
                    padding: 15px;
                    border-left: 4px solid #10B981;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                
                .inventory-notice strong {
                    color: #15803D;
                }
                
                .signatures {
                    display: grid;
                    grid-template-columns: 1fr 1fr 1fr;
                    gap: 40px;
                    margin: 40px 0;
                }
                
                .signature-box {
                    text-align: center;
                    padding-top: 50px;
                    border-top: 2px solid #333;
                }
                
                .signature-box strong {
                    display: block;
                    margin-top: 10px;
                }
                
                .footer {
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 2px solid #ddd;
                    text-align: center;
                    color: #666;
                    font-size: 0.9em;
                }
                
                .print-button {
                    background: #FF7A00;
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    font-size: 1em;
                    font-weight: bold;
                    border-radius: 5px;
                    cursor: pointer;
                    display: block;
                    margin: 20px auto;
                }
                
                .print-button:hover {
                    background: #DC143C;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🍜 RAM-YUM</h1>
                <p>Product & Inventory Operations System</p>
                <p>Proof of Receiving Record</p>
            </div>
            
            <div class="document-title">
                📋 PROOF OF RECEIVING (POR)
            </div>
            
            <div class="info-grid">
                <div class="info-section">
                    <h3>POR Information</h3>
                    <table>
                        <tr><td>POR Number:</td><td><strong>${porDetails.por_number}</strong></td></tr>
                        <tr><td>PO Number:</td><td>${porDetails.po_number}</td></tr>
                        <tr><td>Supplier:</td><td>${porDetails.supplier_name}</td></tr>
                        <tr><td>Status:</td><td><strong style="color:#10B981;">${porDetails.inspection_status}</strong></td></tr>
                    </table>
                </div>
                <div class="info-section">
                    <h3>Receiving Details</h3>
                    <table>
                        <tr><td>Received Date:</td><td>${porDetails.receiving_date ? new Date(porDetails.receiving_date).toLocaleDateString() : 'N/A'}</td></tr>
                        <tr><td>Received By:</td><td>${porDetails.received_by_name || 'N/A'}</td></tr>
                        <tr><td>Total Items:</td><td>${porDetails.total_items || 0}</td></tr>
                        <tr><td>Total Value:</td><td>₱${parseFloat(porDetails.total_value || 0).toLocaleString('en-PH', {minimumFractionDigits: 2})}</td></tr>
                    </table>
                </div>
            </div>
            
            <h3 style="color:#333; margin-top:30px;">📊 Inspection Summary</h3>
            <div class="summary-cards">
                <div class="summary-card" style="background:#F0FDF4; border-color:#10B981;">
                    <div class="label" style="color:#15803D;">✅ Accepted</div>
                    <div class="value" style="color:#10B981;">${porDetails.total_accepted || 0}</div>
                    <div class="note" style="color:#15803D;">Added to inventory</div>
                </div>
                <div class="summary-card" style="background:#FEF2F2; border-color:#EF4444;">
                    <div class="label" style="color:#991B1B;">❌ Rejected</div>
                    <div class="value" style="color:#EF4444;">${porDetails.total_rejected || 0}</div>
                    <div class="note" style="color:#991B1B;">Not added</div>
                </div>
                <div class="summary-card" style="background:#FFFBEB; border-color:#F59E0B;">
                    <div class="label" style="color:#92400E;">⚠️ Damaged</div>
                    <div class="value" style="color:#F59E0B;">${totalDamaged}</div>
                    <div class="note" style="color:#92400E;">Not added</div>
                </div>
                <div class="summary-card" style="background:#F3F4F6; border-color:#6B7280;">
                    <div class="label" style="color:#374151;">📦 Received</div>
                    <div class="value" style="color:#6B7280;">${porDetails.total_received || 0}</div>
                    <div class="note" style="color:#374151;">Physical count</div>
                </div>
            </div>
            
            ${porDetails.inspection_notes || porDetails.remarks ? `
                <div class="notes-section">
                    <h3 style="margin:0 0 10px 0; color:#92400E;">📝 Inspection Notes</h3>
                    <p style="margin:0; color:#92400E;">${porDetails.inspection_notes || porDetails.remarks}</p>
                </div>
            ` : ''}
            
            <h3 style="color:#333; margin-top:30px;">📦 Items Inspection Details</h3>
            <table class="items">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th style="text-align:center;">Ordered</th>
                        <th style="text-align:center;">Received</th>
                        <th style="text-align:center; background:#10B981;">Accepted</th>
                        <th style="text-align:center; background:#EF4444;">Rejected</th>
                        <th style="text-align:center; background:#F59E0B;">Damaged</th>
                        <th style="text-align:center;">Result</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHTML}
                </tbody>
            </table>
            
            ${porDetails.inventory_updated ? `
                <div class="inventory-notice">
                    <strong>✓ Inventory Updated</strong>
                    <p style="margin:5px 0 0 0; color:#15803D;">
                        Stock levels were updated on ${porDetails.inventory_updated_at ? new Date(porDetails.inventory_updated_at).toLocaleString() : 'N/A'}
                    </p>
                </div>
            ` : ''}
            
            <div class="signatures">
                <div class="signature-box">
                    <strong>Received By</strong>
                    <p style="color:#666; font-size:0.9em; margin-top:5px;">${porDetails.received_by_name || 'N/A'}</p>
                </div>
                <div class="signature-box">
                    <strong>Inspected By</strong>
                    <p style="color:#666; font-size:0.9em; margin-top:5px;">Quality Control</p>
                </div>
                <div class="signature-box">
                    <strong>Approved By</strong>
                    <p style="color:#666; font-size:0.9em; margin-top:5px;">Warehouse Manager</p>
                </div>
            </div>
            
            <div class="footer">
                <p><strong>OFFICIAL PROOF OF RECEIVING DOCUMENT</strong></p>
                <p>POR #: ${porDetails.por_number} | Generated: ${new Date().toLocaleString()}</p>
                <p style="font-size:0.85em; color:#999; margin-top:10px;">
                    This document serves as official proof of receiving and inspection results.<br>
                    Keep for audit and compliance purposes.
                </p>
            </div>
            
            <button class="print-button no-print" onclick="window.print()">🖨️ Print / Save as PDF</button>
        </body>
        </html>
    `);
    
    receiptWindow.document.close();
    
    setTimeout(() => {
        receiptWindow.focus();
    }, 250);
    
    toast.show('POR receipt opened. Use Print button to save as PDF.', 'success');
}
