<?php
/**
 * Stock Transfer Module Implementation Validator
 * Comprehensive validation of all components and integration
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

// Ensure only admins can access validation
$currentUser = require_login_page();
if ($currentUser['role'] !== 'admin') {
    http_response_code(403);
    die('Access denied. Admin role required for validation tools.');
}

// Validation results array
$validationResults = [];

// Function to add validation result
function addResult($category, $test, $status, $message, $details = '') {
    global $validationResults;
    $validationResults[] = [
        'category' => $category,
        'test' => $test,
        'status' => $status,
        'message' => $message,
        'details' => $details
    ];
}

// =====================================================================
// 1. FILE STRUCTURE VALIDATION
// =====================================================================

$requiredFiles = [
    'database/stock-transfer-schema.sql' => 'Database schema definition',
    'database/stock-transfer-demo-data.sql' => 'Demo data scenarios',
    'database/stock-transfer-comprehensive-demo.sql' => 'Comprehensive test scenarios',
    'setup-stock-transfer-db.php' => 'Database setup script',
    'api/stock-transfers.php' => 'Stock Transfer API endpoints',
    'api/locations.php' => 'Locations management API',
    'modules/stock-transfer/stock-transfer.js' => 'Frontend stock transfer module',
    'modules/locations/locations.js' => 'Frontend locations module',
    'assets/js/utils/stock-transfer-service.js' => 'Stock Transfer service utilities',
    'test-stock-transfer-scenarios.php' => 'Interactive testing interface',
    'STOCK_TRANSFER_DOCUMENTATION.md' => 'Complete system documentation'
];

foreach ($requiredFiles as $file => $description) {
    if (file_exists($file)) {
        $size = filesize($file);
        addResult('Files', "File: $file", 'SUCCESS', "$description exists", "Size: " . number_format($size) . " bytes");
    } else {
        addResult('Files', "File: $file", 'ERROR', "$description is missing", '');
    }
}

// =====================================================================
// 2. DATABASE VALIDATION
// =====================================================================

try {
    $pdo = new PDO($dsn, $dbUser, $dbPass, $options);
    addResult('Database', 'Connection', 'SUCCESS', 'Database connection established', '');

    // Check required tables exist
    $requiredTables = ['locations', 'stock_transfers', 'inventory_locations', 'stock_transfer_audit'];
    
    foreach ($requiredTables as $table) {
        $stmt = $pdo->query("SHOW TABLES LIKE '$table'");
        if ($stmt->rowCount() > 0) {
            // Get row count
            $countStmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
            $count = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];
            addResult('Database', "Table: $table", 'SUCCESS', "Table exists with $count records", '');
        } else {
            addResult('Database', "Table: $table", 'ERROR', "Required table missing", 'Run setup-stock-transfer-db.php');
        }
    }

    // Validate JSON structure in stock_transfers
    $stmt = $pdo->query("SELECT id, data FROM stock_transfers LIMIT 3");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $data = json_decode($row['data'], true);
        if ($data && isset($data['transferNumber'], $data['status'], $data['items'])) {
            addResult('Database', "JSON Structure: {$row['id']}", 'SUCCESS', 'Valid JSON structure', '');
        } else {
            addResult('Database', "JSON Structure: {$row['id']}", 'ERROR', 'Invalid JSON structure', '');
        }
    }

} catch (PDOException $e) {
    addResult('Database', 'Connection', 'ERROR', 'Database connection failed', $e->getMessage());
}

// =====================================================================
// 3. API ENDPOINT VALIDATION
// =====================================================================

// Test API endpoints availability
$apiEndpoints = [
    'api/stock-transfers.php' => 'Stock Transfer API',
    'api/locations.php' => 'Locations API'
];

foreach ($apiEndpoints as $endpoint => $description) {
    if (file_exists($endpoint)) {
        // Basic syntax check
        $content = file_get_contents($endpoint);
        if (strpos($content, '<?php') === 0) {
            addResult('API', $description, 'SUCCESS', 'PHP file structure valid', '');
        } else {
            addResult('API', $description, 'ERROR', 'Invalid PHP file structure', '');
        }
        
        // Check for required functions/methods
        if (strpos($content, 'function') !== false || strpos($content, 'switch') !== false) {
            addResult('API', "$description Logic", 'SUCCESS', 'API logic structure present', '');
        } else {
            addResult('API', "$description Logic", 'WARNING', 'API logic structure unclear', '');
        }
    } else {
        addResult('API', $description, 'ERROR', 'API file missing', '');
    }
}

// =====================================================================
// 4. FRONTEND MODULE VALIDATION
// =====================================================================

$jsModules = [
    'modules/stock-transfer/stock-transfer.js' => 'renderStockTransfer',
    'modules/locations/locations.js' => 'renderLocations',
    'assets/js/utils/stock-transfer-service.js' => 'StockTransferService'
];

foreach ($jsModules as $module => $expectedFunction) {
    if (file_exists($module)) {
        $content = file_get_contents($module);
        if (strpos($content, $expectedFunction) !== false) {
            addResult('Frontend', basename($module), 'SUCCESS', "Module contains $expectedFunction", '');
        } else {
            addResult('Frontend', basename($module), 'WARNING', "$expectedFunction not found", '');
        }
        
        // Check for ES6 modules
        if (strpos($content, 'export') !== false) {
            addResult('Frontend', basename($module) . ' ES6', 'SUCCESS', 'ES6 module structure', '');
        } else {
            addResult('Frontend', basename($module) . ' ES6', 'WARNING', 'Not ES6 module', '');
        }
    } else {
        addResult('Frontend', basename($module), 'ERROR', 'Module file missing', '');
    }
}

// =====================================================================
// 5. INTEGRATION VALIDATION
// =====================================================================

// Check dashboard integration
if (file_exists('dashboard.php')) {
    $dashboardContent = file_get_contents('dashboard.php');
    
    if (strpos($dashboardContent, 'stock-transfer') !== false) {
        addResult('Integration', 'Dashboard Navigation', 'SUCCESS', 'Stock Transfer navigation integrated', '');
    } else {
        addResult('Integration', 'Dashboard Navigation', 'ERROR', 'Stock Transfer navigation missing', '');
    }
    
    if (strpos($dashboardContent, 'locations') !== false) {
        addResult('Integration', 'Locations Navigation', 'SUCCESS', 'Locations navigation integrated', '');
    } else {
        addResult('Integration', 'Locations Navigation', 'ERROR', 'Locations navigation missing', '');
    }
    
    // Check routing
    if (strpos($dashboardContent, 'stock-transfer/stock-transfer.js') !== false) {
        addResult('Integration', 'Stock Transfer Routing', 'SUCCESS', 'Module routing configured', '');
    } else {
        addResult('Integration', 'Stock Transfer Routing', 'ERROR', 'Module routing missing', '');
    }
} else {
    addResult('Integration', 'Dashboard', 'ERROR', 'Dashboard file missing', '');
}

// =====================================================================
// 6. AUTHENTICATION & SECURITY VALIDATION
// =====================================================================

// Check auth integration
$authFiles = ['api/stock-transfers.php', 'api/locations.php'];
foreach ($authFiles as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        if (strpos($content, 'require_login') !== false || strpos($content, 'auth.php') !== false) {
            addResult('Security', basename($file) . ' Auth', 'SUCCESS', 'Authentication integration present', '');
        } else {
            addResult('Security', basename($file) . ' Auth', 'WARNING', 'Authentication integration unclear', '');
        }
    }
}

// =====================================================================
// 7. DOCUMENTATION VALIDATION
// =====================================================================

$docFiles = [
    'STOCK_TRANSFER_DOCUMENTATION.md' => 'Complete system documentation',
    'test-stock-transfer-scenarios.php' => 'Interactive demo interface'
];

foreach ($docFiles as $file => $description) {
    if (file_exists($file)) {
        $size = filesize($file);
        if ($size > 5000) { // Substantial documentation
            addResult('Documentation', basename($file), 'SUCCESS', "$description is comprehensive", "Size: " . number_format($size) . " bytes");
        } else {
            addResult('Documentation', basename($file), 'WARNING', "$description may be incomplete", "Size: " . number_format($size) . " bytes");
        }
    } else {
        addResult('Documentation', basename($file), 'ERROR', "$description is missing", '');
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Transfer Implementation Validation</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .validation-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            margin-bottom: 24px;
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            font-size: 1.25rem;
            font-weight: 700;
        }
        .card-content { padding: 0; }
        .result-item {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-color);
        }
        .result-item:last-child { border-bottom: none; }
        .result-status {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
            margin-right: 16px;
            flex-shrink: 0;
        }
        .status-SUCCESS { background: #10B981; color: white; }
        .status-WARNING { background: #F59E0B; color: white; }
        .status-ERROR { background: #EF4444; color: white; }
        .result-info { flex: 1; }
        .result-test { font-weight: 600; color: var(--text-primary); margin-bottom: 4px; }
        .result-message { color: var(--text-secondary); font-size: 0.875rem; }
        .result-details { color: var(--text-muted); font-size: 0.75rem; margin-top: 2px; }
        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            text-align: center;
        }
        .stat-number { font-size: 2rem; font-weight: 700; margin-bottom: 8px; }
        .stat-label { color: var(--text-secondary); font-size: 0.875rem; }
        .success { color: #10B981; }
        .warning { color: #F59E0B; }
        .error { color: #EF4444; }
        .overall-status {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 24px;
            text-align: center;
            margin-bottom: 32px;
        }
        .status-icon { font-size: 3rem; margin-bottom: 16px; }
        .status-title { font-size: 1.5rem; font-weight: 700; margin-bottom: 8px; }
        .status-subtitle { color: var(--text-secondary); }
        .actions { text-align: center; margin: 32px 0; }
        .btn {
            display: inline-block;
            padding: 12px 24px;
            margin: 8px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-primary { background: var(--primary-red); color: white; }
        .btn-secondary { background: var(--bg-gray); color: var(--text-primary); }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
    </style>
</head>
<body>
    <div class="container">
        <div style="text-align: center; margin-bottom: 40px;">
            <h1 style="color: var(--text-primary);">Stock Transfer Implementation Validation</h1>
            <p style="color: var(--text-secondary);">Comprehensive validation of all module components</p>
        </div>

        <?php
        // Calculate summary statistics
        $totalTests = count($validationResults);
        $successCount = count(array_filter($validationResults, fn($r) => $r['status'] === 'SUCCESS'));
        $warningCount = count(array_filter($validationResults, fn($r) => $r['status'] === 'WARNING'));
        $errorCount = count(array_filter($validationResults, fn($r) => $r['status'] === 'ERROR'));
        $successRate = round(($successCount / $totalTests) * 100, 1);

        // Determine overall status
        if ($errorCount === 0 && $warningCount === 0) {
            $overallStatus = 'EXCELLENT';
            $statusIcon = '🎉';
            $statusColor = 'success';
            $statusMessage = 'All components validated successfully!';
        } elseif ($errorCount === 0) {
            $overallStatus = 'GOOD';
            $statusIcon = '✅';
            $statusColor = 'warning';
            $statusMessage = 'System ready with minor warnings.';
        } elseif ($errorCount <= 2) {
            $overallStatus = 'NEEDS ATTENTION';
            $statusIcon = '⚠️';
            $statusColor = 'warning';
            $statusMessage = 'Some issues found, but system may function.';
        } else {
            $overallStatus = 'CRITICAL ISSUES';
            $statusIcon = '❌';
            $statusColor = 'error';
            $statusMessage = 'Multiple critical issues found.';
        }
        ?>

        <!-- Overall Status -->
        <div class="overall-status">
            <div class="status-icon"><?= $statusIcon ?></div>
            <div class="status-title <?= $statusColor ?>"><?= $overallStatus ?></div>
            <div class="status-subtitle"><?= $statusMessage ?></div>
        </div>

        <!-- Summary Statistics -->
        <div class="summary-stats">
            <div class="stat-card">
                <div class="stat-number"><?= $totalTests ?></div>
                <div class="stat-label">Total Tests</div>
            </div>
            <div class="stat-card">
                <div class="stat-number success"><?= $successCount ?></div>
                <div class="stat-label">Passed</div>
            </div>
            <div class="stat-card">
                <div class="stat-number warning"><?= $warningCount ?></div>
                <div class="stat-label">Warnings</div>
            </div>
            <div class="stat-card">
                <div class="stat-number error"><?= $errorCount ?></div>
                <div class="stat-label">Errors</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?= $successRate ?>%</div>
                <div class="stat-label">Success Rate</div>
            </div>
        </div>

        <!-- Detailed Results by Category -->
        <?php
        $categories = array_unique(array_column($validationResults, 'category'));
        foreach ($categories as $category):
            $categoryResults = array_filter($validationResults, fn($r) => $r['category'] === $category);
        ?>
        <div class="validation-card">
            <div class="card-header">
                <?= htmlspecialchars($category) ?> Validation
                <span style="font-size: 0.875rem; opacity: 0.8; margin-left: 16px;">
                    (<?= count($categoryResults) ?> tests)
                </span>
            </div>
            <div class="card-content">
                <?php foreach ($categoryResults as $result): ?>
                <div class="result-item">
                    <div class="result-status status-<?= $result['status'] ?>">
                        <?= $result['status'] === 'SUCCESS' ? '✓' : ($result['status'] === 'WARNING' ? '!' : '✗') ?>
                    </div>
                    <div class="result-info">
                        <div class="result-test"><?= htmlspecialchars($result['test']) ?></div>
                        <div class="result-message"><?= htmlspecialchars($result['message']) ?></div>
                        <?php if ($result['details']): ?>
                        <div class="result-details"><?= htmlspecialchars($result['details']) ?></div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>

        <!-- Action Buttons -->
        <div class="actions">
            <a href="dashboard.php" class="btn btn-primary">Open Dashboard</a>
            <a href="test-stock-transfer-scenarios.php" class="btn btn-secondary">Test Scenarios</a>
            <a href="setup-stock-transfer-db.php" class="btn btn-secondary">Database Setup</a>
            <button class="btn btn-secondary" onclick="location.reload()">Re-run Validation</button>
        </div>

        <!-- Recommendations -->
        <?php if ($errorCount > 0 || $warningCount > 0): ?>
        <div style="background: var(--bg-gray); padding: 24px; border-radius: 12px; margin-top: 32px;">
            <h3 style="margin-bottom: 16px; color: var(--text-primary);">🔧 Recommendations</h3>
            <ul style="color: var(--text-secondary); line-height: 1.6;">
                <?php if ($errorCount > 0): ?>
                <li><strong>Fix Critical Errors:</strong> Address all ERROR status items before system demonstration.</li>
                <?php endif; ?>
                <?php if ($warningCount > 0): ?>
                <li><strong>Review Warnings:</strong> Check WARNING items to ensure optimal functionality.</li>
                <?php endif; ?>
                <li><strong>Database Setup:</strong> Ensure database schema and demo data are properly loaded.</li>
                <li><strong>Test Workflow:</strong> Run through complete transfer workflow before presentation.</li>
                <li><strong>User Training:</strong> Review documentation for proper system usage.</li>
            </ul>
        </div>
        <?php endif; ?>

        <!-- System Information -->
        <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid var(--border-color); color: var(--text-muted); font-size: 0.875rem;">
            <p>Stock Transfer Module v1.0 | Validation completed on <?= date('Y-m-d H:i:s') ?></p>
        </div>
    </div>
</body>
</html>